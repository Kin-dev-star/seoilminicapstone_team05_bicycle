# 2026-11-25 지도 줌 제한 · 검은 화면 진단 · GPS 속도 개선 (BicycleSafety_v2 기반)

## 기준본
`BicycleSafety_v2_실기기_주행검색_UI간소화` 계열 최신 ZIP에 아래 변경만 누적했습니다.
다른 ChatGPT 작업본(FINAL 계열)에만 있던 수정 중, v2에 빠져 있던 세 가지를 옮긴 것입니다.

## 바뀐 파일 (3개 + 문서)
- `app/src/main/java/com/example/bicyclesafety/MainActivity.java`
- `app/src/main/java/com/example/app/ui/BikeApp.kt`
- `tests/check_startup_zoom.py` (신규 정적 검사)
- `README.md` (최신 기능 기준으로 동작 확인 순서·파일 표·주의사항 갱신), 이 문서

## 변경 내용
1. **지도 줌 10~18레벨 제한** (`MainActivity.applyCameraZoomLimits`)
   - 지도가 준비되면 `kakaoMap.setCameraMinLevel(10)`, `setCameraMaxLevel(18)` 적용.
   - SDK가 허용하는 범위(`getMinZoomLevel`~`getMaxZoomLevel`) 안으로만 맞추고, 실패해도 앱은 계속 동작.
   - 기본 줌 15, 안내 줌 17은 범위 안이라 기존 동작은 그대로.
2. **화면 전환 Crossfade 제거** (`BikeApp.kt`)
   - 로딩 화면 → 메인 화면을 애니메이션 없이 바로 교체. 카카오맵 네이티브 지도 화면이 전환 중 검게 남는 경우를 피하기 위함.
3. **시작 단계 진단 로그** (Logcat 태그 `BicycleSafetyStartup`)
   - `1. onCreate 시작` → `2. Compose 화면 연결 완료` → `3. MapView 생성` → `4. 안전 안내 확인` → `5. 카카오맵 시작 요청` → `6. 카카오맵 준비 완료`
   - `Compose screen=LOADING` / `Compose screen=MAIN`, `지도 줌 제한 적용`, `사고 자료 로딩 완료: 2079건`, 오류 시 `5-오류`.

## 확인 결과 수정하지 않은 것
- 안전 우선 경로로 안내 중 이탈 시 재탐색: `requestReroute`에 이미 안전 우선 분기가 있어 현재 위치에서 안전 우선 비교를 다시 합니다. 변경 없음.
- 그 외 경로 3종, GPS 보호, 위험구역 1회 경고, 주행 중 검색, 경로창 UI, 사고 데이터는 그대로입니다.

## 검증
- 정적 검사 4종 통과: `check_sources`(XML 47개·사고 데이터 2,079건), `check_route_flow`(10개), `check_navigation_search_compact`(11개), `check_startup_zoom`(6개)
- GPS·도착·위험구역 Java 단위 테스트 16개 통과
- `MainActivity.java` javac 구문 검사: 문법 오류 없음 (Android·카카오 라이브러리 참조 오류만 발생, SDK 없는 환경이라 정상)
- **Kotlin 컴파일, Android Studio 전체 빌드, 갤럭시 실행은 이 환경에서 검증하지 못했습니다.**

## 실기기 확인 순서
1. 새 폴더(한글 없는 짧은 경로)에 압축 해제 → 기존 `local.properties`의 SDK 경로와 카카오 키 2줄 복사 → Gradle Sync → 갤럭시 Run
2. 지도를 최대로 확대·축소 → 10~18레벨에서 멈추고 튕기지 않는지 확인
3. 검은 화면이 나오면 Logcat에서 `is:crash` → 없으면 `BicycleSafetyStartup` 검색 후 마지막으로 찍힌 단계 번호를 알려 주세요.
4. 나머지는 `README.md` 3장 순서대로 확인

`local.properties`(API 키)는 GitHub·카톡에 공유하지 마세요.

---

## 추가: 'GPS 확인 중' 대기 시간 단축

### 원인
1. 경로 검색 출발지도 주행 판정과 같은 엄격한 기준(오차 50m·15초 이내)을 써서, 실내·건물 옆에서는 출발지가 늦게 채워졌습니다.
2. 안드로이드 기본 GPS(LocationManager)만 사용해 위성 신호를 기다리는 시간이 길었습니다.

### 변경
- `app/build.gradle.kts`: `com.google.android.gms:play-services-location:21.3.0` 추가
- `MainActivity.java`
  - Play 서비스가 있으면 **Google Fused 위치**(GPS + Wi-Fi + 기지국) 사용: 연속 위치 + 휴대폰의 최근 위치 + 1회성 새 위치를 함께 요청
  - Play 서비스가 없거나 Fused 시작에 실패하면 기존 LocationManager 방식으로 자동 전환
  - 경로 검색 **출발지만** 오차 100m·2분 이내 좌표를 바로 사용
  - 이미 받은 좌표보다 오래된 1회성 좌표는 버려서 'GPS 정확도 낮음'으로 잘못 표시되지 않게 함
  - 화면이 꺼지거나 앱이 닫히면 Fused·기본 GPS 모두 중지
- `NavigationGpsGuard.java`: `MAX_ORIGIN_ACCURACY_METERS = 100`, `isUsableOriginFix()` 추가
- 그대로 둔 것: 지도 위치 반영 50m, 주행 35m, 자동 도착 20m·3회 확인, 위험 경고 80m 기준

### 주의
- 출발지가 최대 100m 정도 어긋날 수 있습니다. 안내를 시작하면 엄격한 주행 기준 좌표로 다시 판정하고, 경로에서 40m 넘게 벗어난 상태가 3번 이어지면 현재 위치에서 자동 재탐색합니다.
- 실내에서는 Fused 위치도 주행 기준(35m)을 통과하지 못할 수 있습니다. 주행 테스트는 실외에서 하세요.
- 처음 Gradle Sync 때 라이브러리를 내려받아야 하므로 네트워크가 필요합니다.

### 추가 검증
- 정적 검사 `check_fused_location` 9개 통과, GPS Java 단위 테스트 22개 통과(출발지 기준 6개 추가)
- `MainActivity.java` 문법 오류 없음. **Fused 위치의 실제 동작 속도는 갤럭시에서 확인해야 합니다.**

### 실기기 확인
1. Logcat `BicycleSafetyStartup`에 `위치: Google Fused 위치 사용`이 나오는지 확인
2. 앱 실행 → 안전 안내 확인 후 현재 위치 표시까지 걸리는 시간 확인
3. 경로 설정 창을 열었을 때 `GPS 확인 중…`이 몇 초 안에 `경로 찾기`로 바뀌는지 확인 (실내·실외 각각)
