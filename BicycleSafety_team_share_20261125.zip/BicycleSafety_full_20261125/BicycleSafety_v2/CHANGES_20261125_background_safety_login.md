# 2026-11-25 밤: 백그라운드 안내 · 안전 경로 강화 · 카카오 로그인(서버 검증) · 마이페이지·제보 데이터 틀

기준: `BicycleSafety_v2_nav_recenter_button_20261125` + 서버 `eclipse-project4`

## 1. 안전 우선 경로 강화 (`SafetyRoutePlanner.java`)
| 전 | 후 |
|---|---|
| 경로 150m 안 사고 지점 **개수** | **가중 위험 점수** = Σ (사고 건수 + 사상자×0.5) × 거리 가중(50m 1.0 / 100m 0.7 / 150m 0.4) |
| 경로 중간 좌우 650m 우회 2곳 | 위험 점수가 큰 사고 지점 최대 2곳(서로 400m 이상)마다 진행 방향 좌우 **300m·600m** + 경로 중간 좌우 650m → 최대 **8곳** |
| 최대 거리 1.6배 | 비용 = 위험 점수 + 늘어난 거리/300m, **기본 경로의 1.35배 초과 제외** |
| - | 우회 지점이 사고 지점 150m 안이면 제외, 우회 지점을 **찍고 같은 길로 되돌아오는 경로 제외** |
| 후보를 하나씩 조회 | **4개씩 동시에 조회** (최대 25초 제한) |
| - | 우회 지점에서 나오던 '도착' 안내 문구 제거 (중간에 도착으로 읽히지 않게) |
- 비교 카드 문구: `위험 점수 N% 감소 · 사고 이력 M곳 감소 · 과거 자료 기반` (개선 없으면 `별도 회피 경로를 찾지 못함`)
- 테스트: `tests/TestSafetyRoutePlanner.java` 42개 통과 (점수·가중치·비용·우회 후보 위치·되돌아오는 경로 판정)
- 한계(발표 때 설명): 카카오 자전거 API에 안전 모드가 없어 후보를 만들어 비교하는 방식이며, 모든 경로를 탐색하는 최적화는 아닙니다. 과거 사고 기록 기반이고 실시간 위험이 아닙니다.

## 2. 백그라운드 길 안내 (`NavigationForegroundService.java` 신규)
- 안내 시작 시 '위치' 타입 포그라운드 서비스 + 상단 알림 → **화면을 끄거나 다른 앱을 써도 GPS·음성 안내·위험 경고 계속**
- 알림에 `150m 앞 좌회전 · 상계역 · 남은 거리 2.4km` 표시 (안내가 바뀌거나 10초마다 갱신), 누르면 앱으로 돌아옴
- 안내 중에는 `onPause`에서 위치 갱신을 멈추지 않음. 안내 종료·앱 종료·최근 앱에서 지우면 서비스 종료
- Android 13 이상: 처음 안내 시작 때 알림 권한 1회 요청 (거부해도 안내는 동작, 알림만 안 보임)
- '항상 허용' 백그라운드 위치 권한은 필요 없음 (앱이 화면에 있을 때 시작하는 포그라운드 서비스)
- 매니페스트: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_LOCATION`, `POST_NOTIFICATIONS`, 서비스 등록, MainActivity `singleTask`

## 3. 카카오 로그인 + 서버 토큰 검증
앱 (`KakaoAuthManager.java` 신규, `MapApplication`, `MainActivity`, `MainScreen` 마이페이지 프로필 카드)
1. 마이페이지 → `카카오 로그인` → 카카오톡 앱(없거나 실패하면 카카오계정 웹)으로 로그인
2. 카카오 액세스 토큰을 서버 `POST /api/auth/kakao` 로 전송 → 서버가 카카오에 검증 → 세션 토큰 수신
3. 세션만 저장(카카오 토큰은 저장 안 함). 프로필 카드: 닉네임 + `서버 인증됨` / `서버 검증 전`
4. `로그아웃` → 카카오 로그아웃 + 서버 세션 삭제
- Gradle: `com.kakao.sdk:v2-user:2.21.2`, 저장소 `https://devrepo.kakao.com/nexus/content/groups/public/`
- 매니페스트: `AuthCodeHandlerActivity` (스킴 `kakao{네이티브 앱 키}`, `local.properties` 값으로 자동 설정)
- `local.properties` 에 `TEAM_API_BASE_URL=http://PC의IP:8088` 추가 (디버그 빌드에서만 http 허용)

서버 (`eclipse-project/MainServer`, 자세한 내용 `README_SERVER_KAKAO_AUTH.md`)
- `POST /api/auth/kakao`: 카카오 `access_token_info`로 **우리 앱 ID에서 발급된 토큰인지** 확인 → `user/me`로 회원번호·닉네임 확인 → `kakao_user` 저장, 세션 발급(`user_session`에 SHA-256 해시만, 30일)
- `GET /api/me`, `POST /api/auth/logout`, `GET /api/hazards`(사고 2,079곳 JSON), `GET /api/health`
- 기존 `/1`, `/2` 유지 + 버그 수정(파라미터에 " HTTP/1.1" 붙던 문제, CPU 100% 반복문)
- `server.properties`에 `kakao.appId`(카카오 앱 ID 숫자) 입력 필요

## 4. 마이페이지·제보게시판 데이터 틀 (`data` 패키지 신규)
- 모델: `FavoritePlace`, `RideRecord`, `RideStats`, `HazardReport`, `UserSession`
- 저장소 인터페이스 3개 + 휴대폰 저장 구현 + 서버 API 구현, 입구는 `AppRepositories` 하나
- 길 안내가 끝나면 **주행 기록 자동 저장** (실제 이동 거리·시간·출발/도착·경로 종류·도착 여부)
- 사용법·서버 API 규격: `docs/TEAM_INTEGRATION_GUIDE.md`
- 화면은 팀원 작업 (마이페이지 아래 기록 영역은 아직 예시 데이터, 제보게시판은 '준비 중' 화면 그대로)

## 5. 검증
- 정적 검사 7종 통과, GPS 테스트 22개·안전 경로 테스트 42개 통과
- Java: 안전 경로·데이터 패키지는 실제 컴파일, 나머지는 구문 검사 통과 / Kotlin: 괄호·인자 대조 통과
- 서버: Java 17 컴파일·로컬 실행으로 `/api/health`, `/api/hazards`(2,079건, 앱 데이터와 전부 일치), `/1`, 오류 응답 확인
- **못 한 것:** Android Studio 빌드·갤럭시 실행, 실제 카카오 로그인·서버 토큰 검증(카카오 서버·MySQL 접속 불가 환경)

## 6. 갤럭시 확인 순서
1. 서버 PC: `server.properties`(앱 ID) → MySQL 켜기 → `Main` 실행 → 휴대폰 브라우저 `http://PC IP:8088/api/health`
2. 앱 `local.properties`에 `TEAM_API_BASE_URL` 추가 → Sync → Run
3. 마이페이지 → 카카오 로그인 → `서버 인증됨` 확인 (서버 콘솔에 `카카오 로그인 성공: 회원번호 …`)
4. 경로 찾기 → 안전 우선 카드의 `위험 점수 N% 감소` 확인
5. 안내 시작 → 알림 권한 허용 → 화면 끄고 걷기/주행 → 음성 안내·알림 갱신 확인 → 종료 후 다시 켜서 정상
6. 안내 종료 후 데이터가 저장되는지는 다음 단계(마이페이지 화면 연결) 후 확인
