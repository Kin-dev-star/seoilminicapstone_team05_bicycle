# 정적 검사
학교 PC에 Python이 있다면, 프로젝트 루트에서 아래를 실행합니다.

```
python tests/check_sources.py
python tests/check_route_flow.py
python tests/check_navigation_search_compact.py
python tests/check_startup_zoom.py
python tests/check_fused_location.py
python tests/check_nav_ui_recent_routes.py
python tests/check_background_safety_login.py
python tests/check_lockscreen_simulation.py
```

GPS 단위 테스트: `javac -d out app/src/main/java/com/example/bicyclesafety/NavigationGpsGuard.java app/src/main/java/com/example/bicyclesafety/RiskWarningGate.java tests/TestNavigationGpsGuard.java` 후 `java -cp out com.example.bicyclesafety.TestNavigationGpsGuard`

안전 경로 계산 테스트(org.json이 필요하므로 Android Studio의 단위 테스트로 옮기거나, 위와 같은 방식에 org.json jar를 클래스패스에 추가): `tests/TestSafetyRoutePlanner.java`

이 검사는 **Android 실제 빌드가 아님**. Gradle·SDK·카카오 API·GPS·TTS 실행은 체크리스트를 따르세요.
