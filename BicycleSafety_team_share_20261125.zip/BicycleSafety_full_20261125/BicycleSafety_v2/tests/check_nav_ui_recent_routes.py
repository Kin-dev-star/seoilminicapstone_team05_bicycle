# -*- coding: utf-8 -*-
"""11/25 저녁 요청 반영 정적 검사 (빌드/실행 아님).
위치 화살표 줌 비례 · 안내 시작 확대 · 안내 화면 개편 · 하단 동그라미 검색 ·
장소/주소 통합 검색 · 다른 출발지 + 내 위치에서 안내 · 최근 경로 · 미리보기 전체 경로 맞춤
"""
from pathlib import Path
base = Path(__file__).resolve().parents[1]
java = base / 'app/src/main/java/com/example/bicyclesafety'
ui = base / 'app/src/main/java/com/example/app/ui'
res = base / 'app/src/main/res/drawable-nodpi'
activity = (java / 'MainActivity.java').read_text(encoding='utf-8')
repo = (java / 'KakaoRouteRepository.java').read_text(encoding='utf-8')
store = (java / 'RecentRouteStore.java').read_text(encoding='utf-8')
bridge = (ui / 'BikeUiBridge.kt').read_text(encoding='utf-8')
app = (ui / 'BikeApp.kt').read_text(encoding='utf-8')
screen = (ui / 'main/MainScreen.kt').read_text(encoding='utf-8')
nav = (ui / 'main/NavigationScreen.kt').read_text(encoding='utf-8')

arrow_files = ['ic_nav_self_arrow_z10', 'ic_nav_self_arrow_z12', 'ic_nav_self_arrow_z13', 'ic_nav_self_arrow_z14',
               'ic_nav_self_arrow_z15', 'ic_nav_self_arrow_z16', 'ic_nav_self_arrow_z17']
checks = {
    '줌 레벨별 화살표 이미지 7개': all((res / (n + '.png')).exists() for n in arrow_files),
    '화살표·위치점 줌 레벨 스타일': 'navArrowStyles()' in activity and 'locationDotStyles()' in activity
        and '.setZoomLevel(MARKER_ZOOM_LEVELS[i])' in activity
        and all(f'R.drawable.{n}' in activity for n in arrow_files),
    '줌 레벨 오름차순': 'MARKER_ZOOM_LEVELS = {0, 12, 13, 14, 15, 16, 17, 18}' in activity,
    '안내 시작 즉시 확대': 'moveCameraToPoint(startView.getLatitude(), startView.getLongitude(), NAV_ZOOM)' in activity,
    '미리보기 카드 높이 기준 전체 경로 맞춤': 'public void onRoutePreviewLayout(int panelHeightPx)' in activity
        and 'fitRouteCamera(minLat, maxLat, minLng, maxLng)' in activity
        and '.onSizeChanged { onPreviewLayout(it.height) }' in screen,
    '안내 화면: 회전 카드 + 다음 안내 꼬리': 'TurnCard(state, attachedBelow' in nav and 'NextTurnTab(' in nav,
    '안내 화면: 상단 검색창 제거': 'NavigationSearchBar' not in nav,
    '안내 화면: 하단 동그라미 → 검색창': 'SearchCircleButton(onClick = { searchOpen = true })' in nav
        and 'NavigationSearchField(' in nav and '.imePadding()' in nav,
    '장소·주소 통합 검색': 'searchPlacesCombined(' in repo and 'KakaoRouteRepository.searchPlacesCombined(' in activity
        and 'onAddressModeChange(!addressOnly)' not in screen,
    '출발지 입력 + 내 위치 버튼': 'onUseMyLocation' in screen and 'PlaceSuggestions(0, start' in screen
        and '"출발지 검색 (장소·주소)"' in screen,
    '다른 출발지면 내 위치에서 안내': 'fromCurrentLocation' in bridge and '"내 위치에서 안내"' in nav
        and 'public void onGuideFromMyLocation()' in activity and 'startGuidanceAfterAnalysis' in activity,
    '최근 경로 저장(최대 5개)': 'MAX_ITEMS = 5' in store and 'saveRecentRoute(from, to, fromGps)' in activity,
    '최근 경로 목록·다시 검색·삭제': 'SectionTitle("최근 경로")' in screen and 'RecentRouteRow(' in screen
        and 'onRecentRouteSelected' in bridge and 'onRecentRouteRemoved' in bridge,
    '안내 중 지도 조작 시 따라가기 해제 + 내 위치 버튼': 'setOnCameraMoveStartListener' in activity
        and 'if (followMyLocation) moveCameraToLocation(location, NAV_ZOOM);' in activity
        and 'public void onRecenterRequested()' in activity and 'fun navFollowing' in bridge
        and 'if (!state.following) RecenterButton(onClick = onRecenter)' in nav and 'onRecenter = onRecenter' in app,
    'Compose 연결(BikeApp 전달)': all(k in app for k in
        ['recentRoutes = recentRoutes', 'onGuideFromMyLocation = onGuideFromMyLocation', 'onPreviewLayout = onPreviewLayout']),
}
for name, ok in checks.items():
    assert ok, 'FAIL: ' + name
    print('PASS:', name)
print(f'PASS: {len(checks)} nav/route UI checks')
