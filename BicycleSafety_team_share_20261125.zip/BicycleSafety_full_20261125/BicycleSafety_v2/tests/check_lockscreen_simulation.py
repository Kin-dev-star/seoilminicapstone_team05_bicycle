# -*- coding: utf-8 -*-
"""11/25 밤: 잠금화면 안내 알림 · 주행 시뮬레이션(시연 모드) 정적 검사 (빌드/실행 아님)."""
from pathlib import Path
base = Path(__file__).resolve().parents[1]
java = base / 'app/src/main/java/com/example/bicyclesafety'
activity = (java / 'MainActivity.java').read_text(encoding='utf-8')
service = (java / 'NavigationForegroundService.java').read_text(encoding='utf-8')
manifest = (base / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
nav = (base / 'app/src/main/java/com/example/app/ui/main/NavigationScreen.kt').read_text(encoding='utf-8')
bridge = (base / 'app/src/main/java/com/example/app/ui/BikeUiBridge.kt').read_text(encoding='utf-8')
checks = {
    '잠금화면 공개 알림': 'VISIBILITY_PUBLIC' in service and 'setLockscreenVisibility(Notification.VISIBILITY_PUBLIC)' in service,
    '기본 중요도 새 채널(소리·진동 끔)': 'IMPORTANCE_DEFAULT' in service and 'setSound(null, null)' in service
        and 'deleteNotificationChannel(OLD_CHANNEL_ID)' in service,
    '진행 막대·안내 종료 버튼': 'setProgress(1000' in service and 'addAction(0, "안내 종료", endIntent)' in service,
    '종료 버튼 처리': 'ACTION_END_GUIDANCE.equals(intent.getAction())' in activity,
    '잠금 위 안내 화면': 'setShowWhenLocked(true)' in activity and 'setShowWhenLocked(false)' in activity,
    '시뮬레이션 시작·가짜 GPS 주입': 'public void onSimulateGuidanceRequested()' in activity
        and 'new Location(SIMULATION_PROVIDER)' in activity and 'onLocationChanged(fake)' in activity,
    '시뮬레이션 중 실제 GPS 차단': 'if (simulationActive) return; // 시뮬레이션 중에는 실제 GPS를 쓰지 않음' in activity
        and '!SIMULATION_PROVIDER.equals(location.getProvider())' in activity,
    '화면 꺼짐 중 동작(WakeLock)': 'PARTIAL_WAKE_LOCK' in activity and 'android.permission.WAKE_LOCK' in manifest,
    '시뮬레이션은 주행 기록 제외·위치 초기화': 'finishRide(arrivedEnd, simulationActive, spoken != null);' in activity and 'if (!simulated) {' in activity and 'lastOriginCandidate = null;' in activity,
    '미리보기 버튼(디버그)·안내 배너': 'BuildConfig.DEBUG' in nav and 'onSimulateGuidance' in nav
        and '주행 시뮬레이션 중 · 실제 GPS 아님' in nav and 'fun navSimulated' in bridge,
}
for name, ok in checks.items():
    assert ok, 'FAIL: ' + name
    print('PASS:', name)
print(f'PASS: {len(checks)} lockscreen/simulation checks')
