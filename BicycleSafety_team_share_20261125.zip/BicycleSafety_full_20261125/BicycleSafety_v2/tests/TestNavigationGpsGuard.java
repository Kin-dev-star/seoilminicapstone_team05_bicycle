package com.example.bicyclesafety;

/** Android 없이 javac/java 로 실행하는 GPS·도착 판정 회귀 테스트. */
public final class TestNavigationGpsGuard {
    private static int checked = 0;
    private static void expect(boolean value, String description) {
        checked++;
        if (!value) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        long now = 100_000_000_000L;
        expect(NavigationGpsGuard.isUsableFix(true, 8f, now - 2_000_000_000L, now, 35f), "정상 GPS");
        expect(!NavigationGpsGuard.isUsableFix(false, 8f, now, now, 35f), "정확도 없는 좌표 거절");
        expect(!NavigationGpsGuard.isUsableFix(true, 80f, now, now, 35f), "80m 오차 거절");
        expect(!NavigationGpsGuard.isUsableFix(true, Float.NaN, now, now, 35f), "NaN 오차 거절");
        expect(!NavigationGpsGuard.isUsableFix(true, 8f, now - 16_000_000_000L, now, 35f), "16초 된 좌표 거절");
        expect(!NavigationGpsGuard.isUsableFix(true, 8f, now + 3_000_000_000L, now, 35f), "미래 시각 좌표 거절");
        expect(NavigationGpsGuard.isPlausibleMovement(8f, now - 1_000_000_000L, now), "정상 이동");
        expect(!NavigationGpsGuard.isPlausibleMovement(120f, now - 1_000_000_000L, now), "순간 점프 거절");
        expect(!NavigationGpsGuard.isPlausibleMovement(0f, now, now), "동일 시각 재전송 거절");
        NavigationGpsGuard guard = new NavigationGpsGuard();
        expect(!guard.confirmArrival(true, now - 3_000_000_000L), "첫 도착 후보에서 안내 유지");
        expect(!guard.confirmArrival(true, now - 3_000_000_000L), "같은 측정치 중복은 세지 않음");
        expect(!guard.confirmArrival(true, now - 2_000_000_000L), "두번째 도착 후보에서 안내 유지");
        expect(guard.confirmArrival(true, now - 1_000_000_000L), "서로 다른 3번째 측정치에서 종료 허용");
        guard.resetArrival();
        expect(!guard.confirmArrival(true, now), "리셋 후 재시작");
        expect(!guard.confirmArrival(false, now + 1_000_000_000L), "목적지 밖이면 연속 카운트 리셋");
        expect(!guard.confirmArrival(true, now + 2_000_000_000L), "재진입은 1회부터 시작");
        // 경로 검색 출발지: 주행 기준보다 느슨하지만 오래되거나 크게 틀린 좌표는 거절
        expect(NavigationGpsGuard.isUsableOriginFix(true, 80f, now - 5_000_000_000L, now), "출발지 80m 오차 허용");
        expect(NavigationGpsGuard.isUsableOriginFix(true, 30f, now - 90_000_000_000L, now), "출발지 90초 된 최근 위치 허용");
        expect(!NavigationGpsGuard.isUsableOriginFix(true, 150f, now, now), "출발지 150m 오차 거절");
        expect(!NavigationGpsGuard.isUsableOriginFix(true, 20f, now - 180_000_000_000L, now), "출발지 3분 된 위치 거절");
        expect(!NavigationGpsGuard.isUsableOriginFix(false, 20f, now, now), "출발지 정확도 없는 좌표 거절");
        expect(!NavigationGpsGuard.isUsableFix(true, 80f, now, now, NavigationGpsGuard.MAX_NAV_ACCURACY_METERS), "출발지 기준 완화가 주행 기준에 영향 없음");
        System.out.println("PASS: " + checked + " GPS guard checks");
    }
}
