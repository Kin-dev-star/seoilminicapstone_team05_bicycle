# -*- coding: utf-8 -*-
"""11/25 GPS 속도 개선: Google Fused 위치 + 출발지 기준 완화 정적 검사 (빌드/실행 아님)."""
from pathlib import Path
base = Path(__file__).resolve().parents[1]
activity = (base / 'app/src/main/java/com/example/bicyclesafety/MainActivity.java').read_text(encoding='utf-8')
guard = (base / 'app/src/main/java/com/example/bicyclesafety/NavigationGpsGuard.java').read_text(encoding='utf-8')
gradle = (base / 'app/build.gradle.kts').read_text(encoding='utf-8')
checks = {
    'play-services-location 의존성': 'com.google.android.gms:play-services-location:' in gradle,
    'Play 서비스 확인 후 Fused 사용': 'isGooglePlayServicesAvailable' in activity and 'LocationServices.getFusedLocationProviderClient' in activity,
    'Play 서비스 없으면 기존 GPS 대체': 'locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER' in activity,
    'Fused 연속 위치 + 빠른 1회 위치': 'fusedClient.requestLocationUpdates(' in activity
        and 'fusedClient.getLastLocation()' in activity and 'fusedClient.getCurrentLocation(' in activity,
    '오래된 1회 좌표 무시': 'deliverQuickFix' in activity,
    '화면 꺼짐 시 위치 중지': activity.count('stopLocationUpdates();') >= 2,
    '출발지 기준 100m·2분': 'MAX_ORIGIN_ACCURACY_METERS = 100f' in guard and 'MAX_ORIGIN_FIX_AGE_NANOS = 120_000_000_000L' in guard,
    '출발지는 완화 기준 사용': 'isOriginFix(lastOriginCandidate)' in activity and 'if (pendingOriginLocation) applyGpsOrigin(location);' in activity,
    '주행 기준은 그대로 (35m/20m)': 'MAX_NAV_ACCURACY_METERS = 35f' in guard and 'MAX_ARRIVAL_ACCURACY_METERS = 20f' in guard,
}
for name, ok in checks.items():
    assert ok, 'FAIL: ' + name
    print('PASS:', name)
print(f'PASS: {len(checks)} fused location checks')
