package com.example.bicyclesafety;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Android·네트워크 없이 실행하는 안전 우선 경로 계산 테스트 (카카오 API 호출 부분 제외). */
public final class TestSafetyRoutePlanner {
    private static int checked = 0;
    private static void expect(boolean value, String description) {
        checked++;
        if (!value) throw new AssertionError(description);
    }

    private static RiskPoint risk(double lat, double lng, int accidents, int casualties) {
        RiskPoint r = new RiskPoint();
        r.latitude = lat; r.longitude = lng; r.accidentCount = accidents; r.casualtyCount = casualties;
        r.name = "test";
        return r;
    }

    /** 위도 37.5에서 동쪽으로 곧게 가는 약 2.6km 경로 */
    private static List<KakaoRouteRepository.Point> straightEast() {
        List<KakaoRouteRepository.Point> path = new ArrayList<>();
        for (int i = 0; i <= 30; i++) path.add(new KakaoRouteRepository.Point(37.5, 127.0 + i * 0.001));
        return path;
    }

    public static void main(String[] args) {
        List<KakaoRouteRepository.Point> path = straightEast();
        double oneHundredMetersLat = 100.0 / 111320.0;

        // 가중치·거리 가중
        expect(SafetyRoutePlanner.weightOf(risk(0, 0, 4, 2)) == 5.0, "사고 4건 + 사상자 2명 = 5점");
        expect(SafetyRoutePlanner.weightOf(risk(0, 0, 0, 0)) == 1.0, "사고 0건도 최소 1점");
        expect(SafetyRoutePlanner.proximityFactor(30) == 1.0, "50m 이내 1.0");
        expect(SafetyRoutePlanner.proximityFactor(80) == 0.7, "100m 이내 0.7");
        expect(SafetyRoutePlanner.proximityFactor(140) == 0.4, "150m 이내 0.4");
        expect(SafetyRoutePlanner.proximityFactor(160) == 0.0, "150m 밖 0");

        // 위험 점수: 경로 위 큰 사고지점 > 경로에서 조금 떨어진 작은 사고지점
        List<RiskPoint> risks = Arrays.asList(
                risk(37.5, 127.010, 4, 4),                          // 경로 위: (4+2)*1.0 = 6
                risk(37.5 + 1.2 * oneHundredMetersLat, 127.020, 1, 0), // 약 120m: 1*0.4 = 0.4
                risk(37.52, 127.015, 9, 9));                         // 약 2.2km 밖: 0
        double score = SafetyRoutePlanner.riskScore(risks, path);
        expect(Math.abs(score - 6.4) < 1e-6, "가중 위험 점수 6.4, 실제 " + score);
        expect(SafetyRoutePlanner.riskCount(risks, path) == 2, "150m 이내 사고 지점 2곳");

        // 비용: 위험 3점 줄이려고 600m 더 가는 것은 이득 (3 > 2)
        double baseCost = SafetyRoutePlanner.cost(6.0, 2000, 2000);
        double detourCost = SafetyRoutePlanner.cost(3.0, 2600, 2000);
        expect(detourCost < baseCost, "위험 3점 감소 > 600m 증가(2점) 이면 우회가 유리");
        expect(SafetyRoutePlanner.cost(5.5, 3000, 2000) > baseCost, "위험 0.5점 감소에 1km 증가는 불리");

        // 우회 후보: 큰 위험 지점 기준 좌우(남북) 300m·600m + 중간 650m
        KakaoRouteRepository.PlaceOption from = new KakaoRouteRepository.PlaceOption("A", "", 37.5, 127.0);
        KakaoRouteRepository.PlaceOption to = new KakaoRouteRepository.PlaceOption("B", "", 37.5, 127.03);
        List<SafetyRoutePlanner.Via> vias = SafetyRoutePlanner.candidateVias(risks, path, from, to);
        expect(!vias.isEmpty() && vias.size() <= SafetyRoutePlanner.MAX_CANDIDATES, "우회 후보 1~10개, 실제 " + vias.size());
        SafetyRoutePlanner.Via first = vias.get(0);
        double offsetMeters = Math.abs(first.latitude - 37.5) * 111320.0;
        double expectedNear = SafetyRoutePlanner.offsetsFor((int) Math.round(SafetyRoutePlanner.pathLength(path)))[0];
        expect(Math.abs(offsetMeters - expectedNear) < 5, "첫 후보는 진행 방향 수직 '가까운 폭', 실제 " + offsetMeters);
        expect(Math.abs(first.longitude - 127.010) < 0.0015, "첫 후보는 가장 위험한 지점 옆");
        boolean bothSides = false;
        for (SafetyRoutePlanner.Via v : vias) if (v.latitude < 37.5) { bothSides = true; break; }
        expect(bothSides && first.latitude > 37.5 || bothSides, "좌우 양쪽 후보 생성");
        for (SafetyRoutePlanner.Via v : vias) {
            for (RiskPoint r : risks) {
                expect(SafetyRoutePlanner.meters(v.latitude, v.longitude, r.latitude, r.longitude)
                        > SafetyRoutePlanner.VIA_HAZARD_CLEARANCE_METERS, "우회 지점은 사고 지점 60m 밖");
            }
        }

        // 우회 폭은 경로 길이에 비례 (짧은 길은 좁게, 긴 길은 넓게)
        double[] shortOffsets = SafetyRoutePlanner.offsetsFor(800);
        expect(shortOffsets[0] == 150 && shortOffsets[1] == 300, "0.8km 경로: 150m·300m");
        double[] midOffsets = SafetyRoutePlanner.offsetsFor(2500);
        expect(midOffsets[0] == 300 && Math.abs(midOffsets[1] - 625) < 1e-6, "2.5km 경로: 300m·625m");
        double[] longOffsets = SafetyRoutePlanner.offsetsFor(10000);
        expect(longOffsets[0] == 400 && longOffsets[1] == 800, "10km 경로: 400m·800m (상한)");

        // 사고 지점이 촘촘해도 후보가 남아야 함 (예전에는 150m 필터로 거의 다 버려짐)
        List<RiskPoint> dense = new ArrayList<>();
        for (int i = 0; i <= 30; i++) {
            dense.add(risk(37.5, 127.0 + i * 0.001, 2, 1));                       // 경로 위
            dense.add(risk(37.5 + 2.2 * oneHundredMetersLat, 127.0 + i * 0.001 + 0.0005, 1, 0)); // 경로 북쪽 220m 줄
            dense.add(risk(37.5 - 2.2 * oneHundredMetersLat, 127.0 + i * 0.001 + 0.0005, 1, 0)); // 경로 남쪽 220m 줄
        }
        List<SafetyRoutePlanner.Via> denseVias = SafetyRoutePlanner.candidateVias(dense, path, from, to);
        expect(denseVias.size() >= 4, "사고 지점이 촘촘한 지역에서도 후보 4개 이상, 실제 " + denseVias.size());

        // 비용으로 못 이겨도 위험 25% 이상 감소면 '안전 우선' 대안
        expect(SafetyRoutePlanner.isSafetyFallback(8.0, 6.0), "8 → 6 (25% 감소)은 대안으로 인정");
        expect(!SafetyRoutePlanner.isSafetyFallback(8.0, 6.5), "8 → 6.5 (19% 감소)는 부족");
        expect(!SafetyRoutePlanner.isSafetyFallback(0, 0), "기본 경로 위험 0이면 대안 불필요");

        // 사고 지점이 없으면 후보 중 위험지점 맞춤 후보 없음 (중간 우회만)
        List<SafetyRoutePlanner.Via> none = SafetyRoutePlanner.candidateVias(new ArrayList<>(), path, from, to);
        expect(none.size() == 2, "위험 지점이 없으면 중간 좌우 2개만");

        // 찍고 돌아오는 경로 감지
        List<KakaoRouteRepository.Point> out = new ArrayList<>();
        for (int i = 0; i <= 10; i++) out.add(new KakaoRouteRepository.Point(37.5 + i * 0.0005, 127.0));
        List<KakaoRouteRepository.Point> back = new ArrayList<>();
        for (int i = 10; i >= 0; i--) back.add(new KakaoRouteRepository.Point(37.5 + i * 0.0005, 127.0));
        expect(SafetyRoutePlanner.isOutAndBack(out, back), "같은 길로 되돌아오면 제외");
        List<KakaoRouteRepository.Point> onward = new ArrayList<>();
        for (int i = 0; i <= 10; i++) onward.add(new KakaoRouteRepository.Point(37.505, 127.0 + i * 0.0006));
        expect(!SafetyRoutePlanner.isOutAndBack(out, onward), "다른 방향으로 이어지면 통과");

        // 감소율 표시
        SafetyRoutePlanner.Selection sel = new SafetyRoutePlanner.Selection(null, true, 1, 8.0, 2.0);
        expect(sel.reductionPercent() == 75, "위험 점수 8 → 2 는 75% 감소");

        System.out.println("PASS: " + checked + " safety route checks");
    }
}
