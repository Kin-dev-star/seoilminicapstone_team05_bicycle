"""11/25 사용자 지정 화면 및 실기기 GPS 기능 최소 연결 회귀 검사(빌드/실행 아님)."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/java/com/example'
activity=(root/'bicyclesafety/MainActivity.java').read_text()
bridge=(root/'app/ui/BikeUiBridge.kt').read_text()
app=(root/'app/ui/BikeApp.kt').read_text()
screen=(root/'app/ui/main/MainScreen.kt').read_text()
nav=(root/'app/ui/main/NavigationScreen.kt').read_text()
checks={
 '주행 속도 UI 제거': 'SpeedBadge(' not in nav and 'BottomInfoCard(' in nav,
 '휴대폰 방향 센서 사용': 'Sensor.TYPE_ROTATION_VECTOR' in activity and 'deviceHeadingDegrees' in activity and 'currentLocationLabel.rotateTo' in activity,
 '주행 중 새 목적지 검색(하단 동그라미)': 'SearchCircleButton(' in nav and 'NavigationSearchField(' in nav and 'onSearchDestination(query)' in nav and 'onSearchDestinationDuringGuidance' in activity and 'onSearchDestination = onSearchDestination' in app,
 'Java-Compose 경로 검색 연결': 'activity.onSearchDestinationDuringGuidance(destination)' in bridge,
 '현재 GPS 출발지(기본값)': 'if (routeOpen && selectedOrigin == null && originFromGps) onApplyGpsOrigin()' in screen,
 '경로시트 간소화': '목적지를 검색하세요' in screen and '"✓ 내 위치"' in screen and 'OptionChip(' in screen and 'SectionTitle("경로 옵션")' not in screen,
 '세 경로 비교 유지': 'onAnalyzeRoute(start.ifBlank { "현재 위치" }, dest, 2' in screen and 'onSelectRoute' in nav,
 '집·회사 즐겨찾기 UI 유지': 'FavoriteTile(Icons.Filled.Home, "집")' in screen and 'FavoriteTile(Icons.Filled.Place, "회사")' in screen,
 '빠른 위치 초기 요청': 'getLastKnownLocation' in activity and 'getCurrentLocation' in activity,
 'GPS 도착 오판 보호 유지': 'navigationGpsGuard.confirmArrival(' in activity,
 '위험지역 접근 게이트 유지': 'riskWarningGate.update(' in activity,
}
for title, ok in checks.items():
 assert ok, 'FAIL: '+title
 print('PASS: '+title)
print(f'PASS: {len(checks)} integration checks')
