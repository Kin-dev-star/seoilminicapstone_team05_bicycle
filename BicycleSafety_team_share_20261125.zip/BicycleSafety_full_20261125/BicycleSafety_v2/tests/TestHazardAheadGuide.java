import com.example.bicyclesafety.HazardAheadGuide;
import com.example.bicyclesafety.HazardAheadGuide.State;
import com.example.bicyclesafety.HazardAheadGuide.Voice;

public class TestHazardAheadGuide {
    static int pass, fail;
    static void check(String name, boolean ok) { if (ok) pass++; else { fail++; System.out.println("FAIL " + name); } }

    public static void main(String[] a) {
        // 1000m, 1100m(겹침), 2000m 지점 → 구간 2개
        HazardAheadGuide g = new HazardAheadGuide(new double[]{2000, 1000, 1100}, new int[]{4, 3, 5});
        check("two zones", g.zones().size() == 2);
        check("merged accidents", g.zones().get(0).accidents == 8 && g.zones().get(0).points == 2);
        check("zone start margin", g.zones().get(0).startMeters == 950);

        State s = g.update(500); // 450m 앞
        check("hidden beyond 300", !s.visible && s.voice == Voice.NONE);
        s = g.update(660); // 290m 앞
        check("visible at 290", s.visible && !s.inside);
        check("display ceil 50", s.displayMeters == 300);
        check("far voice", s.voice == Voice.FAR && s.voiceMeters == 250);
        check("far speech", "250미터 앞 사고 다발 구간".equals(HazardAheadGuide.speech(s)));
        s = g.update(700); // 250m
        check("far once", s.voice == Voice.NONE && s.displayMeters == 250);
        s = g.update(745); // 205m
        check("50m steps", s.displayMeters == 250);
        s = g.update(760); // 190m
        check("50m steps 200", s.displayMeters == 200);
        s = g.update(860); // 90m
        check("near voice", s.voice == Voice.NEAR && s.displayMeters == 100);
        s = g.update(880);
        check("near once", s.voice == Voice.NONE);
        s = g.update(1000);
        check("inside", s.inside && s.visible && s.voice == Voice.NONE);
        s = g.update(1140);
        check("still inside merged zone (one voice)", s.inside && s.voice == Voice.NONE);
        s = g.update(1200);
        check("hidden after pass", !s.visible);
        check("passed one zone", g.passedCount() == 1);
        s = g.update(1720); // 230m to second zone (start 1950)
        check("second zone far", s.voice == Voice.FAR && s.voiceMeters == 200 && s.accidents == 4);

        // 시작 지점이 이미 100m 안 → 300m 안내 건너뛰고 NEAR만
        HazardAheadGuide g2 = new HazardAheadGuide(new double[]{120}, new int[]{2});
        s = g2.update(0);
        check("start near skips far", s.voice == Voice.NEAR);
        s = g2.update(10);
        check("no repeat", s.voice == Voice.NONE);

        // 시작부터 구간 안
        HazardAheadGuide g3 = new HazardAheadGuide(new double[]{20}, new int[]{1});
        s = g3.update(0);
        check("start inside speaks once", s.inside && s.voice == Voice.INSIDE);
        s = g3.update(5);
        check("inside no repeat", s.voice == Voice.NONE);

        // 빈 목록
        // 구간에 들어간 적 없이 건너뛴 경우(재탐색 등)는 통과로 세지 않음
        HazardAheadGuide g6 = new HazardAheadGuide(new double[]{500}, new int[]{1});
        g6.update(100);
        g6.update(900);
        check("skipped zone not counted", g6.passedCount() == 0);
        HazardAheadGuide g4 = new HazardAheadGuide(new double[0], new int[0]);
        check("empty", !g4.update(0).visible);
        HazardAheadGuide g5 = new HazardAheadGuide(null, null);
        check("null safe", !g5.update(0).visible);

        System.out.println("HazardAheadGuide: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
