# -*- coding: utf-8 -*-
"""지도/경로/안전경로 비교 정적 회귀 검사: 실제 실기기 실행 확인과 별개."""
from pathlib import Path
root=Path(__file__).parents[1]/'app/src/main/java/com/example'
activity=(root/'bicyclesafety/MainActivity.java').read_text()
repo=(root/'bicyclesafety/KakaoRouteRepository.java').read_text()
safe=(root/'bicyclesafety/SafetyRoutePlanner.java').read_text()
screen=(root/'app/ui/main/MainScreen.kt').read_text()
nav=(root/'app/ui/main/NavigationScreen.kt').read_text()
bridge=(root/'app/ui/BikeUiBridge.kt').read_text()
checks = {
    '사고 데이터 지연 로딩 후 재집계': 'routeHazardsVisible.addAll(hazardsAlongRoute(pendingRoute.points));' in activity and 'updateComparisonUi();' in activity,
    'GPS 업데이트로 위험 마커 다시 그리기': 'refreshHazardMarkers(pendingRoute == null ? null : routeHazardsVisible);' in activity,
    '실제 GPS 출발지': 'onUseCurrentLocationAsOrigin()' in activity and 'originSelected' in bridge,
    # 11/25 변경: '주소만 검색' 전환 대신 장소·주소 통합 검색
    '자동완성 및 장소·주소 통합 조회': 'searchPlacesCombined(' in repo and 'searchPlacesCombined(' in activity and '장소 이름과 주소를 함께 검색' in screen,
    '3종 경로 조회': 'routeBetween' in repo and 'SafetyRoutePlanner.choose(' in activity,
    # 11/25 강화: 위험 지점 맞춤 우회 후보를 실제 카카오 경로로 조회하고 가중 위험 점수로 비교
    '안전 우회 후보 실제 API 조회': 'KakaoRouteRepository.routeBetween(key, from, viaPlace, true)' in safe and 'riskScore(risks, candidate.points)' in safe,
    '미개선 시 동일 경로로 안내': '별도 회피 경로를 찾지 못함' in activity,
    '경로 3종 클릭 비교': 'onSelectRoute: (Int) -> Unit' in screen and 'state.choices.forEach' in nav,
    'GPS 주행 방향 화살표': 'R.drawable.ic_nav_self_arrow' in activity and 'rotateTo(' in activity,
    '내비게이션 상태 및 종료 연결': 'BikeUiBridge.navStarted(' in activity and 'BikeUiBridge.navEnded()' in activity,
}
for name, passed in checks.items():
    assert passed, 'FAIL: ' + name
    print('PASS:',name)
print('PASS: 정적 연결 검사 10개 (실기기 테스트 별도)')
