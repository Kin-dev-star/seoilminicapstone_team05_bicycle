# -*- coding: utf-8 -*-
"""11/25 밤: 백그라운드 안내 · 안전 경로 강화 · 카카오 로그인 · 데이터 틀 정적 검사 (빌드/실행 아님)."""
from pathlib import Path
import xml.etree.ElementTree as ET
base = Path(__file__).resolve().parents[1]
java = base / 'app/src/main/java/com/example/bicyclesafety'
ui = base / 'app/src/main/java/com/example/app/ui'
activity = (java / 'MainActivity.java').read_text(encoding='utf-8')
planner = (java / 'SafetyRoutePlanner.java').read_text(encoding='utf-8')
service = (java / 'NavigationForegroundService.java').read_text(encoding='utf-8')
auth = (java / 'KakaoAuthManager.java').read_text(encoding='utf-8')
app_init = (java / 'MapApplication.java').read_text(encoding='utf-8')
manifest = (base / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
gradle = (base / 'app/build.gradle.kts').read_text(encoding='utf-8')
settings = (base / 'settings.gradle.kts').read_text(encoding='utf-8')
screen = (ui / 'main/MainScreen.kt').read_text(encoding='utf-8')
bridge = (ui / 'BikeUiBridge.kt').read_text(encoding='utf-8')
data = java / 'data'
ET.fromstring(manifest)

checks = {
    # 안전 경로
    '가중 위험 점수': 'public static double riskScore(' in planner and 'weightOf(risk) * proximityFactor(d)' in planner,
    '위험 지점 맞춤 우회 후보(길이 비례 폭)': 'static List<Via> candidateVias(' in planner and 'double[] offsets = offsetsFor(baseDistanceMeters);' in planner,
    '촘촘한 지역 후보 필터 완화(60m)': 'VIA_HAZARD_CLEARANCE_METERS = 60.0' in planner,
    '위험 25% 감소 대안': 'static boolean isSafetyFallback(' in planner,
    '거리 패널티·최대 1.4배': 'METERS_PER_RISK_POINT = 300.0' in planner and 'MAX_DETOUR_RATIO = 1.4' in planner,
    '찍고 오는 경로 제외': 'isOutAndBack(first.points, second.points)' in planner,
    '우회 후보 병렬 조회': 'pool.invokeAll(jobs' in planner,
    '감소율 표시': 'safest.reductionPercent()' in activity and '별도 회피 경로를 찾지 못함' in activity,
    # 백그라운드
    '위치 포그라운드 서비스': 'FOREGROUND_SERVICE_TYPE_LOCATION' in service and 'android:foregroundServiceType="location"' in manifest,
    '권한(FGS·위치·알림)': all(p in manifest for p in ['FOREGROUND_SERVICE"', 'FOREGROUND_SERVICE_LOCATION', 'POST_NOTIFICATIONS']),
    '안내 시작/종료 시 서비스': 'NavigationForegroundService.start(this' in activity and 'NavigationForegroundService.stop(this);' in activity,
    '화면 꺼져도 위치 유지': 'if (!guidanceActive) stopLocationUpdates();' in activity,
    '알림 갱신(10초·안내 변경)': 'updateNavNotification(' in activity,
    '중복 화면 방지(singleTask)': 'android:launchMode="singleTask"' in manifest,
    # 카카오 로그인
    '카카오 SDK 저장소·의존성': 'devrepo.kakao.com/nexus/content/groups/public/' in settings and 'com.kakao.sdk:v2-user:' in gradle,
    '카카오 SDK 초기화': 'KakaoSdk.init(this, BuildConfig.KAKAO_NATIVE_APP_KEY)' in app_init,
    '로그인 리다이렉트 액티비티': 'com.kakao.sdk.auth.AuthCodeHandlerActivity' in manifest and 'kakao${KAKAO_NATIVE_APP_KEY}' in manifest
        and 'manifestPlaceholders["KAKAO_NATIVE_APP_KEY"]' in gradle,
    '카카오톡→계정 로그인 대체·취소 처리': 'loginWithKakaoTalk' in auth and 'loginWithKakaoAccount' in auth and 'ClientErrorCause.Cancelled' in auth,
    '서버 토큰 검증 요청': '"/api/auth/kakao"' in auth and 'SessionStore.save(' in auth,
    '디버그에서만 http 허용': 'android:usesCleartextTraffic="${usesCleartextTraffic}"' in manifest
        and gradle.count('manifestPlaceholders["usesCleartextTraffic"]') == 2,
    '마이페이지 로그인 카드': 'MyPageBody(account, onKakaoLogin, onKakaoLogout)' in screen and '"카카오 로그인"' in screen
        and 'fun accountUpdated(' in bridge,
    # 데이터 틀
    '데이터 모델·저장소 파일': all((data / f).exists() for f in [
        'FavoriteRepository.java', 'RideRecordRepository.java', 'ReportRepository.java', 'AppRepositories.java',
        'LocalFavoriteRepository.java', 'ServerReportRepository.java', 'ApiClient.java', 'SessionStore.java']),
    '주행 기록 자동 저장': 'AppRepositories.rides(this).add(record, null)' in activity,
    '통합 가이드 문서': (base / 'docs/TEAM_INTEGRATION_GUIDE.md').exists(),
}
for name, ok in checks.items():
    assert ok, 'FAIL: ' + name
    print('PASS:', name)
print(f'PASS: {len(checks)} background/safety/login checks')
