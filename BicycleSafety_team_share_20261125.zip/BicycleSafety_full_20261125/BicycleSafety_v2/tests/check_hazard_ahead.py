"""사고 다발 구간 앞 안내(위젯·음성) 정적 연결 검사."""
import pathlib
root = pathlib.Path(__file__).resolve().parents[1]
J = root / 'app/src/main/java/com/example/bicyclesafety'
main = (J / 'MainActivity.java').read_text(encoding='utf-8')
guide = (J / 'HazardAheadGuide.java').read_text(encoding='utf-8')
bridge = (root / 'app/src/main/java/com/example/app/ui/BikeUiBridge.kt').read_text(encoding='utf-8')
nav = (root / 'app/src/main/java/com/example/app/ui/main/NavigationScreen.kt').read_text(encoding='utf-8')
checks = {
    '300m 표시·100m 음성·50m 단위': 'SHOW_METERS = 300' in guide and 'NEAR_METERS = 100' in guide and 'STEP_METERS = 50' in guide,
    '겹치는 위험지점 한 구간으로': 'MERGE_GAP_METERS = 150' in guide,
    '안내 시작 시 구간 생성': main.count('rebuildHazardAhead();') >= 2,
    '안내 종료 시 초기화': 'hazardAhead = null;' in main,
    '회전 안내 여부 반환': 'private boolean announceGuidance(' in main and 'boolean turnSpoken = announceGuidance(snap, steps);' in main,
    '회전 먼저 + 1초 쉬고 위험 안내': 'playSilentUtterance(1000, TextToSpeech.QUEUE_ADD' in main,
    '안내 중 반경 경고 끔': 'riskWarningGate.reset()' in main,
    '브리지 상태': 'fun navHazard(text: String?, inside: Boolean, accidents: Int)' in bridge and 'val hazardAhead: String? = null' in bridge,
    '화면 위젯': 'private fun HazardAheadCard(' in nav and 'state.hazardAhead?.let' in nav,
    '안전 우선 진단 문구': 'private static String safetyNote(' in main and '별도 회피 경로를 찾지 못함 · 기존 경로와 동일' in main,
}
for name, ok in checks.items():
    if not ok:
        raise AssertionError('FAIL: ' + name)
print(f'PASS: {len(checks)} hazard-ahead checks')
