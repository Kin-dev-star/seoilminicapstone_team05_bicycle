# -*- coding: utf-8 -*-
"""11/25 수정본: 지도 줌 제한 · Crossfade 제거 · 시작 진단 로그 정적 검사 (빌드/실행 아님)."""
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/example'
activity = (root / 'bicyclesafety/MainActivity.java').read_text(encoding='utf-8')
app = (root / 'app/ui/BikeApp.kt').read_text(encoding='utf-8')
checks = {
    '지도 줌 10~18 제한 상수': 'MIN_CAMERA_LEVEL = 10' in activity and 'MAX_CAMERA_LEVEL = 18' in activity,
    '지도 준비 시 줌 제한 적용': 'applyCameraZoomLimits(kakaoMap);' in activity
        and 'kakaoMap.setCameraMinLevel(min);' in activity and 'kakaoMap.setCameraMaxLevel(max);' in activity,
    '안내 줌(17)·기본 줌(15)이 제한 범위 안': 'NAV_ZOOM = 17;' in activity and 'moveCameraToLocation(location, 15);' in activity,
    'Crossfade 제거': 'Crossfade(targetState' not in app and 'import androidx.compose.animation.Crossfade' not in app and 'if (showMain) {' in app,
    'Compose 시작 로그': 'Compose screen=' in app and 'BicycleSafetyStartup' in app,
    'Activity 시작 단계 로그': all(f'"{n}. ' in activity for n in range(1, 7)) and 'BicycleSafetyStartup' in activity,
}
for name, ok in checks.items():
    assert ok, 'FAIL: ' + name
    print('PASS:', name)
print(f'PASS: {len(checks)} startup/zoom checks')
