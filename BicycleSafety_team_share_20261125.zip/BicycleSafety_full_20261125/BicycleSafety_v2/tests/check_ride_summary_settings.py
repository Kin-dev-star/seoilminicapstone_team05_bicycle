"""주행 요약 카드 · 사고 다발 구간 통과 수 · 실제 설정 연결 정적 검사."""
import pathlib
root = pathlib.Path(__file__).resolve().parents[1]
J = root / 'app/src/main/java/com/example/bicyclesafety'
main = (J / 'MainActivity.java').read_text(encoding='utf-8')
prefs = (J / 'AppPrefs.java').read_text(encoding='utf-8')
record = (J / 'data/RideRecord.java').read_text(encoding='utf-8')
codec = (J / 'data/JsonCodec.java').read_text(encoding='utf-8')
guide = (J / 'HazardAheadGuide.java').read_text(encoding='utf-8')
bridge = (root / 'app/src/main/java/com/example/app/ui/BikeUiBridge.kt').read_text(encoding='utf-8')
ui = (root / 'app/src/main/java/com/example/app/ui/main/MainScreen.kt').read_text(encoding='utf-8')
checks = {
    '통과 구간 수 계산': 'public int passedCount()' in guide and 'if (z.entered) z.passed = true;' in guide,
    '재탐색해도 누적': 'rideZonesPassedBase += hazardAhead.passedCount();' in main,
    '기록에 저장(예전 생성자 유지)': 'public final int hazardZonesPassed;' in record and record.count('public RideRecord(') == 2,
    'JSON 필드': '"hazardZonesPassed"' in codec,
    '주행 요약 카드': 'BikeUiBridge.rideFinished(' in main and 'private fun RideFinishedDialog(' in bridge and 'RideFinishedDialog(ride = ride' in bridge,
    '시뮬레이션은 저장 안 함': 'if (!simulated) {' in main,
    '음성 안내 설정 연결': main.count('if (!AppPrefs.voiceGuide(this)) return;') == 2,
    '화면 꺼짐 방지 연결': 'private void applyKeepScreenOn()' in main and 'AppPrefs.keepScreenOn(this)' in main,
    '자전거도로 오버레이 연결': 'activeMap.showOverlay(MapOverlay.BICYCLE_ROAD)' in main and 'activeMap.hideOverlay(MapOverlay.BICYCLE_ROAD)' in main,
    '설정 변경 즉시 반영': 'registerOnSharedPreferenceChangeListener(settingsListener)' in main and 'unregisterOnSharedPreferenceChangeListener(settingsListener)' in main,
    '설정 저장': 'AppPrefs.set(context, AppPrefs.VOICE_GUIDE, value)' in ui and 'BIKE_LANES = "bike_lanes"' in prefs,
    '가짜 스위치 제거': all(k not in ui for k in ['자동 일시정지', '공공자전거 대여소 표시', 'listOf("km", "mi")', '(시연용)']),
    '중복 로그아웃 줄 제거': 'MenuRow("로그아웃"' not in ui,
}
for name, ok in checks.items():
    if not ok:
        raise AssertionError('FAIL: ' + name)
print(f'PASS: {len(checks)} ride summary/settings checks')
