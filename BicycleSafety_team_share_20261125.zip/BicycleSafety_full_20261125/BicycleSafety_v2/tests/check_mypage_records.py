"""마이페이지 주행 기록 정적 연결 검사."""
import pathlib
root = pathlib.Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/com/example/app/ui/main/MainScreen.kt').read_text(encoding='utf-8')
summary = (root / 'app/src/main/java/com/example/bicyclesafety/data/RideSummary.java').read_text(encoding='utf-8')
checks = {
    '주행 목표 삭제': '주행 목표' not in ui,
    '예시 데이터 제거': '"128.4"' not in ui and '한강 자전거길' not in ui,
    '실제 기록 연결': 'AppRepositories.rides(context).recent(200' in ui,
    '주간/월간 전환': 'listOf("주간", "월간")' in ui,
    '지난 기간 같은 시점 비교': 'prevSamePoint' in summary and '이맘때보다' in ui,
    '날짜별 막대': 'private fun DailyBars(' in ui,
    '평균 속도·최장·탄 날·CO2': all(k in ui for k in ['"평균 속도"', '"최장 거리"', '"탄 날"', '"CO₂ 절감"']),
    '안전 우선 이용 횟수': '안전 우선 ${summary.safeRouteCount}회' in ui and 'safeRouteCount' in summary and 'hazardZonesPassed' in summary,
    '최근 주행 실제 5건': 'rides.orEmpty().take(5)' in ui,
}
for name, ok in checks.items():
    if not ok:
        raise AssertionError('FAIL: ' + name)
print(f'PASS: {len(checks)} mypage record checks')
