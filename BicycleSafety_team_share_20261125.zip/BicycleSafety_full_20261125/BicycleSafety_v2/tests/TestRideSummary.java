import com.example.bicyclesafety.data.RideRecord;
import com.example.bicyclesafety.data.RideSummary;
import java.util.*;

public class TestRideSummary {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else { fail++; System.out.println("FAIL " + n); } }
    static long at(int y, int m, int d, int h) { Calendar c = Calendar.getInstance(); c.clear(); c.set(y, m - 1, d, h, 0, 0); return c.getTimeInMillis(); }
    static RideRecord ride(long start, int meters, int sec, int mode, boolean arrived) {
        return new RideRecord("x", start, start + sec * 1000L, meters, sec, "A", "B", mode, arrived);
    }
    public static void main(String[] a) {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Seoul"));
        long now = at(2026, 11, 25, 23); // 수요일
        List<RideRecord> r = new ArrayList<>();
        r.add(new RideRecord("z", at(2026, 11, 25, 8), at(2026, 11, 25, 8) + 1860000L, 8200, 1860, "A", "B", 0, true, 3)); // 이번 주 수, 구간 3곳
        r.add(ride(at(2026, 11, 24, 18), 12000, 2700, 2, true)); // 이번 주 화
        r.add(ride(at(2026, 11, 24, 7), 3000, 900, 0, false));   // 같은 날 두 번
        r.add(ride(at(2026, 11, 3, 9), 20000, 4800, 1, true));   // 이번 달, 지난주 아님
        r.add(ride(at(2026, 11, 18, 9), 5000, 1200, 0, true));   // 지난주 수 9시 (같은 시점 이전)
        r.add(ride(at(2026, 11, 19, 9), 7000, 1200, 0, true));   // 지난주 목 (같은 시점 이후 → 비교 제외)
        r.add(ride(at(2026, 10, 10, 9), 9000, 1800, 0, true));   // 지난달 10일
        r.add(ride(at(2026, 10, 28, 9), 4000, 1800, 0, true));   // 지난달 28일 (25일 23시 이후 → 제외)

        RideSummary w = RideSummary.of(r, RideSummary.Period.WEEK, now);
        check("week count", w.count == 3);
        check("week distance", w.distanceMeters == 23200);
        check("week 7 bars", w.dailyKm.length == 7 && w.todayIndex == 2);
        check("tue bar", Math.abs(w.dailyKm[1] - 15.0f) < 1e-4);
        check("wed bar", Math.abs(w.dailyKm[2] - 8.2f) < 1e-4);
        check("active days", w.activeDays == 2);
        check("longest", w.longestMeters == 12000);
        check("safe count", w.safeRouteCount == 2);
        check("arrived", w.arrivedCount == 2);
        check("prev same point", w.previousDistanceMeters == 5000);
        check("zones passed", w.hazardZonesPassed == 3);
        check("change", w.distanceChangeMeters() == 18200);
        double avg = w.averageSpeedKmh();
        check("avg speed", Math.abs(avg - 23.2 / (5460 / 3600.0)) < 1e-6);

        RideSummary m = RideSummary.of(r, RideSummary.Period.MONTH, now);
        check("month days", m.dailyKm.length == 30 && m.todayIndex == 24);
        check("month count", m.count == 6);
        check("month distance", m.distanceMeters == 55200);
        check("month prev same point", m.previousDistanceMeters == 9000);
        check("co2", Math.abs(m.co2SavedKg() - 55.2 * 0.1475) < 1e-9);
        check("day 3 bar", Math.abs(m.dailyKm[2] - 20f) < 1e-4);

        RideSummary e = RideSummary.of(new ArrayList<>(), RideSummary.Period.MONTH, now);
        check("empty", e.count == 0 && e.averageSpeedKmh() == 0 && e.activeDays == 0);
        check("null safe", RideSummary.of(null, RideSummary.Period.WEEK, now).count == 0);

        // 3월 31일: 지난달(2월) 비교 시점이 2월 말을 넘지 않음
        List<RideRecord> r2 = new ArrayList<>();
        r2.add(ride(at(2026, 2, 27, 9), 6000, 1200, 0, true));
        r2.add(ride(at(2026, 3, 2, 9), 1000, 300, 0, true));
        RideSummary mar = RideSummary.of(r2, RideSummary.Period.MONTH, at(2026, 3, 31, 20));
        check("march prev", mar.previousDistanceMeters == 6000 && mar.distanceMeters == 1000);
        // 일요일 밤: 이번 주 마지막 칸
        RideSummary sun = RideSummary.of(r, RideSummary.Period.WEEK, at(2026, 11, 29, 22));
        check("sunday index", sun.todayIndex == 6 && sun.count == 3);

        System.out.println("RideSummary: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
