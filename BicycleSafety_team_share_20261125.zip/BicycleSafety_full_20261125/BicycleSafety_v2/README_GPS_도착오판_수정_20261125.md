# GPS 정확도 / 주행 안내 자동 종료 오판 수정

기준: BicycleSafety_v2_경로창_스와이프_펼침접힘_수정_20261125.zip

## 바뀐 파일 (2개)
- `app/src/main/java/com/example/bicyclesafety/MainActivity.java`
- `app/src/main/java/com/example/bicyclesafety/NavigationGpsGuard.java` (신규)

## 변경사항
- 위치 오차가 큰 좌표(주행 중 35m 초과, 일반 지도 50m 초과), 수신 시각이 오래된 좌표, 짧은 시간의 비현실적 위치 점프를 위치 마커/지도 카메라/주행 계산에 반영하지 않음
- GPS 상태가 나쁘면 길 안내를 유지하면서 `GPS 정확도 낮음 · 경로 안내 유지 중` 안내를 1회 표시
- 자동 도착 종료는 실제 목적지 25m 이내, 경로의 끝 25m 이내, 경로선과 25m 이내, GPS 정확도 20m 이내가 **서로 다른 정상 측정치 3회 연속** 확인될 때만 발생
- 수동 `안내 종료` 기능과 기존 경로/UI/위험지역 기능은 유지

## 주의
- GPS 품질 기준은 실내에서 충족되지 않을 수 있음. 실외에서 테스트 권장
- GPS가 약한 상태에서는 주행 모드가 유지되지만 위치 갱신이 일시 중지됨
- Android SDK/Gradle 전체 빌드와 실기기 실행까지 검증한 것은 아님
- `local.properties` API 키는 각자 기존 파일을 사용, GitHub 등에 공유하지 말 것

## 확인 순서
1. Android Studio에서 새 프로젝트 열어 Gradle Sync → Build → 갤럭시 실행
2. GPS가 불안정해도 지도/주행 안내가 임의 종료되지 않는지 확인
3. 실외 GPS 신호가 안정되면 위치 화살표·지도 추적 확인
4. 목적지 근처에서 서로 다른 측정치 3회 이상 수신할 때만 자동 안내 종료 확인
