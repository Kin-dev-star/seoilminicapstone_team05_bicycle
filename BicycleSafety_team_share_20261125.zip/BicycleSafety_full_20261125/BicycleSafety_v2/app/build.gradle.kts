import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
}

// Read local.properties on the developer's machine only. Never commit the REST API key.
val localProps = Properties()
val localFile = rootProject.file("local.properties")
if (localFile.exists()) localFile.inputStream().use { localProps.load(it) }
val restKey = (localProps.getProperty("KAKAO_REST_API_KEY") ?: "").trim()
val nativeMapKey = (localProps.getProperty("KAKAO_NATIVE_APP_KEY") ?: "").trim()
val safeNativeKey = nativeMapKey.replace("\\", "\\\\").replace("\"", "\\\"")
val teamHazardUrl = (localProps.getProperty("TEAM_HAZARD_API_URL") ?: "").trim()
val safeTeamUrl = teamHazardUrl.replace("\\", "\\\\").replace("\"", "\\\"")
val safeRestKey = restKey.replace("\\", "\\\\").replace("\"", "\\\"")
// 팀 서버 주소 (예: http://192.168.0.10:8088). 카카오 로그인 서버 검증·사고 데이터·마이페이지 API에 사용
val teamApiBaseUrl = (localProps.getProperty("TEAM_API_BASE_URL") ?: "").trim()
val safeTeamApiBaseUrl = teamApiBaseUrl.replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.example.bicyclesafety"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.bicyclesafety"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "KAKAO_REST_API_KEY", "\"$safeRestKey\"")
        buildConfigField("String", "KAKAO_NATIVE_APP_KEY", "\"$safeNativeKey\"")
        buildConfigField("String", "TEAM_HAZARD_API_URL", "\"$safeTeamUrl\"")
        buildConfigField("String", "TEAM_API_BASE_URL", "\"$safeTeamApiBaseUrl\"")
        // 카카오 로그인 리다이렉트 스킴 kakao{네이티브 앱 키}://oauth
        manifestPlaceholders["KAKAO_NATIVE_APP_KEY"] = nativeMapKey
        ndk {
            abiFilters += "arm64-v8a"
        }

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug {
            // 학교·집 같은 와이파이에서 PC 서버(http://IP:8088)에 접속하는 테스트용. 배포 버전은 HTTPS만 허용
            manifestPlaceholders["usesCleartextTraffic"] = "true"
        }
        release {
            manifestPlaceholders["usesCleartextTraffic"] = "false"
            optimization {
                enable = false
            }
        }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Design team Compose export (Java activity and native KakaoMap are retained).
    implementation(platform("androidx.compose:compose-bom:2026.08.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.13.0")

    implementation("com.kakao.maps.open:android:2.15.2")
    // 빠른 현재 위치: GPS + Wi-Fi + 기지국을 함께 쓰는 Google Fused 위치 (Play 서비스 없으면 기본 GPS로 자동 대체)
    implementation("com.google.android.gms:play-services-location:21.3.0")
    // 카카오 로그인 (최신 버전은 developers.kakao.com/docs/ko/android/download 에서 확인 후 올려도 됨)
    implementation("com.kakao.sdk:v2-user:2.21.2")
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
}
