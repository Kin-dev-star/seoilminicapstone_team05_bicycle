package com.example.bicyclesafety.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 서버 주행 기록 (API 규격: docs/TEAM_INTEGRATION_GUIDE.md) */
public final class ServerRideRecordRepository implements RideRecordRepository {
    private final String session;

    public ServerRideRecordRepository(String sessionToken) { this.session = sessionToken; }

    @Override
    public void add(RideRecord record, ResultCallback<RideRecord> callback) {
        DataExecutors.run(() -> JsonCodec.ride(
                ApiClient.request("POST", "/api/rides", JsonCodec.ride(record), session)
                        .getJSONObject("item")), callback);
    }

    @Override
    public void recent(int limit, ResultCallback<List<RideRecord>> callback) {
        DataExecutors.run(() -> fetch(limit), callback);
    }

    @Override
    public void statsSince(long fromMillis, ResultCallback<RideStats> callback) {
        DataExecutors.run(() -> RideStats.since(fetch(200), fromMillis), callback);
    }

    private List<RideRecord> fetch(int limit) throws Exception {
        JSONArray items = ApiClient.request("GET", "/api/rides?limit=" + Math.max(1, limit), null, session)
                .optJSONArray("items");
        List<RideRecord> out = new ArrayList<>();
        if (items != null) for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o != null) out.add(JsonCodec.ride(o));
        }
        return out;
    }
}
