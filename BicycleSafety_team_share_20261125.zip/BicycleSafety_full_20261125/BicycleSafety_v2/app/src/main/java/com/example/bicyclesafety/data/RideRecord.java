package com.example.bicyclesafety.data;

/** 주행 기록 1건. 길 안내를 마치면 MainActivity가 자동으로 저장합니다. */
public final class RideRecord {
    public final String id;
    public final long startedAt;
    public final long endedAt;
    /** GPS로 실제 이동한 거리(m) */
    public final int distanceMeters;
    public final int durationSeconds;
    public final String originName;
    public final String destinationName;
    /** 0 안전 우선 / 1 최단 / 2 자전거도로 우선 */
    public final int routeMode;
    /** 목적지 도착으로 끝났는지 (false = 중간 종료) */
    public final boolean arrived;
    /** 주행 중 지나간 사고 다발 구간 수 (없으면 0, 예전 기록도 0) */
    public final int hazardZonesPassed;

    public RideRecord(String id, long startedAt, long endedAt, int distanceMeters, int durationSeconds,
                      String originName, String destinationName, int routeMode, boolean arrived) {
        this(id, startedAt, endedAt, distanceMeters, durationSeconds, originName, destinationName,
                routeMode, arrived, 0);
    }

    public RideRecord(String id, long startedAt, long endedAt, int distanceMeters, int durationSeconds,
                      String originName, String destinationName, int routeMode, boolean arrived,
                      int hazardZonesPassed) {
        this.id = id == null ? "" : id;
        this.startedAt = startedAt;
        this.endedAt = endedAt;
        this.distanceMeters = Math.max(0, distanceMeters);
        this.durationSeconds = Math.max(0, durationSeconds);
        this.originName = originName == null ? "" : originName;
        this.destinationName = destinationName == null ? "" : destinationName;
        this.routeMode = routeMode;
        this.arrived = arrived;
        this.hazardZonesPassed = Math.max(0, hazardZonesPassed);
    }
}
