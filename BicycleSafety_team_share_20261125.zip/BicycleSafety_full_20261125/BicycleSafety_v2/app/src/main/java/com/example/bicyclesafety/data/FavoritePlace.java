package com.example.bicyclesafety.data;

/** 즐겨찾기 장소 (집·회사·기타). 마이페이지·경로 설정창 즐겨찾기 타일에서 사용 */
public final class FavoritePlace {
    public static final String TYPE_HOME = "HOME";
    public static final String TYPE_WORK = "WORK";
    public static final String TYPE_OTHER = "OTHER";

    /** 서버/로컬 식별자 (새로 만들 때는 빈 문자열) */
    public final String id;
    /** HOME / WORK / OTHER */
    public final String type;
    /** 화면 표시 이름 (예: 집, 회사, 학교) */
    public final String label;
    /** 장소 이름 (카카오 검색 결과 place_name) */
    public final String placeName;
    public final String address;
    public final double latitude;
    public final double longitude;

    public FavoritePlace(String id, String type, String label, String placeName, String address,
                         double latitude, double longitude) {
        this.id = id == null ? "" : id;
        this.type = type == null ? TYPE_OTHER : type;
        this.label = label == null ? "" : label;
        this.placeName = placeName == null ? "" : placeName;
        this.address = address == null ? "" : address;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
