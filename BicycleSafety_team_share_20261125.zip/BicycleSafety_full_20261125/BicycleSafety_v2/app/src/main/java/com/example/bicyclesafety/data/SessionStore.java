package com.example.bicyclesafety.data;

import android.content.Context;
import android.content.SharedPreferences;

/** 로그인 세션을 휴대폰에 저장 (앱 전용 저장소, 백업 제외: AndroidManifest allowBackup=false) */
public final class SessionStore {
    private SessionStore() {}
    private static final String PREFS = "auth_session";

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** 저장된 세션 (없거나 만료면 null) */
    public static UserSession load(Context context) {
        SharedPreferences p = prefs(context);
        if (!p.contains("kakaoId")) return null;
        UserSession s = new UserSession(p.getLong("kakaoId", 0), p.getString("nickname", ""),
                p.getString("sessionToken", ""), p.getBoolean("verified", false), p.getLong("expiresAt", 0));
        if (s.isExpired()) { clear(context); return null; }
        return s;
    }

    public static void save(Context context, UserSession s) {
        prefs(context).edit()
                .putLong("kakaoId", s.kakaoId)
                .putString("nickname", s.nickname)
                .putString("sessionToken", s.sessionToken)
                .putBoolean("verified", s.serverVerified)
                .putLong("expiresAt", s.expiresAt)
                .apply();
    }

    public static void clear(Context context) {
        prefs(context).edit().clear().apply();
    }
}
