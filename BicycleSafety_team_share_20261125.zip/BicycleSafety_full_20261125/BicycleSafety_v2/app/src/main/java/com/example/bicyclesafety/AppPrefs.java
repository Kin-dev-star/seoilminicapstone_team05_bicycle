package com.example.bicyclesafety;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 설정 화면 값 (휴대폰에 저장). 설정 화면(AppSettings)이 쓰고, MainActivity가 읽습니다.
 * MainActivity는 값이 바뀌면 바로 반영하려고 OnSharedPreferenceChangeListener를 등록합니다.
 */
public final class AppPrefs {
    private AppPrefs() { }

    public static final String FILE = "app_settings";
    /** 회전·사고 다발 구간 음성 안내 */
    public static final String VOICE_GUIDE = "voice_guide";
    /** 길 안내 중 화면 켜 두기 */
    public static final String KEEP_SCREEN_ON = "keep_screen_on";
    /** 지도에 카카오 자전거도로 선 표시 */
    public static final String BIKE_LANES = "bike_lanes";

    public static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean voiceGuide(Context context) { return prefs(context).getBoolean(VOICE_GUIDE, true); }

    public static boolean keepScreenOn(Context context) { return prefs(context).getBoolean(KEEP_SCREEN_ON, true); }

    public static boolean bikeLanes(Context context) { return prefs(context).getBoolean(BIKE_LANES, true); }

    public static void set(Context context, String key, boolean value) {
        prefs(context).edit().putBoolean(key, value).apply();
    }
}
