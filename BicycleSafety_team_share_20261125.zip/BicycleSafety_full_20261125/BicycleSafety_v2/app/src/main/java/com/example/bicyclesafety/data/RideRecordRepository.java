package com.example.bicyclesafety.data;

import java.util.List;

/** 주행 기록 저장소. 기록 추가는 앱(길 안내 종료 시)이 하고, 마이페이지는 조회만 합니다. */
public interface RideRecordRepository {
    void add(RideRecord record, ResultCallback<RideRecord> callback);
    /** 최신순 limit개 */
    void recent(int limit, ResultCallback<List<RideRecord>> callback);
    /** fromMillis 이후 통계 (RideStats.startOfThisWeek(), startOfThisMonth() 사용) */
    void statsSince(long fromMillis, ResultCallback<RideStats> callback);
}
