package com.example.bicyclesafety.data;

import java.util.Calendar;
import java.util.List;

/**
 * 마이페이지 '주행 기록' 요약 (이번 주 / 이번 달). 안드로이드 의존성 없음 → 단위 테스트 가능.
 *
 * 자전거 이용자가 많이 보는 값 위주: 총 거리, 횟수, 시간, 평균 속도, 최장 거리, 탄 날 수,
 * 지난 기간 같은 시점 대비 거리, 날짜별 거리 막대, 안전 우선 경로 이용 횟수, CO₂ 절감 추정.
 */
public final class RideSummary {

    public enum Period { WEEK, MONTH }

    /**
     * 승용차 1인이 1km 이동할 때 온실가스 (kg). 서울연구원(2018) 보고서의 2016년 서울 기준 승용차 147.5g.
     * '자전거 대신 승용차를 탔다면'으로 가정한 추정치입니다.
     */
    public static final double CAR_CO2_KG_PER_KM = 0.1475;

    public final Period period;
    public int count;
    public int distanceMeters;
    public int durationSeconds;
    public int longestMeters;
    /** 하루라도 탄 날 수 */
    public int activeDays;
    /** 안전 우선(routeMode 0) 경로로 탄 횟수 */
    public int safeRouteCount;
    /** 목적지 도착으로 끝난 횟수 */
    public int arrivedCount;
    /** 지나간 사고 다발 구간 수 합계 */
    public int hazardZonesPassed;
    /** 지난주/지난달의 '같은 시점까지' 거리 (공정 비교) */
    public int previousDistanceMeters;
    /** 날짜별 거리 km (주: 월~일 7칸, 달: 1일~말일) */
    public final float[] dailyKm;
    /** 오늘 칸 번호 */
    public final int todayIndex;

    private RideSummary(Period period, int days, int todayIndex) {
        this.period = period;
        this.dailyKm = new float[days];
        this.todayIndex = todayIndex;
    }

    /** 평균 속도 km/h (주행 시간 1분 미만이면 0) */
    public double averageSpeedKmh() {
        if (durationSeconds < 60) return 0;
        return distanceMeters / 1000.0 / (durationSeconds / 3600.0);
    }

    public double co2SavedKg() {
        return distanceMeters / 1000.0 * CAR_CO2_KG_PER_KM;
    }

    /** 지난 기간 같은 시점 대비 거리 차이 (m, 음수면 덜 탐) */
    public int distanceChangeMeters() {
        return distanceMeters - previousDistanceMeters;
    }

    public static RideSummary of(List<RideRecord> records, Period period, long nowMillis) {
        Calendar start = Calendar.getInstance();
        start.setTimeInMillis(nowMillis);
        start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0);
        start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
        int days;
        if (period == Period.WEEK) {
            // 월요일 시작
            int dow = start.get(Calendar.DAY_OF_WEEK); // 일=1 … 토=7
            int back = (dow + 5) % 7;                    // 월=0 … 일=6
            start.add(Calendar.DAY_OF_MONTH, -back);
            days = 7;
        } else {
            start.set(Calendar.DAY_OF_MONTH, 1);
            days = start.getActualMaximum(Calendar.DAY_OF_MONTH);
        }
        long periodStart = start.getTimeInMillis();
        Calendar prev = (Calendar) start.clone();
        if (period == Period.WEEK) prev.add(Calendar.DAY_OF_MONTH, -7); else prev.add(Calendar.MONTH, -1);
        long prevStart = prev.getTimeInMillis();
        long prevSamePoint = prevStart + (nowMillis - periodStart);
        // 지난달이 더 짧은 경우(예: 3월 31일 ↔ 2월) 지난 기간 끝을 넘지 않게
        long prevEnd = periodStart;
        if (prevSamePoint > prevEnd) prevSamePoint = prevEnd;

        int today = dayIndex(periodStart, nowMillis, days);
        RideSummary s = new RideSummary(period, days, today);
        boolean[] rode = new boolean[days];
        if (records == null) return s;
        for (RideRecord r : records) {
            if (r == null) continue;
            if (r.startedAt >= periodStart && r.startedAt <= nowMillis) {
                s.count++;
                s.distanceMeters += r.distanceMeters;
                s.durationSeconds += r.durationSeconds;
                s.longestMeters = Math.max(s.longestMeters, r.distanceMeters);
                if (r.routeMode == 0) s.safeRouteCount++;
                if (r.arrived) s.arrivedCount++;
                s.hazardZonesPassed += r.hazardZonesPassed;
                int d = dayIndex(periodStart, r.startedAt, days);
                if (d >= 0) {
                    s.dailyKm[d] += r.distanceMeters / 1000f;
                    rode[d] = true;
                }
            } else if (r.startedAt >= prevStart && r.startedAt < prevSamePoint) {
                s.previousDistanceMeters += r.distanceMeters;
            }
        }
        for (boolean b : rode) if (b) s.activeDays++;
        return s;
    }

    /** 기간 시작부터 며칠째인지 (서머타임 없는 한국 기준이지만 달력으로 계산해 안전하게) */
    private static int dayIndex(long periodStart, long time, int days) {
        if (time < periodStart) return -1;
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(periodStart);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(time);
        int index = 0;
        while (index < days) {
            Calendar next = (Calendar) a.clone();
            next.add(Calendar.DAY_OF_MONTH, 1);
            if (b.before(next)) return index;
            a = next;
            index++;
        }
        return -1;
    }
}
