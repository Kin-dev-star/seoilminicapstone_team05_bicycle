package com.example.bicyclesafety.data;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 저장소 작업은 백그라운드 스레드에서, 결과 콜백은 메인 스레드에서 실행 */
final class DataExecutors {
    private DataExecutors() {}

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    interface Work<T> { T run() throws Exception; }

    static <T> void run(Work<T> work, ResultCallback<T> callback) {
        IO.execute(() -> {
            try {
                T result = work.run();
                if (callback != null) MAIN.post(() -> callback.onSuccess(result));
            } catch (Exception error) {
                String message = error.getMessage() == null ? "처리 중 오류가 발생했습니다." : error.getMessage();
                if (callback != null) MAIN.post(() -> callback.onError(message));
            }
        });
    }
}
