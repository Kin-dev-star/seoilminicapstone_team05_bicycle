package com.example.bicyclesafety.data;

import org.json.JSONException;
import org.json.JSONObject;

/** 모델 ↔ JSON 변환. 로컬 저장과 서버 API가 같은 필드 이름을 씁니다 (docs/TEAM_INTEGRATION_GUIDE.md 참고). */
public final class JsonCodec {
    private JsonCodec() {}

    public static JSONObject favorite(FavoritePlace p) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", p.id); o.put("type", p.type); o.put("label", p.label);
        o.put("placeName", p.placeName); o.put("address", p.address);
        o.put("latitude", p.latitude); o.put("longitude", p.longitude);
        return o;
    }

    public static FavoritePlace favorite(JSONObject o) {
        return new FavoritePlace(o.optString("id", ""), o.optString("type", FavoritePlace.TYPE_OTHER),
                o.optString("label", ""), o.optString("placeName", ""), o.optString("address", ""),
                o.optDouble("latitude", 0), o.optDouble("longitude", 0));
    }

    public static JSONObject ride(RideRecord r) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", r.id); o.put("startedAt", r.startedAt); o.put("endedAt", r.endedAt);
        o.put("distanceMeters", r.distanceMeters); o.put("durationSeconds", r.durationSeconds);
        o.put("originName", r.originName); o.put("destinationName", r.destinationName);
        o.put("routeMode", r.routeMode); o.put("arrived", r.arrived);
        o.put("hazardZonesPassed", r.hazardZonesPassed);
        return o;
    }

    public static RideRecord ride(JSONObject o) {
        return new RideRecord(o.optString("id", ""), o.optLong("startedAt", 0), o.optLong("endedAt", 0),
                o.optInt("distanceMeters", 0), o.optInt("durationSeconds", 0),
                o.optString("originName", ""), o.optString("destinationName", ""),
                o.optInt("routeMode", 2), o.optBoolean("arrived", false),
                o.optInt("hazardZonesPassed", 0));
    }

    public static JSONObject report(HazardReport r) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", r.id); o.put("title", r.title); o.put("content", r.content);
        o.put("placeName", r.placeName); o.put("latitude", r.latitude); o.put("longitude", r.longitude);
        o.put("authorNickname", r.authorNickname); o.put("createdAt", r.createdAt);
        return o;
    }

    public static HazardReport report(JSONObject o) {
        return new HazardReport(o.optString("id", ""), o.optString("title", ""), o.optString("content", ""),
                o.optString("placeName", ""), o.optDouble("latitude", 0), o.optDouble("longitude", 0),
                o.optString("authorNickname", ""), o.optLong("createdAt", 0));
    }
}
