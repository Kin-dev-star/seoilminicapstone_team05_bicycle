package com.example.bicyclesafety;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 최근 경로(최대 5개)를 휴대폰 안(SharedPreferences)에 저장합니다.
 * 서버·계정과 무관한 기기 로컬 기록이며, 카카오 로그인/DB 연동 시 서버 저장으로 옮길 수 있습니다.
 */
public final class RecentRouteStore {
    private RecentRouteStore() {}

    public static final int MAX_ITEMS = 5;
    private static final String PREFS = "recent_routes";
    private static final String KEY_ITEMS = "items";
    /** 같은 장소로 보는 좌표 차이 (약 30m) */
    private static final double SAME_PLACE_DEGREES = 0.0003;

    public static final class Entry {
        public final String originName;
        /** 출발지가 '현재 위치(GPS)'였는지. 다시 검색할 때는 그때의 현재 위치를 사용 */
        public final boolean originGps;
        public final double originLatitude;
        public final double originLongitude;
        public final String destinationName;
        public final double destinationLatitude;
        public final double destinationLongitude;
        public final long savedAt;

        public Entry(String originName, boolean originGps, double originLatitude, double originLongitude,
                     String destinationName, double destinationLatitude, double destinationLongitude,
                     long savedAt) {
            this.originName = originName == null ? "" : originName;
            this.originGps = originGps;
            this.originLatitude = originLatitude;
            this.originLongitude = originLongitude;
            this.destinationName = destinationName == null ? "" : destinationName;
            this.destinationLatitude = destinationLatitude;
            this.destinationLongitude = destinationLongitude;
            this.savedAt = savedAt;
        }

        boolean sameRoute(Entry other) {
            boolean sameDestination = near(destinationLatitude, other.destinationLatitude)
                    && near(destinationLongitude, other.destinationLongitude);
            boolean sameOrigin = originGps && other.originGps
                    || (!originGps && !other.originGps
                        && near(originLatitude, other.originLatitude)
                        && near(originLongitude, other.originLongitude));
            return sameDestination && sameOrigin;
        }
    }

    private static boolean near(double a, double b) {
        return Math.abs(a - b) < SAME_PLACE_DEGREES;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<Entry> load(Context context) {
        List<Entry> items = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs(context).getString(KEY_ITEMS, "[]"));
            for (int i = 0; i < array.length() && items.size() < MAX_ITEMS; i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                items.add(new Entry(
                        o.optString("originName", "현재 위치"), o.optBoolean("originGps", true),
                        o.optDouble("originLat", 0), o.optDouble("originLng", 0),
                        o.optString("destName", ""),
                        o.optDouble("destLat", 0), o.optDouble("destLng", 0),
                        o.optLong("savedAt", 0)));
            }
        } catch (Exception error) {
            Log.w("BicycleSafety", "최근 경로 읽기 실패", error);
        }
        return items;
    }

    /** 가장 최근 경로를 맨 앞에 넣고, 같은 출발·도착 경로는 하나만 남깁니다. */
    public static List<Entry> add(Context context, Entry entry) {
        List<Entry> items = load(context);
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i).sameRoute(entry)) items.remove(i);
        }
        items.add(0, entry);
        while (items.size() > MAX_ITEMS) items.remove(items.size() - 1);
        save(context, items);
        return items;
    }

    public static List<Entry> remove(Context context, int index) {
        List<Entry> items = load(context);
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            save(context, items);
        }
        return items;
    }

    private static void save(Context context, List<Entry> items) {
        try {
            JSONArray array = new JSONArray();
            for (Entry e : items) {
                JSONObject o = new JSONObject();
                o.put("originName", e.originName);
                o.put("originGps", e.originGps);
                o.put("originLat", e.originLatitude);
                o.put("originLng", e.originLongitude);
                o.put("destName", e.destinationName);
                o.put("destLat", e.destinationLatitude);
                o.put("destLng", e.destinationLongitude);
                o.put("savedAt", e.savedAt);
                array.put(o);
            }
            prefs(context).edit().putString(KEY_ITEMS, array.toString()).apply();
        } catch (Exception error) {
            Log.w("BicycleSafety", "최근 경로 저장 실패", error);
        }
    }

    public static List<Entry> unmodifiable(List<Entry> items) {
        return Collections.unmodifiableList(items);
    }
}
