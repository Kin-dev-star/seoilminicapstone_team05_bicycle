package com.example.bicyclesafety.data;

import android.content.Context;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 휴대폰 안에만 저장하는 제보게시판 (서버 연동 전 화면 개발·시연용).
 * 다른 사용자의 제보는 보이지 않으므로 실제 게시판은 ServerReportRepository로 바꿔야 합니다.
 */
public final class LocalReportRepository implements ReportRepository {
    private final LocalJsonList store;
    private final String author;

    public LocalReportRepository(Context context, String authorNickname) {
        store = new LocalJsonList(context, "local_hazard_reports", "items");
        author = authorNickname == null ? "" : authorNickname;
    }

    @Override
    public void list(int page, int pageSize, ResultCallback<List<HazardReport>> callback) {
        DataExecutors.run(() -> {
            List<JSONObject> items = store.read();
            List<HazardReport> out = new ArrayList<>();
            int from = Math.max(0, page) * Math.max(1, pageSize);
            for (int i = from; i < items.size() && out.size() < pageSize; i++) out.add(JsonCodec.report(items.get(i)));
            return out;
        }, callback);
    }

    @Override
    public void get(String id, ResultCallback<HazardReport> callback) {
        DataExecutors.run(() -> {
            for (JSONObject o : store.read()) {
                if (o.optString("id", "").equals(id)) return JsonCodec.report(o);
            }
            throw new IllegalArgumentException("제보를 찾을 수 없습니다.");
        }, callback);
    }

    @Override
    public void create(HazardReport draft, ResultCallback<HazardReport> callback) {
        DataExecutors.run(() -> {
            if (draft.title.trim().isEmpty()) throw new IllegalArgumentException("제목을 입력해 주세요.");
            if (draft.content.trim().isEmpty()) throw new IllegalArgumentException("내용을 입력해 주세요.");
            HazardReport saved = new HazardReport(UUID.randomUUID().toString(), draft.title.trim(),
                    draft.content.trim(), draft.placeName, draft.latitude, draft.longitude,
                    draft.authorNickname.isEmpty() ? author : draft.authorNickname, System.currentTimeMillis());
            List<JSONObject> items = store.read();
            items.add(0, JsonCodec.report(saved));
            store.write(items);
            return saved;
        }, callback);
    }
}
