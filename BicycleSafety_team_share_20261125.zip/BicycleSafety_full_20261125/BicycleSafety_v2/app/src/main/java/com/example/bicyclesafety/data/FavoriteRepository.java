package com.example.bicyclesafety.data;

import java.util.List;

/** 즐겨찾기 저장소. UI/UX 담당은 이 인터페이스만 사용하면 로컬↔서버 전환과 무관하게 동작합니다. */
public interface FavoriteRepository {
    void list(ResultCallback<List<FavoritePlace>> callback);
    /** 같은 id(또는 HOME/WORK 타입)가 있으면 수정, 없으면 추가. 저장된 항목을 돌려줌 */
    void save(FavoritePlace place, ResultCallback<FavoritePlace> callback);
    void delete(String id, ResultCallback<Boolean> callback);
}
