package com.example.bicyclesafety;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 경로 앞쪽의 사고 다발 구간 안내 (안드로이드 의존성 없는 순수 로직 → 단위 테스트 가능).
 *
 * 규칙
 *  - 경로에서 150m 이내 사고다발지점을 '경로상 위치(m)'로 바꾼 뒤, 150m 안에 붙어 있는 지점은 한 구간으로 묶음
 *    → 겹치는 위험지점은 음성이 한 번만 나옴
 *  - 구간 시작 300m 전부터 화면 위젯 표시, 거리는 50m 단위로 올림 (300 → 250 → 200 …)
 *  - 음성은 300m 전 1번, 100m 전 1번 (구간마다)
 *  - 구간 안에 있으면 "통과 중", 구간 끝을 지나면 위젯 숨김
 */
public final class HazardAheadGuide {

    public static final double SHOW_METERS = 300;
    public static final double NEAR_METERS = 100;
    public static final double STEP_METERS = 50;
    /** 이 거리 안에 붙은 위험지점은 한 구간으로 합칩니다. */
    public static final double MERGE_GAP_METERS = 150;
    /** 지점 앞뒤로 이만큼을 '구간'으로 봅니다. */
    public static final double ZONE_MARGIN_METERS = 50;

    public enum Voice { NONE, FAR, NEAR, INSIDE }

    public static final class Zone {
        public final double startMeters;
        public final double endMeters;
        public final int accidents;
        public final int points;
        boolean farSpoken;
        boolean nearSpoken;
        boolean entered;
        boolean passed;

        Zone(double start, double end, int accidents, int points) {
            this.startMeters = start;
            this.endMeters = end;
            this.accidents = accidents;
            this.points = points;
        }
    }

    public static final class State {
        /** 위젯을 띄울지 */
        public boolean visible;
        /** 구간 안에 있는지 */
        public boolean inside;
        /** 위젯에 보일 거리 (50m 단위로 올림) */
        public int displayMeters;
        public int accidents;
        public int points;
        /** 이번 위치에서 말해야 할 음성 (없으면 NONE) */
        public Voice voice = Voice.NONE;
        /** 음성용 거리 (50m 단위로 내림) */
        public int voiceMeters;
    }

    private final List<Zone> zones = new ArrayList<>();

    /**
     * @param alongMeters 각 위험지점의 경로상 위치 (m)
     * @param accidents   각 위험지점의 과거 사고 건수 (alongMeters와 같은 순서)
     */
    public HazardAheadGuide(double[] alongMeters, int[] accidents) {
        int n = alongMeters == null ? 0 : alongMeters.length;
        List<double[]> items = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int count = accidents != null && i < accidents.length ? accidents[i] : 0;
            items.add(new double[]{alongMeters[i], count});
        }
        Collections.sort(items, (a, b) -> Double.compare(a[0], b[0]));
        int i = 0;
        while (i < items.size()) {
            double first = items.get(i)[0];
            double last = first;
            int sum = (int) items.get(i)[1];
            int count = 1;
            int j = i + 1;
            while (j < items.size() && items.get(j)[0] - last <= MERGE_GAP_METERS) {
                last = items.get(j)[0];
                sum += (int) items.get(j)[1];
                count++;
                j++;
            }
            zones.add(new Zone(Math.max(0, first - ZONE_MARGIN_METERS), last + ZONE_MARGIN_METERS, sum, count));
            i = j;
        }
    }

    public List<Zone> zones() { return Collections.unmodifiableList(zones); }

    /** 들어갔다가 끝까지 지나간 구간 수 (주행 요약·기록용) */
    public int passedCount() {
        int n = 0;
        for (Zone z : zones) if (z.passed) n++;
        return n;
    }

    /** 현재 경로상 위치(m)로 위젯/음성 상태를 계산합니다. 같은 구간 같은 음성은 한 번만 나옵니다. */
    public State update(double currentAlong) {
        State s = new State();
        for (Zone z : zones) {
            if (currentAlong > z.endMeters) {
                // 실제로 구간에 들어갔다가 끝을 지났을 때만 '통과'로 셈 (재탐색으로 건너뛴 구간 제외)
                if (z.entered) z.passed = true;
                continue; // 이미 지난 구간
            }
            double ahead = z.startMeters - currentAlong;
            if (ahead > SHOW_METERS) break; // 다음 구간이 아직 멀면 표시하지 않음
            s.visible = true;
            s.accidents = z.accidents;
            s.points = z.points;
            if (ahead <= 0) {
                s.inside = true;
                z.entered = true;
                // 안내 시작/재탐색 직후 이미 구간 안이면 한 번만 알림
                if (!z.nearSpoken && !z.farSpoken) {
                    s.voice = Voice.INSIDE;
                }
                z.farSpoken = true;
                z.nearSpoken = true;
            } else {
                s.displayMeters = (int) (Math.ceil(ahead / STEP_METERS) * STEP_METERS);
                if (ahead <= NEAR_METERS) {
                    if (!z.nearSpoken) s.voice = Voice.NEAR;
                    z.nearSpoken = true;
                    z.farSpoken = true; // 100m 안에서 처음 봤다면 300m 안내는 건너뜀
                } else if (!z.farSpoken) {
                    s.voice = Voice.FAR;
                    s.voiceMeters = (int) (Math.floor(ahead / STEP_METERS) * STEP_METERS);
                    z.farSpoken = true;
                }
            }
            break;
        }
        return s;
    }

    /** 음성 문구 (NONE이면 null) */
    public static String speech(State s) {
        switch (s.voice) {
            case FAR: return s.voiceMeters + "미터 앞 사고 다발 구간";
            case NEAR: return "곧 사고 다발 구간입니다. 주의하세요";
            case INSIDE: return "사고 다발 구간입니다. 주의하세요";
            default: return null;
        }
    }
}
