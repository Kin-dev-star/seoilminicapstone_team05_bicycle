package com.example.bicyclesafety.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** 서버 즐겨찾기 (API 규격: docs/TEAM_INTEGRATION_GUIDE.md). 서버 엔드포인트는 백엔드 담당 구현 */
public final class ServerFavoriteRepository implements FavoriteRepository {
    private final String session;

    public ServerFavoriteRepository(String sessionToken) { this.session = sessionToken; }

    @Override
    public void list(ResultCallback<List<FavoritePlace>> callback) {
        DataExecutors.run(() -> {
            JSONArray items = ApiClient.request("GET", "/api/favorites", null, session).optJSONArray("items");
            List<FavoritePlace> out = new ArrayList<>();
            if (items != null) for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o != null) out.add(JsonCodec.favorite(o));
            }
            return out;
        }, callback);
    }

    @Override
    public void save(FavoritePlace place, ResultCallback<FavoritePlace> callback) {
        DataExecutors.run(() -> JsonCodec.favorite(
                ApiClient.request("POST", "/api/favorites", JsonCodec.favorite(place), session)
                        .getJSONObject("item")), callback);
    }

    @Override
    public void delete(String id, ResultCallback<Boolean> callback) {
        DataExecutors.run(() -> {
            ApiClient.request("DELETE", "/api/favorites/" + URLEncoder.encode(id, "UTF-8"), null, session);
            return true;
        }, callback);
    }
}
