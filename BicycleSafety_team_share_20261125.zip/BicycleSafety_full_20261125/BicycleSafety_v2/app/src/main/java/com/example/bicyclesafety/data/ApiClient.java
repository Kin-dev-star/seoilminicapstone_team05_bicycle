package com.example.bicyclesafety.data;

import com.example.bicyclesafety.BuildConfig;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * 팀 서버(MainServer) JSON API 호출 도우미. 주소는 local.properties 의 TEAM_API_BASE_URL
 * (예: http://192.168.0.10:8088). 로그인 후 받은 세션 토큰을 Authorization: Bearer 헤더로 보냅니다.
 * 백그라운드 스레드에서만 호출하세요 (저장소 구현은 DataExecutors 사용).
 */
public final class ApiClient {
    private ApiClient() {}

    public static final class ApiException extends IOException {
        public final int status;
        public ApiException(int status, String message) { super(message); this.status = status; }
    }

    public static boolean isConfigured() {
        return !baseUrl().isEmpty();
    }

    public static String baseUrl() {
        String url = BuildConfig.TEAM_API_BASE_URL == null ? "" : BuildConfig.TEAM_API_BASE_URL.trim();
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    /** GET/POST/DELETE 요청 후 응답 JSON. 서버가 {"ok":false,"error":"..."} 를 주면 ApiException */
    public static JSONObject request(String method, String path, JSONObject body, String sessionToken)
            throws IOException {
        if (!isConfigured()) throw new IOException("서버 주소(TEAM_API_BASE_URL)가 설정되지 않았습니다.");
        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl() + path).openConnection();
        try {
            conn.setRequestMethod(method);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(12000);
            conn.setRequestProperty("Accept", "application/json");
            if (sessionToken != null && !sessionToken.isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + sessionToken);
            }
            if (body != null) {
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
            }
            int status = conn.getResponseCode();
            InputStream in = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
            String text = readAll(in);
            JSONObject json;
            try {
                json = new JSONObject(text.isEmpty() ? "{}" : text);
            } catch (Exception parse) {
                throw new ApiException(status, "서버 응답이 JSON이 아닙니다 (HTTP " + status + ")");
            }
            if (status < 200 || status >= 300 || !json.optBoolean("ok", true)) {
                throw new ApiException(status, json.optString("error", "서버 오류 (HTTP " + status + ")"));
            }
            return json;
        } finally {
            conn.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = input.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() > 5_000_000) throw new IOException("서버 응답이 너무 큽니다.");
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
