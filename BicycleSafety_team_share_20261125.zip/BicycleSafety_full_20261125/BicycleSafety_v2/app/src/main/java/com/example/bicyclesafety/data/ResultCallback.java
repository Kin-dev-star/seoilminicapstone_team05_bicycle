package com.example.bicyclesafety.data;

/** 저장소(Repository) 비동기 결과. 항상 메인(UI) 스레드에서 호출됩니다. */
public interface ResultCallback<T> {
    void onSuccess(T result);
    void onError(String message);
}
