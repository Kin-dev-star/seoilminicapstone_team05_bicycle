package com.example.bicyclesafety;

/**
 * 한 번에 이어지는 사고 위험구역(서로 겹치는 150m 원 포함)에서 알림을 한 번만 보냅니다.
 * 반경 밖 20m까지 경계 여유를 두어 GPS 흔들림으로 연속 재알림되는 것을 막습니다.
 */
public final class RiskWarningGate {
    public static final double EXIT_BUFFER_METERS = 20.0;

    public enum Transition { ENTER, EXIT, NONE }

    private boolean active;

    public boolean isActive() { return active; }

    /** 길 안내 중에는 경로 기준 안내를 쓰므로 반경 경고 상태를 초기화합니다. */
    public void reset() { active = false; }

    /**
     * @param insideWarning 150m 이내인 사고 지점이 하나라도 있으면 true
     * @param insideExitBuffer 170m 이내인 사고 지점이 하나라도 있으면 true
     */
    public Transition update(boolean insideWarning, boolean insideExitBuffer) {
        if (active) {
            if (!insideExitBuffer) {
                active = false;
                return Transition.EXIT;
            }
            return Transition.NONE;
        }
        if (insideWarning) {
            active = true;
            return Transition.ENTER;
        }
        return Transition.NONE;
    }
}
