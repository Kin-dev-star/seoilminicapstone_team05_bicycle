package com.example.bicyclesafety.data;

import android.content.Context;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 휴대폰 안에 저장하는 주행 기록 (최신 200건까지) */
public final class LocalRideRecordRepository implements RideRecordRepository {
    private static final int MAX_RECORDS = 200;
    private final LocalJsonList store;

    public LocalRideRecordRepository(Context context) {
        store = new LocalJsonList(context, "local_ride_records", "items");
    }

    @Override
    public void add(RideRecord record, ResultCallback<RideRecord> callback) {
        DataExecutors.run(() -> {
            RideRecord saved = new RideRecord(record.id.isEmpty() ? UUID.randomUUID().toString() : record.id,
                    record.startedAt, record.endedAt, record.distanceMeters, record.durationSeconds,
                    record.originName, record.destinationName, record.routeMode, record.arrived,
                    record.hazardZonesPassed);
            List<JSONObject> items = store.read();
            items.add(0, JsonCodec.ride(saved));
            while (items.size() > MAX_RECORDS) items.remove(items.size() - 1);
            store.write(items);
            return saved;
        }, callback);
    }

    @Override
    public void recent(int limit, ResultCallback<List<RideRecord>> callback) {
        DataExecutors.run(() -> readRecent(limit), callback);
    }

    @Override
    public void statsSince(long fromMillis, ResultCallback<RideStats> callback) {
        DataExecutors.run(() -> RideStats.since(readRecent(MAX_RECORDS), fromMillis), callback);
    }

    private List<RideRecord> readRecent(int limit) {
        List<RideRecord> out = new ArrayList<>();
        for (JSONObject o : store.read()) {
            if (out.size() >= limit) break;
            out.add(JsonCodec.ride(o));
        }
        return out;
    }
}
