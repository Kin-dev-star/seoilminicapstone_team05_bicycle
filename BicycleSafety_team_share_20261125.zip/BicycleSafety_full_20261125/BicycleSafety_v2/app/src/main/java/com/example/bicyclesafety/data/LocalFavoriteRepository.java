package com.example.bicyclesafety.data;

import android.content.Context;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 휴대폰 안에 저장하는 즐겨찾기 (서버 연동 전·로그인 전 임시 구현) */
public final class LocalFavoriteRepository implements FavoriteRepository {
    private final LocalJsonList store;

    public LocalFavoriteRepository(Context context) {
        store = new LocalJsonList(context, "local_favorites", "items");
    }

    @Override
    public void list(ResultCallback<List<FavoritePlace>> callback) {
        DataExecutors.run(() -> {
            List<FavoritePlace> out = new ArrayList<>();
            for (JSONObject o : store.read()) out.add(JsonCodec.favorite(o));
            return out;
        }, callback);
    }

    @Override
    public void save(FavoritePlace place, ResultCallback<FavoritePlace> callback) {
        DataExecutors.run(() -> {
            List<JSONObject> items = store.read();
            String id = place.id.isEmpty() ? UUID.randomUUID().toString() : place.id;
            FavoritePlace saved = new FavoritePlace(id, place.type, place.label, place.placeName,
                    place.address, place.latitude, place.longitude);
            boolean singleton = FavoritePlace.TYPE_HOME.equals(place.type) || FavoritePlace.TYPE_WORK.equals(place.type);
            for (int i = items.size() - 1; i >= 0; i--) {
                FavoritePlace old = JsonCodec.favorite(items.get(i));
                if (old.id.equals(id) || (singleton && old.type.equals(place.type))) items.remove(i);
            }
            items.add(JsonCodec.favorite(saved));
            store.write(items);
            return saved;
        }, callback);
    }

    @Override
    public void delete(String id, ResultCallback<Boolean> callback) {
        DataExecutors.run(() -> {
            List<JSONObject> items = store.read();
            boolean removed = false;
            for (int i = items.size() - 1; i >= 0; i--) {
                if (id != null && id.equals(items.get(i).optString("id", ""))) { items.remove(i); removed = true; }
            }
            store.write(items);
            return removed;
        }, callback);
    }
}
