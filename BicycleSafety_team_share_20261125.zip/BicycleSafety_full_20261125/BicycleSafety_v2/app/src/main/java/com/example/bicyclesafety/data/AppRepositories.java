package com.example.bicyclesafety.data;

import android.content.Context;

/**
 * 화면 코드가 저장소를 얻는 단 하나의 입구. 팀원은 여기서 받은 저장소만 쓰면 됩니다.
 * - 서버 주소(TEAM_API_BASE_URL)가 있고, 카카오 로그인 후 서버 검증된 세션이 있으면 → 서버 저장소
 * - 그 외(서버 미연결·로그인 전) → 휴대폰 안 로컬 저장소
 * 백엔드 API가 아직 없으면 USE_SERVER_FOR_* 값을 false 로 두면 로그인해도 로컬로 동작합니다.
 */
public final class AppRepositories {
    private AppRepositories() {}

    /** 백엔드에 해당 API가 준비되면 true 로 바꾸세요 (docs/TEAM_INTEGRATION_GUIDE.md) */
    public static boolean USE_SERVER_FOR_FAVORITES = false;
    public static boolean USE_SERVER_FOR_RIDES = false;
    public static boolean USE_SERVER_FOR_REPORTS = false;

    private static UserSession verifiedSession(Context context) {
        if (!ApiClient.isConfigured()) return null;
        UserSession s = SessionStore.load(context);
        return s != null && s.serverVerified && !s.sessionToken.isEmpty() ? s : null;
    }

    public static FavoriteRepository favorites(Context context) {
        UserSession s = verifiedSession(context);
        return USE_SERVER_FOR_FAVORITES && s != null
                ? new ServerFavoriteRepository(s.sessionToken) : new LocalFavoriteRepository(context);
    }

    public static RideRecordRepository rides(Context context) {
        UserSession s = verifiedSession(context);
        return USE_SERVER_FOR_RIDES && s != null
                ? new ServerRideRecordRepository(s.sessionToken) : new LocalRideRecordRepository(context);
    }

    public static ReportRepository reports(Context context) {
        UserSession s = verifiedSession(context);
        if (USE_SERVER_FOR_REPORTS && ApiClient.isConfigured()) {
            return new ServerReportRepository(s == null ? "" : s.sessionToken);
        }
        UserSession local = SessionStore.load(context);
        return new LocalReportRepository(context, local == null ? "" : local.nickname);
    }
}
