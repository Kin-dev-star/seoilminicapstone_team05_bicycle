package com.example.bicyclesafety.data;

import java.util.List;

/** 위험 지점 제보게시판 저장소 (글쓰기·목록·상세) */
public interface ReportRepository {
    /** 최신순. page는 0부터, pageSize개씩 */
    void list(int page, int pageSize, ResultCallback<List<HazardReport>> callback);
    void get(String id, ResultCallback<HazardReport> callback);
    /** id·createdAt은 저장소가 채운 결과를 돌려줌 */
    void create(HazardReport draft, ResultCallback<HazardReport> callback);
}
