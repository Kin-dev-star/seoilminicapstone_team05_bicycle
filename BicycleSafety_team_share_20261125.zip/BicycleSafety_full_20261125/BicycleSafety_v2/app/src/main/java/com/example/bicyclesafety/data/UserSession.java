package com.example.bicyclesafety.data;

/**
 * 로그인 사용자 정보. 카카오 로그인 후 서버가 카카오 토큰을 검증하면 serverVerified=true 와
 * 서버 세션 토큰(sessionToken)을 받습니다. 다른 API(즐겨찾기·주행 기록·제보)는 이 세션 토큰으로 사용자를 구분합니다.
 */
public final class UserSession {
    public final long kakaoId;
    public final String nickname;
    /** 서버가 발급한 세션 토큰 (서버 미연결이면 빈 문자열) */
    public final String sessionToken;
    /** 서버가 카카오에 토큰을 확인했는지 */
    public final boolean serverVerified;
    /** 세션 만료 시각 (epoch ms, 모르면 0) */
    public final long expiresAt;

    public UserSession(long kakaoId, String nickname, String sessionToken, boolean serverVerified, long expiresAt) {
        this.kakaoId = kakaoId;
        this.nickname = nickname == null || nickname.isEmpty() ? "카카오 사용자" : nickname;
        this.sessionToken = sessionToken == null ? "" : sessionToken;
        this.serverVerified = serverVerified;
        this.expiresAt = expiresAt;
    }

    public boolean isExpired() {
        return expiresAt > 0 && System.currentTimeMillis() > expiresAt;
    }
}
