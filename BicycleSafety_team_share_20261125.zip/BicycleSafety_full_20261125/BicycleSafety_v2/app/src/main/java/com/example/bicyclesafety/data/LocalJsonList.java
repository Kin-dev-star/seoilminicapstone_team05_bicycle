package com.example.bicyclesafety.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** SharedPreferences에 JSON 배열 하나를 저장하는 작은 도우미 (로컬 임시 저장소용) */
final class LocalJsonList {
    private final SharedPreferences prefs;
    private final String key;

    LocalJsonList(Context context, String prefsName, String key) {
        this.prefs = context.getApplicationContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE);
        this.key = key;
    }

    synchronized List<JSONObject> read() {
        List<JSONObject> items = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o != null) items.add(o);
            }
        } catch (Exception ignored) {
            // 손상된 값이면 빈 목록으로 시작
        }
        return items;
    }

    synchronized void write(List<JSONObject> items) {
        JSONArray array = new JSONArray();
        for (JSONObject o : items) array.put(o);
        prefs.edit().putString(key, array.toString()).apply();
    }
}
