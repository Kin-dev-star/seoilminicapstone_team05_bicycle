package com.example.bicyclesafety;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/**
 * 백그라운드 길 안내용 포그라운드 서비스.
 * 길 안내 중 화면을 끄거나 다른 앱을 써도 위치 갱신·음성 안내·위험 경고가 계속되도록
 * '위치' 타입 포그라운드 서비스와 알림을 유지합니다. 위치 계산 자체는 MainActivity가 그대로 합니다.
 * 안내 시작(앱이 화면에 보이는 상태)에서만 시작하므로 '항상 허용' 백그라운드 위치 권한은 필요 없습니다.
 *
 * 잠금화면: 알림을 공개(PUBLIC)로 표시해 잠금화면에도 다음 안내·남은 거리·진행 막대가 보이고,
 * '안내 종료' 버튼으로 바로 끝낼 수 있습니다. 알림을 누르면 잠금 위에 안내 화면이 열립니다.
 */
public class NavigationForegroundService extends Service {
    private static final String TAG = "BicycleSafety";
    /** 잠금화면에 보이도록 중요도를 올린 새 채널 (이전 채널 bike_navigation 은 삭제) */
    public static final String CHANNEL_ID = "bike_navigation_live";
    private static final String OLD_CHANNEL_ID = "bike_navigation";
    public static final int NOTIFICATION_ID = 4201;
    /** 알림의 '안내 종료' 버튼 → MainActivity.onNewIntent 에서 처리 */
    public static final String ACTION_END_GUIDANCE = "com.example.bicyclesafety.END_GUIDANCE";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_TEXT = "text";
    private static final int NAV_BLUE = 0xFF1E6EF5;

    /** 길 안내 시작 시 호출 */
    public static void start(Context context, String title, String text) {
        Intent intent = new Intent(context, NavigationForegroundService.class)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_TEXT, text);
        try {
            ContextCompat.startForegroundService(context, intent);
        } catch (Exception error) {
            // 앱이 이미 백그라운드인 특수한 경우 등: 안내는 화면이 켜진 동안 계속 동작
            Log.w(TAG, "백그라운드 안내 서비스 시작 실패", error);
        }
    }

    /** 다음 안내·남은 거리·진행률(0~1000, 모르면 -1)을 알림에 갱신 */
    public static void update(Context context, String title, String text, int progressPermille) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;
        try {
            manager.notify(NOTIFICATION_ID, build(context, title, text, progressPermille));
        } catch (Exception error) {
            Log.w(TAG, "안내 알림 갱신 실패", error);
        }
    }

    /** 길 안내 종료 시 호출 */
    public static void stop(Context context) {
        context.stopService(new Intent(context, NavigationForegroundService.class));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent == null ? null : intent.getStringExtra(EXTRA_TITLE);
        String text = intent == null ? null : intent.getStringExtra(EXTRA_TEXT);
        Notification notification = build(this,
                title == null ? "자전거 길 안내 중" : title,
                text == null ? "화면을 꺼도 음성 안내가 계속됩니다." : text, 0);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Exception error) {
            Log.w(TAG, "포그라운드 서비스 전환 실패", error);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // 최근 앱 목록에서 앱을 지우면 안내도 끝냄
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    static Notification build(Context context, String title, String text, int progressPermille) {
        ensureChannel(context);
        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent end = new Intent(context, MainActivity.class)
                .setAction(ACTION_END_GUIDANCE)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent endIntent = PendingIntent.getActivity(context, 1, end,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_my_location)
                .setContentTitle(title)
                .setContentText(text)
                .setSubText("자전거 길 안내")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                // 잠금화면에서도 내용 전체 표시 (휴대폰 설정에서 잠금화면 알림 '내용 표시'가 켜져 있어야 함)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(NAV_BLUE)
                .setColorized(true)
                .setContentIntent(contentIntent)
                .addAction(0, "안내 종료", endIntent)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE);
        if (progressPermille >= 0) builder.setProgress(1000, Math.min(1000, progressPermille), false);
        return builder.build();
    }

    private static void ensureChannel(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (manager.getNotificationChannel(OLD_CHANNEL_ID) != null) {
            manager.deleteNotificationChannel(OLD_CHANNEL_ID);
        }
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return;
        // 중요도 '기본'이어야 잠금화면·상태 표시줄에 보임. 소리·진동은 끔 (음성 안내는 TTS가 담당)
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "자전거 길 안내",
                NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("길 안내 중 잠금화면·상태 표시줄에 다음 안내와 남은 거리를 보여 줍니다.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(channel);
    }
}
