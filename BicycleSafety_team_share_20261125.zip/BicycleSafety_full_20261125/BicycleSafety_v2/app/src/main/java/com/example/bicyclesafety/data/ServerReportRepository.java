package com.example.bicyclesafety.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** 서버 제보게시판 (API 규격: docs/TEAM_INTEGRATION_GUIDE.md). 목록·상세는 로그인 없이, 글쓰기는 로그인 필요 */
public final class ServerReportRepository implements ReportRepository {
    private final String session;

    public ServerReportRepository(String sessionToken) { this.session = sessionToken; }

    @Override
    public void list(int page, int pageSize, ResultCallback<List<HazardReport>> callback) {
        DataExecutors.run(() -> {
            JSONArray items = ApiClient.request("GET",
                    "/api/reports?page=" + Math.max(0, page) + "&size=" + Math.max(1, pageSize), null, session)
                    .optJSONArray("items");
            List<HazardReport> out = new ArrayList<>();
            if (items != null) for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o != null) out.add(JsonCodec.report(o));
            }
            return out;
        }, callback);
    }

    @Override
    public void get(String id, ResultCallback<HazardReport> callback) {
        DataExecutors.run(() -> JsonCodec.report(
                ApiClient.request("GET", "/api/reports/" + URLEncoder.encode(id, "UTF-8"), null, session)
                        .getJSONObject("item")), callback);
    }

    @Override
    public void create(HazardReport draft, ResultCallback<HazardReport> callback) {
        DataExecutors.run(() -> {
            if (session == null || session.isEmpty()) throw new IllegalStateException("제보하려면 로그인해 주세요.");
            return JsonCodec.report(ApiClient.request("POST", "/api/reports", JsonCodec.report(draft), session)
                    .getJSONObject("item"));
        }, callback);
    }
}
