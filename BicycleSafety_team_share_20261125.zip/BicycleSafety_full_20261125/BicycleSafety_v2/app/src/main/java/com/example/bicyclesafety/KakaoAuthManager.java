package com.example.bicyclesafety;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.example.bicyclesafety.data.ApiClient;
import com.example.bicyclesafety.data.SessionStore;
import com.example.bicyclesafety.data.UserSession;
import com.kakao.sdk.auth.model.OAuthToken;
import com.kakao.sdk.common.model.ClientError;
import com.kakao.sdk.common.model.ClientErrorCause;
import com.kakao.sdk.user.UserApiClient;
import com.kakao.sdk.user.model.Account;
import com.kakao.sdk.user.model.Profile;
import com.kakao.sdk.user.model.User;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/**
 * 카카오 로그인 + 서버 토큰 검증.
 * 1) 카카오톡 앱(없으면 카카오계정 웹)으로 로그인 → 카카오 액세스 토큰
 * 2) 토큰을 팀 서버 POST /api/auth/kakao 로 보냄 → 서버가 카카오에 토큰을 확인(우리 앱에서 발급됐는지 app_id 검사)
 *    → 서버 세션 토큰 발급
 * 3) 세션을 SessionStore에 저장. 서버 주소가 없거나 서버 검증이 실패하면 '검증 안 됨' 상태로 표시합니다.
 * 앱은 카카오 액세스 토큰을 저장하지 않고 서버 세션 토큰만 저장합니다.
 */
public final class KakaoAuthManager {
    private KakaoAuthManager() {}
    private static final String TAG = "BicycleSafety";
    private static final ExecutorService NETWORK = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Listener {
        /** session == null 이면 로그인 실패/취소. message는 화면에 보여 줄 안내 */
        void onResult(UserSession session, String message);
    }

    public static void login(Activity activity, Listener listener) {
        if (BuildConfig.KAKAO_NATIVE_APP_KEY.isEmpty()) {
            listener.onResult(null, "카카오 네이티브 앱 키가 없습니다. local.properties를 확인하세요.");
            return;
        }
        Function2<OAuthToken, Throwable, Unit> accountCallback = (token, error) -> {
            if (error != null) {
                listener.onResult(null, cancelled(error) ? "로그인을 취소했어요." : "카카오 로그인 실패: " + error.getMessage());
            } else if (token != null) {
                afterKakaoLogin(activity, token.getAccessToken(), listener);
            }
            return Unit.INSTANCE;
        };
        try {
            if (UserApiClient.getInstance().isKakaoTalkLoginAvailable(activity)) {
                UserApiClient.getInstance().loginWithKakaoTalk(activity, (token, error) -> {
                    if (error != null) {
                        if (cancelled(error)) {
                            listener.onResult(null, "로그인을 취소했어요.");
                        } else {
                            // 카카오톡에 연결된 계정이 없는 경우 등: 카카오계정(웹) 로그인으로 다시 시도
                            UserApiClient.getInstance().loginWithKakaoAccount(activity, accountCallback);
                        }
                    } else if (token != null) {
                        afterKakaoLogin(activity, token.getAccessToken(), listener);
                    }
                    return Unit.INSTANCE;
                });
            } else {
                UserApiClient.getInstance().loginWithKakaoAccount(activity, accountCallback);
            }
        } catch (Exception error) {
            Log.e(TAG, "카카오 로그인 시작 실패", error);
            listener.onResult(null, "카카오 로그인을 시작하지 못했습니다: " + error.getMessage());
        }
    }

    private static boolean cancelled(Throwable error) {
        return error instanceof ClientError && ((ClientError) error).getReason() == ClientErrorCause.Cancelled;
    }

    /** 카카오 사용자 정보(닉네임) 확인 후 서버 검증 */
    private static void afterKakaoLogin(Context context, String accessToken, Listener listener) {
        UserApiClient.getInstance().me((user, error) -> {
            long kakaoId = 0;
            String nickname = "";
            if (user != null) {
                kakaoId = user.getId() == null ? 0 : user.getId();
                nickname = nicknameOf(user);
            } else if (error != null) {
                Log.w(TAG, "카카오 사용자 정보 조회 실패", error);
            }
            verifyWithServer(context, accessToken, kakaoId, nickname, listener);
            return Unit.INSTANCE;
        });
    }

    private static String nicknameOf(User user) {
        Account account = user.getKakaoAccount();
        Profile profile = account == null ? null : account.getProfile();
        String nickname = profile == null ? null : profile.getNickname();
        return nickname == null ? "" : nickname;
    }

    private static void verifyWithServer(Context context, String accessToken, long kakaoId, String nickname,
                                         Listener listener) {
        Context app = context.getApplicationContext();
        if (!ApiClient.isConfigured()) {
            UserSession local = new UserSession(kakaoId, nickname, "", false, 0);
            SessionStore.save(app, local);
            listener.onResult(local, "카카오 로그인 완료 · 서버 주소가 없어 서버 검증은 하지 않았어요.");
            return;
        }
        NETWORK.execute(() -> {
            UserSession session;
            String message;
            try {
                JSONObject body = new JSONObject();
                body.put("accessToken", accessToken);
                JSONObject res = ApiClient.request("POST", "/api/auth/kakao", body, null);
                session = new UserSession(res.optLong("kakaoId", kakaoId),
                        res.optString("nickname", nickname), res.optString("sessionToken", ""),
                        true, res.optLong("expiresAt", 0));
                message = "로그인 완료 · 서버 인증됨";
            } catch (Exception error) {
                Log.w(TAG, "서버 토큰 검증 실패", error);
                session = new UserSession(kakaoId, nickname, "", false, 0);
                message = "카카오 로그인은 됐지만 서버 검증 실패: " + error.getMessage();
            }
            SessionStore.save(app, session);
            final UserSession result = session;
            final String text = message;
            MAIN.post(() -> listener.onResult(result, text));
        });
    }

    /** 카카오 로그아웃 + 서버 세션 종료(가능하면) + 저장된 세션 삭제 */
    public static void logout(Context context, Runnable done) {
        Context app = context.getApplicationContext();
        UserSession session = SessionStore.load(app);
        SessionStore.clear(app);
        if (session != null && !session.sessionToken.isEmpty() && ApiClient.isConfigured()) {
            NETWORK.execute(() -> {
                try { ApiClient.request("POST", "/api/auth/logout", new JSONObject(), session.sessionToken); }
                catch (Exception error) { Log.w(TAG, "서버 로그아웃 실패(무시)", error); }
            });
        }
        try {
            UserApiClient.getInstance().logout(error -> {
                if (error != null) Log.w(TAG, "카카오 로그아웃 실패(세션은 삭제됨)", error);
                MAIN.post(done);
                return Unit.INSTANCE;
            });
        } catch (Exception error) {
            Log.w(TAG, "카카오 로그아웃 호출 실패", error);
            MAIN.post(done);
        }
    }
}
