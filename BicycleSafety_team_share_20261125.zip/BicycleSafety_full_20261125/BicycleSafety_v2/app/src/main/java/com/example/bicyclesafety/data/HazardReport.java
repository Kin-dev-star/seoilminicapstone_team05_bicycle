package com.example.bicyclesafety.data;

/** 위험 지점 제보 글 (제보게시판). 새 글을 쓸 때는 id="" , createdAt=0 으로 만들어 저장소에 넘깁니다. */
public final class HazardReport {
    public final String id;
    public final String title;
    public final String content;
    /** 제보 위치 이름 (카카오 장소 검색 결과 또는 직접 입력) */
    public final String placeName;
    public final double latitude;
    public final double longitude;
    /** 서버가 세션으로 채움 (로컬 저장은 현재 로그인 닉네임) */
    public final String authorNickname;
    public final long createdAt;

    public HazardReport(String id, String title, String content, String placeName,
                        double latitude, double longitude, String authorNickname, long createdAt) {
        this.id = id == null ? "" : id;
        this.title = title == null ? "" : title;
        this.content = content == null ? "" : content;
        this.placeName = placeName == null ? "" : placeName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.authorNickname = authorNickname == null ? "" : authorNickname;
        this.createdAt = createdAt;
    }
}
