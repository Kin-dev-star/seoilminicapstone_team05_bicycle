package com.example.bicyclesafety;

/**
 * GPS 품질 검사와 목적지 도착 확정. Android API 의존성이 없어 단독 테스트할 수 있습니다.
 */
public final class NavigationGpsGuard {
    /** 메인 지도의 위치 정확도 기준 (m) */
    public static final float MAX_MAP_ACCURACY_METERS = 50f;
    /** 주행 중 위치를 반영하는 정확도 기준 (m) */
    public static final float MAX_NAV_ACCURACY_METERS = 35f;
    /** 자동 도착 종료를 허용하는 더 엄격한 정확도 기준 (m) */
    public static final float MAX_ARRIVAL_ACCURACY_METERS = 20f;
    public static final int REQUIRED_ARRIVAL_FIXES = 3;
    /**
     * 경로 검색 출발지용 정확도 기준 (m). 카카오 경로 API가 가까운 도로로 맞추므로
     * 주행·도착·위험 판정보다 느슨하게 둡니다. 출발지에만 쓰고 주행 판정에는 쓰지 않습니다.
     */
    public static final float MAX_ORIGIN_ACCURACY_METERS = 100f;
    private static final long MAX_ORIGIN_FIX_AGE_NANOS = 120_000_000_000L;
    private static final long MAX_FIX_AGE_NANOS = 15_000_000_000L;
    private static final long FUTURE_TOLERANCE_NANOS = 2_000_000_000L;
    private static final long MAX_MOVEMENT_INTERVAL_NANOS = 20_000_000_000L;

    private int arrivalCount = 0;
    private long lastArrivalFixNanos = -1L;

    public static boolean isUsableFix(boolean hasAccuracy, float accuracyMeters,
                                     long fixElapsedNanos, long nowElapsedNanos,
                                     float maxAccuracyMeters) {
        if (!hasAccuracy || !Float.isFinite(accuracyMeters) ||
                accuracyMeters <= 0f || accuracyMeters > maxAccuracyMeters ||
                fixElapsedNanos <= 0L || nowElapsedNanos <= 0L) return false;
        long ageNanos = nowElapsedNanos - fixElapsedNanos;
        return ageNanos >= -FUTURE_TOLERANCE_NANOS && ageNanos <= MAX_FIX_AGE_NANOS;
    }

    /** 출발지로 쓸 수 있는 좌표인지: 오차 100m 이하, 수신 후 2분 이내 (휴대폰 최근 위치 포함). */
    public static boolean isUsableOriginFix(boolean hasAccuracy, float accuracyMeters,
                                            long fixElapsedNanos, long nowElapsedNanos) {
        if (!hasAccuracy || !Float.isFinite(accuracyMeters) ||
                accuracyMeters <= 0f || accuracyMeters > MAX_ORIGIN_ACCURACY_METERS ||
                fixElapsedNanos <= 0L || nowElapsedNanos <= 0L) return false;
        long ageNanos = nowElapsedNanos - fixElapsedNanos;
        return ageNanos >= -FUTURE_TOLERANCE_NANOS && ageNanos <= MAX_ORIGIN_FIX_AGE_NANOS;
    }

    /** 두 유효 측정치 사이의 비현실적인 점프를 거릅니다 (GPS 오차 여유 40m 포함). */
    public static boolean isPlausibleMovement(float distanceMeters,
                                               long previousFixNanos, long currentFixNanos) {
        if (!Float.isFinite(distanceMeters) || distanceMeters < 0f) return false;
        if (previousFixNanos <= 0L) return true;
        long deltaNanos = currentFixNanos - previousFixNanos;
        if (deltaNanos <= 0L) return false; // 지연 도착 또는 중복 좌표
        if (deltaNanos > MAX_MOVEMENT_INTERVAL_NANOS) return true; // 재수신 시에는 새 위치 사용
        double seconds = deltaNanos / 1_000_000_000.0;
        return distanceMeters <= 40.0 + (22.0 * seconds);
    }

    /** 도착 후보가 3회 연속 확인되어야만 true. 동일 GPS 측정값의 재사용은 세지 않습니다. */
    public boolean confirmArrival(boolean plausibleArrival, long fixElapsedNanos) {
        if (!plausibleArrival || fixElapsedNanos <= 0L) {
            resetArrival();
            return false;
        }
        if (fixElapsedNanos <= lastArrivalFixNanos) return false;
        lastArrivalFixNanos = fixElapsedNanos;
        if (arrivalCount < REQUIRED_ARRIVAL_FIXES) arrivalCount++;
        return arrivalCount >= REQUIRED_ARRIVAL_FIXES;
    }

    public void resetArrival() {
        arrivalCount = 0;
        lastArrivalFixNanos = -1L;
    }
}
