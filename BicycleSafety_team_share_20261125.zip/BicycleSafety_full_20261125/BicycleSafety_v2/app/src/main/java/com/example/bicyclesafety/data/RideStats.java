package com.example.bicyclesafety.data;

import java.util.Calendar;
import java.util.List;

/** 기간별 주행 통계 (마이페이지 '이번 주·이번 달' 표시용) */
public final class RideStats {
    public final int count;
    public final int distanceMeters;
    public final int durationSeconds;

    public RideStats(int count, int distanceMeters, int durationSeconds) {
        this.count = count;
        this.distanceMeters = distanceMeters;
        this.durationSeconds = durationSeconds;
    }

    /** 기록 목록에서 [fromMillis, 지금] 사이 통계 계산 */
    public static RideStats since(List<RideRecord> records, long fromMillis) {
        int count = 0, distance = 0, duration = 0;
        for (RideRecord r : records) {
            if (r.startedAt < fromMillis) continue;
            count++;
            distance += r.distanceMeters;
            duration += r.durationSeconds;
        }
        return new RideStats(count, distance, duration);
    }

    /** 이번 주 월요일 0시 */
    public static long startOfThisWeek() {
        Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() > System.currentTimeMillis()) c.add(Calendar.DAY_OF_MONTH, -7);
        return c.getTimeInMillis();
    }

    /** 이번 달 1일 0시 */
    public static long startOfThisMonth() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
