package com.example.bicyclesafety;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * '안전 우선' 경로 선택 (과거 사고 이력 기반 시범 구현, 실제 안전 보장 아님).
 *
 * 강화 내용 (2026-11-25):
 * 1. 단순 개수 → 가중 위험 점수: (사고 건수 + 사상자 0.5) × 경로와의 거리 가중(50m 1.0 / 100m 0.7 / 150m 0.4)
 * 2. 경로 중간 한 곳만 우회 → 위험 점수가 큰 지점 최대 2곳을 골라 그 지점의 진행 방향 좌우 300m·600m로 우회 후보 생성
 * 3. 거리 패널티: 비용 = 위험 점수 + (기본 경로보다 늘어난 거리 / 300m). 기본 경로의 1.35배를 넘으면 제외
 * 4. 우회 지점에 갔다가 같은 길로 되돌아오는 '찍고 오는' 경로 제외, 우회 지점 자체가 사고 지점 근처면 제외
 * 5. 후보 경로를 4개씩 동시에 조회해 대기 시간 단축
 *
 * 대안 경로가 잘 안 나오던 문제 보완 (2026-11-25 2차):
 * 6. 우회 지점이 '아무 사고 지점'의 150m 안이면 버리던 필터 → 60m 안일 때만 버림
 *    (사고 지점이 촘촘한 지역에서는 후보가 거의 다 버려져 대안이 0개였음. 실제 위험은 비용 계산이 판단)
 * 7. 우회 폭을 경로 길이에 맞춤: 가까운 후보 = 길이×12% (150~400m), 먼 후보 = 길이×25% (300~800m)
 * 8. 위험 지점 맞춤 후보 2곳 → 3곳 (서로 300m 이상), 후보 최대 8 → 10개, 동시 5개, 허용 거리 1.35 → 1.4배
 * 9. 비용으로 이기는 경로가 없어도, 위험 점수를 25% 이상 줄이면서 거리가 25% 이내로 늘어나는 경로가 있으면
 *    '안전 우선' 대안으로 보여 줌 (안전 우선 카드이므로 조금 더 돌아가도 덜 위험한 쪽을 제시)
 * 10. 진단 정보(검사한 후보 수 / 실제 경로를 받은 후보 수)를 화면 문구에 표시
 */
public final class SafetyRoutePlanner {
    private SafetyRoutePlanner() { }

    public static final double RISK_RADIUS_METERS = 150.0;
    /** 기본 경로 대비 허용 최대 거리 비율 */
    public static final double MAX_DETOUR_RATIO = 1.4;
    /** 위험 점수 1점을 줄이려고 감수하는 추가 거리(m) */
    public static final double METERS_PER_RISK_POINT = 300.0;
    /** 의미 있는 개선으로 보는 최소 비용 감소 */
    static final double MIN_IMPROVEMENT = 0.5;
    static final int MAX_CANDIDATES = 10;
    private static final int PARALLEL_REQUESTS = 5;
    /** 우회 지점이 사고 지점에 이보다 가까우면 후보에서 뺌 */
    static final double VIA_HAZARD_CLEARANCE_METERS = 60.0;
    /** 비용으로 이기지 못해도 '안전 우선'으로 보여 줄 최소 위험 감소율과 최대 거리 증가율 */
    static final double SAFETY_FALLBACK_MIN_REDUCTION = 0.25;
    static final double SAFETY_FALLBACK_MAX_EXTRA = 0.25;
    private static final long CANDIDATE_TIMEOUT_SECONDS = 25;
    private static final double M_PER_DEG = 111320.0;

    public static final class Selection {
        public final KakaoRouteRepository.Result route;
        /** 기본 경로보다 위험 점수가 낮은 별도 경로를 찾았는지 */
        public final boolean distinct;
        /** 선택 경로 150m 이내 사고 지점 수 */
        public final int hazards;
        /** 기본 경로(자전거도로·최단 중 나은 쪽)의 가중 위험 점수 */
        public final double baselineScore;
        /** 선택 경로의 가중 위험 점수 */
        public final double score;
        /** 검사한 우회 후보 수 */
        public int candidatesTried;
        /** 카카오에서 실제 경로를 받았고 거리 제한·되돌아오기 검사를 통과한 후보 수 */
        public int candidatesValid;
        /** 비용이 아니라 '위험 25% 이상 감소' 기준으로 고른 대안인지 */
        public boolean safetyFallback;

        public Selection(KakaoRouteRepository.Result route, boolean distinct, int hazards,
                         double baselineScore, double score) {
            this.route = route; this.distinct = distinct; this.hazards = hazards;
            this.baselineScore = baselineScore; this.score = score;
        }

        Selection diagnostics(int tried, int valid) {
            this.candidatesTried = tried; this.candidatesValid = valid;
            return this;
        }

        /** 위험 점수 감소율 (0~100) */
        public int reductionPercent() {
            if (baselineScore <= 0) return 0;
            return (int) Math.round(Math.max(0, baselineScore - score) / baselineScore * 100.0);
        }
    }

    /** 우회 지점 후보 */
    static final class Via {
        final double latitude, longitude;
        final String reason;
        Via(double latitude, double longitude, String reason) {
            this.latitude = latitude; this.longitude = longitude; this.reason = reason;
        }
    }

    // ───────── 위험 계산 ─────────

    /** 경로 150m 이내 사고 지점 수 (화면 표시용) */
    public static int riskCount(List<RiskPoint> accidents, List<KakaoRouteRepository.Point> path) {
        if (path == null || path.size() < 2 || accidents == null) return 0;
        Bounds b = Bounds.of(path);
        int count = 0;
        for (RiskPoint risk : accidents) {
            if (!b.near(risk)) continue;
            if (distanceToPath(risk.latitude, risk.longitude, path) <= RISK_RADIUS_METERS) count++;
        }
        return count;
    }

    /** 가중 위험 점수 (경로 선택용) */
    public static double riskScore(List<RiskPoint> accidents, List<KakaoRouteRepository.Point> path) {
        if (path == null || path.size() < 2 || accidents == null) return 0;
        Bounds b = Bounds.of(path);
        double score = 0;
        for (RiskPoint risk : accidents) {
            if (!b.near(risk)) continue;
            double d = distanceToPath(risk.latitude, risk.longitude, path);
            score += weightOf(risk) * proximityFactor(d);
        }
        return score;
    }

    /** 사고 지점 무게: 사고 건수(최소 1) + 사상자 0.5 */
    static double weightOf(RiskPoint risk) {
        return Math.max(1, risk.accidentCount) + 0.5 * Math.max(0, risk.casualtyCount);
    }

    /** 경로와 가까울수록 위험하게 봄 */
    static double proximityFactor(double meters) {
        if (meters <= 50) return 1.0;
        if (meters <= 100) return 0.7;
        if (meters <= RISK_RADIUS_METERS) return 0.4;
        return 0.0;
    }

    /** 비용 = 위험 점수 + 늘어난 거리 / 300m */
    static double cost(double score, int distanceMeters, int baseDistanceMeters) {
        double extra = Math.max(0, distanceMeters - baseDistanceMeters);
        return score + extra / METERS_PER_RISK_POINT;
    }

    // ───────── 경로 선택 ─────────

    /**
     * 자전거도로 우선·최단 경로 중 비용이 낮은 쪽을 기본으로 두고, 위험 지점 맞춤 우회 후보를 실제 카카오 경로로 조회해
     * 비용이 의미 있게 낮아질 때만 바꿉니다. 개선이 없으면 distinct=false (화면: '별도 회피 경로를 찾지 못함').
     */
    public static Selection choose(String key, KakaoRouteRepository.PlaceOption from,
            KakaoRouteRepository.PlaceOption to, KakaoRouteRepository.Result bike,
            KakaoRouteRepository.Result shortest, List<RiskPoint> risks) {
        if (bike == null && shortest == null) return null;
        int baseDistance = Math.min(bike == null ? Integer.MAX_VALUE : bike.distanceMeters,
                shortest == null ? Integer.MAX_VALUE : shortest.distanceMeters);

        KakaoRouteRepository.Result best = null;
        double bestScore = 0, bestCost = Double.MAX_VALUE;
        for (KakaoRouteRepository.Result base : new KakaoRouteRepository.Result[]{bike, shortest}) {
            if (base == null) continue;
            double s = riskScore(risks, base.points);
            double c = cost(s, base.distanceMeters, baseDistance);
            if (c < bestCost - 1e-9) { best = base; bestScore = s; bestCost = c; }
        }
        final double baselineScore = bestScore;
        final double baselineCost = bestCost;
        if (risks == null || risks.isEmpty() || baselineScore <= 0
                || best.distanceMeters > 20000 || best.points.size() < 3) {
            return new Selection(best, false, riskCount(risks, best.points), baselineScore, baselineScore);
        }

        List<Via> vias = candidateVias(risks, best.points, from, to, baseDistance);
        if (vias.isEmpty()) {
            return new Selection(best, false, riskCount(risks, best.points), baselineScore, baselineScore);
        }
        int valid = 0;
        KakaoRouteRepository.Result safest = null;
        double safestScore = baselineScore;

        final int maxDistance = (int) Math.round(baseDistance * MAX_DETOUR_RATIO);
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(PARALLEL_REQUESTS, vias.size()));
        List<Callable<KakaoRouteRepository.Result>> jobs = new ArrayList<>();
        for (Via via : vias) {
            jobs.add(() -> routeThrough(key, from, via, to, maxDistance));
        }
        try {
            List<Future<KakaoRouteRepository.Result>> futures =
                    pool.invokeAll(jobs, CANDIDATE_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            for (Future<KakaoRouteRepository.Result> future : futures) {
                KakaoRouteRepository.Result candidate;
                try { candidate = future.get(); } catch (Exception skipped) { continue; }
                if (candidate == null) continue;
                valid++;
                double s = riskScore(risks, candidate.points);
                double c = cost(s, candidate.distanceMeters, baseDistance);
                if (c < bestCost - 1e-9) { best = candidate; bestScore = s; bestCost = c; }
                if (s < safestScore - 1e-9
                        && candidate.distanceMeters <= baseDistance * (1 + SAFETY_FALLBACK_MAX_EXTRA)) {
                    safest = candidate; safestScore = s;
                }
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        } finally {
            pool.shutdownNow();
        }
        int tried = vias.size();
        boolean improved = bestScore < baselineScore && bestCost <= baselineCost - MIN_IMPROVEMENT;
        if (improved) {
            return new Selection(best, true, riskCount(risks, best.points), baselineScore, bestScore)
                    .diagnostics(tried, valid);
        }
        if (safest != null && isSafetyFallback(baselineScore, safestScore)) {
            Selection sel = new Selection(safest, true, riskCount(risks, safest.points), baselineScore, safestScore)
                    .diagnostics(tried, valid);
            sel.safetyFallback = true;
            return sel;
        }
        // 개선 폭이 작으면 원래 기본 경로를 그대로 사용
        KakaoRouteRepository.Result base = pickBase(bike, shortest, risks, baseDistance);
        return new Selection(base, false, riskCount(risks, base.points), baselineScore, baselineScore)
                .diagnostics(tried, valid);
    }

    /** 위험 점수를 25% 이상 줄였는지 */
    static boolean isSafetyFallback(double baselineScore, double score) {
        return baselineScore > 0 && score <= baselineScore * (1 - SAFETY_FALLBACK_MIN_REDUCTION);
    }

    /** 우회 폭 (가까운 후보, 먼 후보): 경로 길이의 12%·25%, 각각 150~400m·300~800m */
    static double[] offsetsFor(int baseDistanceMeters) {
        double near = clamp(baseDistanceMeters * 0.12, 150, 400);
        double far = clamp(baseDistanceMeters * 0.25, 300, 800);
        if (far < near + 150) far = near + 150;
        return new double[]{near, far};
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private static KakaoRouteRepository.Result pickBase(KakaoRouteRepository.Result bike,
            KakaoRouteRepository.Result shortest, List<RiskPoint> risks, int baseDistance) {
        if (bike == null) return shortest;
        if (shortest == null) return bike;
        double cb = cost(riskScore(risks, bike.points), bike.distanceMeters, baseDistance);
        double cs = cost(riskScore(risks, shortest.points), shortest.distanceMeters, baseDistance);
        return cs < cb - 1e-9 ? shortest : bike;
    }

    /** 출발 → 우회 지점 → 도착을 실제 자전거 경로 2구간으로 조회해 하나의 경로로 합칩니다. */
    private static KakaoRouteRepository.Result routeThrough(String key, KakaoRouteRepository.PlaceOption from,
            Via via, KakaoRouteRepository.PlaceOption to, int maxDistance) throws Exception {
        KakaoRouteRepository.PlaceOption viaPlace =
                new KakaoRouteRepository.PlaceOption("우회지점", "", via.latitude, via.longitude);
        KakaoRouteRepository.Result first = KakaoRouteRepository.routeBetween(key, from, viaPlace, true);
        if (first.distanceMeters > maxDistance) return null;
        KakaoRouteRepository.Result second = KakaoRouteRepository.routeBetween(key, viaPlace, to, true);
        int distance = first.distanceMeters + second.distanceMeters;
        if (distance > maxDistance) return null;
        if (isOutAndBack(first.points, second.points)) return null;

        List<KakaoRouteRepository.Point> points = new ArrayList<>(first.points);
        for (int i = 0; i < second.points.size(); i++) {
            KakaoRouteRepository.Point p = second.points.get(i);
            if (i == 0 && !points.isEmpty()) {
                KakaoRouteRepository.Point last = points.get(points.size() - 1);
                if (last.latitude == p.latitude && last.longitude == p.longitude) continue;
            }
            points.add(p);
        }
        // 우회 지점에서 나오는 '도착' 안내는 빼서 중간에 목적지 도착으로 읽히지 않게 함
        List<KakaoRouteRepository.GuideStep> steps = new ArrayList<>();
        for (KakaoRouteRepository.GuideStep step : first.guideSteps) {
            String g = step.guidance == null ? "" : step.guidance;
            if (g.contains("도착") || g.contains("목적지")) continue;
            steps.add(step);
        }
        for (KakaoRouteRepository.GuideStep step : second.guideSteps) {
            String g = step.guidance == null ? "" : step.guidance;
            if (g.contains("출발")) continue;
            steps.add(step);
        }
        return new KakaoRouteRepository.Result(distance, first.durationSeconds + second.durationSeconds,
                first.matchedOrigin, second.matchedDestination, points, steps,
                to.name, to.latitude, to.longitude, true);
    }

    // ───────── 우회 후보 만들기 ─────────

    /** 테스트·기존 호출용: 경로 길이를 점 목록에서 계산 */
    static List<Via> candidateVias(List<RiskPoint> risks, List<KakaoRouteRepository.Point> path,
                                   KakaoRouteRepository.PlaceOption from, KakaoRouteRepository.PlaceOption to) {
        return candidateVias(risks, path, from, to, (int) Math.round(pathLength(path)));
    }

    /**
     * 경로 주변에서 위험 점수가 큰 지점 최대 3곳(서로 300m 이상 떨어진 곳)을 고르고,
     * 그 지점의 경로 진행 방향에 수직으로 좌우 '가까운 폭'·'먼 폭'(경로 길이 비례) 떨어진 우회 지점을 만듭니다.
     * 마지막으로 경로 중간의 좌우 후보를 더합니다. 우회 지점이 사고 지점 60m 이내거나
     * 출발·도착 200m 이내면 제외합니다.
     */
    static List<Via> candidateVias(List<RiskPoint> risks, List<KakaoRouteRepository.Point> path,
                                   KakaoRouteRepository.PlaceOption from, KakaoRouteRepository.PlaceOption to,
                                   int baseDistanceMeters) {
        List<Via> result = new ArrayList<>();
        if (path == null || path.size() < 3) return result;

        // 1) 경로 주변 위험 지점과 그 위치(가장 가까운 구간 번호)
        List<double[]> hot = new ArrayList<>(); // {lat, lng, weight, segmentIndex}
        Bounds b = Bounds.of(path);
        for (RiskPoint risk : risks) {
            if (!b.near(risk)) continue;
            int[] seg = new int[1];
            double d = distanceToPath(risk.latitude, risk.longitude, path, seg);
            double w = weightOf(risk) * proximityFactor(d);
            if (w > 0) hot.add(new double[]{risk.latitude, risk.longitude, w, seg[0]});
        }
        Collections.sort(hot, (x, y) -> Double.compare(y[2], x[2]));
        List<double[]> picked = new ArrayList<>();
        for (double[] h : hot) {
            boolean farEnough = true;
            for (double[] p : picked) {
                if (meters(h[0], h[1], p[0], p[1]) < 300) { farEnough = false; break; }
            }
            if (farEnough) picked.add(h);
            if (picked.size() == 3) break;
        }

        // 2) 위험 지점 맞춤 후보 (가까운 폭 먼저, 그다음 먼 폭)
        double[] offsets = offsetsFor(baseDistanceMeters);
        for (double offset : offsets) {
            for (double[] h : picked) {
                int i = (int) h[3];
                KakaoRouteRepository.Point center = path.get(Math.min(i, path.size() - 1));
                double[] dir = directionAt(path, i);
                for (int sign : new int[]{-1, 1}) {
                    addVia(result, risks, from, to, center, dir, offset * sign, "사고지점 회피");
                }
            }
        }
        // 3) 경로 중간 좌우 (먼 폭) - 위험 지점이 경로 전체에 퍼져 있을 때 크게 돌아가는 후보
        int mid = path.size() / 2;
        double[] midDir = directionAt(path, mid);
        for (int sign : new int[]{-1, 1}) {
            addVia(result, risks, from, to, path.get(mid), midDir, offsets[1] * sign, "중간 우회");
        }
        return result.size() > MAX_CANDIDATES ? new ArrayList<>(result.subList(0, MAX_CANDIDATES)) : result;
    }

    private static void addVia(List<Via> out, List<RiskPoint> risks,
                               KakaoRouteRepository.PlaceOption from, KakaoRouteRepository.PlaceOption to,
                               KakaoRouteRepository.Point center, double[] dir, double offsetMeters, String reason) {
        if (dir == null) return;
        double cos = Math.cos(Math.toRadians(center.latitude));
        // 진행 방향(dx, dy)에 수직인 방향 (-dy, dx)
        double offX = -dir[1] * offsetMeters;
        double offY = dir[0] * offsetMeters;
        double lat = center.latitude + offY / M_PER_DEG;
        double lng = center.longitude + offX / (M_PER_DEG * cos);
        if (from != null && meters(lat, lng, from.latitude, from.longitude) < 200) return;
        if (to != null && meters(lat, lng, to.latitude, to.longitude) < 200) return;
        for (RiskPoint r : risks) {
            if (Math.abs(r.latitude - lat) > 0.003 || Math.abs(r.longitude - lng) > 0.004) continue;
            if (meters(lat, lng, r.latitude, r.longitude) <= VIA_HAZARD_CLEARANCE_METERS) return;
        }
        for (Via v : out) {
            if (meters(lat, lng, v.latitude, v.longitude) < 150) return;
        }
        out.add(new Via(lat, lng, reason));
    }

    /** i번째 지점 주변(앞뒤 3칸)의 진행 방향 단위 벡터 (동쪽 x, 북쪽 y) */
    static double[] directionAt(List<KakaoRouteRepository.Point> path, int i) {
        int a = Math.max(0, i - 3), c = Math.min(path.size() - 1, i + 3);
        if (a == c) return null;
        KakaoRouteRepository.Point p = path.get(a), q = path.get(c);
        double cos = Math.cos(Math.toRadians((p.latitude + q.latitude) / 2));
        double dx = (q.longitude - p.longitude) * M_PER_DEG * cos;
        double dy = (q.latitude - p.latitude) * M_PER_DEG;
        double n = Math.hypot(dx, dy);
        if (n < 1) return null;
        return new double[]{dx / n, dy / n};
    }

    /**
     * 우회 지점까지 간 뒤 같은 길로 되돌아오는 경로인지 확인합니다.
     * 1구간 끝 50~250m와 2구간 시작 50~250m가 서로 30m 이내로 겹치면 '찍고 오는' 경로로 봅니다.
     */
    static boolean isOutAndBack(List<KakaoRouteRepository.Point> first, List<KakaoRouteRepository.Point> second) {
        if (first.size() < 2 || second.size() < 2) return false;
        int overlapped = 0, compared = 0;
        for (double d = 50; d <= 250; d += 50) {
            double[] a = pointAtDistanceFromEnd(first, d);
            double[] b = pointAtDistanceFromStart(second, d);
            if (a == null || b == null) break;
            compared++;
            if (meters(a[0], a[1], b[0], b[1]) < 30) overlapped++;
        }
        return compared >= 3 && overlapped == compared;
    }

    private static double[] pointAtDistanceFromStart(List<KakaoRouteRepository.Point> path, double target) {
        double acc = 0;
        for (int i = 1; i < path.size(); i++) {
            KakaoRouteRepository.Point p = path.get(i - 1), q = path.get(i);
            double seg = meters(p.latitude, p.longitude, q.latitude, q.longitude);
            if (acc + seg >= target && seg > 0) {
                double t = (target - acc) / seg;
                return new double[]{p.latitude + (q.latitude - p.latitude) * t,
                        p.longitude + (q.longitude - p.longitude) * t};
            }
            acc += seg;
        }
        return null;
    }

    private static double[] pointAtDistanceFromEnd(List<KakaoRouteRepository.Point> path, double target) {
        List<KakaoRouteRepository.Point> reversed = new ArrayList<>(path);
        Collections.reverse(reversed);
        return pointAtDistanceFromStart(reversed, target);
    }

    // ───────── 거리 계산 ─────────

    static double distanceToPath(double lat, double lng, List<KakaoRouteRepository.Point> path) {
        return distanceToPath(lat, lng, path, null);
    }

    /** 점과 경로(선분 목록) 사이 최단 거리(m). segmentOut[0]에 가장 가까운 구간 번호 */
    static double distanceToPath(double lat, double lng, List<KakaoRouteRepository.Point> path, int[] segmentOut) {
        double scaleX = M_PER_DEG * Math.cos(Math.toRadians(lat));
        double best = Double.POSITIVE_INFINITY;
        int bestIndex = 0;
        for (int i = 1; i < path.size(); i++) {
            KakaoRouteRepository.Point a = path.get(i - 1), b = path.get(i);
            double ax = (a.longitude - lng) * scaleX, ay = (a.latitude - lat) * M_PER_DEG;
            double bx = (b.longitude - lng) * scaleX, by = (b.latitude - lat) * M_PER_DEG;
            double dx = bx - ax, dy = by - ay, denom = dx * dx + dy * dy;
            double t = denom < 1e-8 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / denom));
            double d = Math.hypot(ax + t * dx, ay + t * dy);
            if (d < best) { best = d; bestIndex = i; }
        }
        if (segmentOut != null && segmentOut.length > 0) segmentOut[0] = bestIndex;
        return best;
    }

    static double pathLength(List<KakaoRouteRepository.Point> path) {
        double total = 0;
        if (path == null) return 0;
        for (int i = 1; i < path.size(); i++) {
            KakaoRouteRepository.Point a = path.get(i - 1), b = path.get(i);
            total += meters(a.latitude, a.longitude, b.latitude, b.longitude);
        }
        return total;
    }

    static double meters(double lat1, double lng1, double lat2, double lng2) {
        double cos = Math.cos(Math.toRadians((lat1 + lat2) / 2));
        return Math.hypot((lng2 - lng1) * M_PER_DEG * cos, (lat2 - lat1) * M_PER_DEG);
    }

    /** 경로를 감싸는 사각형 (+ 약 220~270m 여유)로 먼 사고 지점은 계산을 건너뜀 */
    private static final class Bounds {
        double minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
        static Bounds of(List<KakaoRouteRepository.Point> path) {
            Bounds b = new Bounds();
            for (KakaoRouteRepository.Point p : path) {
                b.minLat = Math.min(b.minLat, p.latitude); b.maxLat = Math.max(b.maxLat, p.latitude);
                b.minLng = Math.min(b.minLng, p.longitude); b.maxLng = Math.max(b.maxLng, p.longitude);
            }
            return b;
        }
        boolean near(RiskPoint r) {
            return r.latitude >= minLat - .002 && r.latitude <= maxLat + .002
                    && r.longitude >= minLng - .003 && r.longitude <= maxLng + .003;
        }
    }
}
