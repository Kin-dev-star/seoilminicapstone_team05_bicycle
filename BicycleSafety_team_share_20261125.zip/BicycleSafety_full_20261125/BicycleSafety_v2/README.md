# BicycleSafety — 자전거 안전예방 지도 (미니캡스톤 5조)

서울시 자전거 사고 다발지역을 카카오맵에 표시하고, 카카오 자전거 경로 검색과 GPS·TTS 접근 경고를 제공하는 Android 앱입니다.

> **현재 상태: 2026-11-25 실기기 테스트 준비본 (줌 제한 · 검은 화면 진단 · GPS 속도 · 안내 화면 개편 · 최근 경로 반영)**
> 이번 변경 요약: `CHANGES_20261125_nav_ui_recent_routes.md`, `CHANGES_20261125_background_safety_login.md`, `CHANGES_20261125_lockscreen_simulation.md`
> 실내 테스트: 경로 미리보기의 `▶ 주행 시뮬레이션`(디버그 빌드)으로 안내·경고·잠금화면·백그라운드를 밖에 나가지 않고 확인
> 팀원 통합 방법: `docs/TEAM_INTEGRATION_GUIDE.md`
> 정적 점검과 Java 단위 테스트까지만 마친 상태이며, **Android Studio 실제 빌드와 갤럭시 실기기 실행은 아직 확인 전**입니다.
> 11/25 변경 기록은 루트의 `README_1125_*.md`, `README_GPS_도착오판_수정_20261125.md`, `README_실기기_6기능_확인.txt`에 있습니다.

이 문서는 기존 안내 문서 3개(`README_먼저읽기.md`, `README_통합_안내.md`, `README_경로설정_통합안내.md`)를 하나로 합친 것입니다. 이전 안내 원문은 `docs/참고_기존안내/`에 보관되어 있습니다.

---

## 1. 프로젝트 열기

1. 이 폴더(`app/`과 `settings.gradle.kts`가 함께 있는 폴더)를 `C:\BS`처럼 **경로가 짧고 한글이 없는 곳**에 둡니다. 상위 경로에 한글이 있으면 Gradle 오류가 날 수 있습니다.
2. Android Studio에서 `File > Open`으로 이 폴더를 엽니다. `app` 폴더만 선택하지 마세요.
3. Gradle Sync를 실행합니다. 처음에는 Kotlin/Compose 의존성을 내려받으므로 네트워크가 필요합니다.
   - 특정 PC에서만 쓰던 **JDK 25 강제 설정은 제거**했습니다. Android Studio의 **Gradle JDK(Embedded JDK/JBR, 호환 버전)**를 사용하세요.
   - Gradle JDK 버전 호환 오류가 나오면 오류 메시지부터 확인하고 설치된 JDK 설정을 조정합니다.
4. SDK 37을 설치하고, ARM64 변환을 지원하는 Pixel 에뮬레이터 또는 실제 Android 기기를 준비합니다.
5. 아래 2번의 `local.properties`를 설정한 뒤 `Build > Make Project`를 실행합니다.

## 2. `local.properties` 설정 (필수)

프로젝트 루트에 `local.properties` 파일을 만들고 **본인 PC의 SDK 위치와 카카오 키**를 입력합니다. 이미 파일이 있으면 기존 `sdk.dir=...` 줄은 지우지 말고 키만 추가합니다. `local.properties.example`을 참고하세요.

```properties
sdk.dir=C\:\\Users\\User\\AppData\\Local\\Android\\Sdk
KAKAO_NATIVE_APP_KEY=카카오디벨로퍼스에서_발급한_네이티브앱키
KAKAO_REST_API_KEY=카카오디벨로퍼스에서_발급한_REST_API_키
# TEAM_API_BASE_URL=http://192.168.0.10:8088   (팀 서버 PC의 IP, 카카오 로그인 서버 검증·사고 데이터·마이페이지 API)
```

저장 후 `File > Sync Project with Gradle Files` → `Build > Rebuild Project`를 실행합니다.

**보안 주의**
- `local.properties`는 `.gitignore` 대상입니다. 키를 채팅, 스크린샷, 공개 GitHub에 올리지 마세요. 노출된 적이 있는 키는 재발급하세요.
- 키는 `BuildConfig`로 앱에 들어가므로 APK에서 추출될 수 있습니다. 수업용 프로토타입 방식이며, 실제 배포 시에는 팀 백엔드에서 카카오 REST API를 대신 호출해야 합니다.
- 자세한 내용은 `docs/04_보안_기본수칙.md`를 참고하세요.

## 3. 동작 확인 순서 (갤럭시 실기기 기준)

1. 앱 실행 → 로딩 화면 → **주행 전 안전 안내** 확인 → 위치 권한 **정확한 위치 허용** → 실제 카카오맵과 현재 위치 표시
2. 사고 마커 선택 → **과거 사고 데이터**의 지점명·건수·출처 표시 (마커 주변 150m 빨간 원 = 접근 안내 범위)
3. 지도를 손가락으로 최대한 확대·축소 → 10~18레벨에서 멈추고 앱이 튕기지 않는지 확인
4. 경로 설정 창 열기 → 출발지는 기본 **현재 위치(GPS)**. 목적지에 장소 이름이나 주소를 입력해 자동완성 후보 선택 (장소·주소가 한 목록에 함께 나옴)
5. 출발지 칸에 다른 장소(예: 서울역)를 입력 → `경로 찾기` → 미리보기에 **`내 위치에서 안내`** 버튼이 나오는지 확인. `✓ 내 위치`를 누르면 출발지가 다시 현재 위치로 돌아감
6. 빈 목적지 / 출발지와 같은 목적지 → 안내 문구 확인
7. `경로 찾기` → 지도 아래 **3가지 경로 비교 카드**(안전 우선 / 최단 경로 / 자전거도로 우선)와 함께 **전체 경로가 카드 위쪽에 모두 보이는지** 확인. 카드를 눌러 경로선이 바뀌는지 확인
8. 경로 설정 창 맨 아래 **최근 경로**에 방금 경로가 저장되는지 확인 → 누르면 다시 검색, ✕로 삭제
9. `안내 시작` → **바로 내 위치로 확대**되고, 왼쪽 위 파란 회전 카드(+ 아래 꼬리: 그다음 안내), 오른쪽 진행 막대, 아래 안내 정보 바(재탐색·목적지·도착 예정 시각·남은 거리·종료)가 보이는지 확인
10. 지도를 확대·축소하면 **위치 화살표도 함께 커지고 작아지는지**, 제자리에서 폰을 돌리면 화살표가 회전하는지 확인
11. 안내 정보 바 위 오른쪽 **작은 동그라미(검색)** → 검색창에 장소 입력 → 종료(✕) 없이 새 경로 비교 화면으로 넘어가는지 확인
12. 사고다발지역 150m 안에 들어가면 화면 경고와 한국어 TTS가 **한 번만** 나오고, 170m 밖으로 나간 뒤 새 구역에서 다시 나오는지 확인
13. 경로에서 40m 이상 벗어난 위치가 3번 연속 잡히면 "경로를 벗어났습니다" 후 자동 재탐색되는지 확인 (안전 우선 경로였다면 현재 위치에서 안전 우선으로 다시 비교)
14. GPS가 약할 때 `GPS 정확도 낮음 · 경로 안내 유지 중`이 나오고 안내가 임의로 끝나지 않는지 확인
15. 목적지 25m 이내에서 정상 GPS 측정이 **3번 연속** 확인될 때만 안내가 자동 종료되는지 확인

에뮬레이터를 쓸 때는 ARM64를 지원하는 Pixel 기기를 사용하고, Extended Controls > Location > Routes로 경로를 재생해 위 9~15번을 확인할 수 있습니다.

전체 체크리스트와 결과 표는 `docs/03_학교실습_체크리스트.md`에 있습니다. 빌드 오류와 실행 화면은 캡처로 남겨 주세요.

## 4. 어떤 기능이 어디에 있나

| 대상 | 파일 | 역할 |
|---|---|---|
| 앱 초기화 | `app/src/main/java/com/example/bicyclesafety/MapApplication.java` | 카카오맵 네이티브 키 초기화 |
| 지도·마커·GPS·TTS·경로 제어 | `.../bicyclesafety/MainActivity.java` | Java 기능 연결의 중심, 안전 확인 게이트, 길 안내 시작·종료·재탐색 |
| 길 안내 계산 | `.../bicyclesafety/NavigationTracker.java` | 현재 위치를 경로선에 투영해 다음 회전까지 거리·남은 거리·경로 이탈·도착 판단 (Android 의존성 없음) |
| 안전 우선 경로 비교 | `.../bicyclesafety/SafetyRoutePlanner.java` | 자전거도로·최단 경로와 좌우 650m 우회 후보를 조회해 경로 150m 이내 과거 사고 지점 수 비교 |
| GPS 품질·도착 확정 | `.../bicyclesafety/NavigationGpsGuard.java` | 오차·오래된 좌표·위치 튐 거르기, 도착 3회 연속 확인 (Android 의존성 없음) |
| 위험 경고 중복 방지 | `.../bicyclesafety/RiskWarningGate.java` | 겹친 150m 원에서 경고 1회, 170m 밖으로 나가야 해제 |
| 최근 경로 저장 | `.../bicyclesafety/RecentRouteStore.java` | 최근 경로 5개를 휴대폰 안(SharedPreferences)에 저장·삭제 |
| 백그라운드 길 안내 | `.../bicyclesafety/NavigationForegroundService.java` | 화면이 꺼져도 GPS·음성 안내 유지, 상단 알림 |
| 카카오 로그인 | `.../bicyclesafety/KakaoAuthManager.java` | 카카오톡/카카오계정 로그인 → 서버 `/api/auth/kakao` 토큰 검증 → 세션 저장 |
| 마이페이지·제보 데이터 | `.../bicyclesafety/data/` | 모델·저장소 인터페이스·로컬/서버 구현, `AppRepositories` 하나로 사용 |
| 카카오 검색·경로 API | `.../bicyclesafety/KakaoRouteRepository.java` | 출발지/도착지 검색, 경로 좌표, 안내 문구 |
| 사고 데이터 입력 | `.../bicyclesafety/RiskDataRepository.java` | 앱 동봉 데이터 / 선택적 HTTPS 팀 서버 API 변환 |
| 사고 모델 | `.../bicyclesafety/RiskPoint.java` | 사고 건수, 사상자, 좌표, 출처 |
| Java–Kotlin 연결 | `.../app/ui/BikeUiBridge.kt` | 화면 상태와 Java 함수, Kakao MapView의 유일한 연결점 |
| 앱 화면 구성 | `.../app/ui/BikeApp.kt` | 로딩 → 메인 화면 전환, 느린 PC 로딩 탈출 처리 |
| 메인 화면 | `.../app/ui/main/MainScreen.kt` | 원통 메뉴, 경로 시트, GPS·경고 표시, 테마 |
| 경로 미리보기·길 안내 화면 | `.../app/ui/main/NavigationScreen.kt` | 경로 분석 후 요약 카드, 안내 중 회전 카드·속도·진행 막대·도착 정보 |
| 로딩 화면 | `.../app/ui/loading/BikeLoadingScreen.kt` | 자전거 로딩 애니메이션 + 로고 |
| 디자인 스타일 | `.../app/ui/theme/Soft.kt` | 디자이너 제공 뉴모피즘 스타일 |
| 동봉 사고 기록 | `app/src/main/assets/seoul_bicycle_accidents.json` | KOROAD 데이터를 팀이 가공한 CSV 2,079행 |
| 화면 레이아웃 | `app/src/main/res/layout/activity_main.xml` | ComposeView 한 개 (다른 XML 레이아웃은 참조용 보관) |

```text
BicycleSafety_v2/
  README.md                       <- 이 문서
  local.properties.example        <- 키 설정 예시
  app/
    build.gradle.kts
    src/main/
      java/com/example/bicyclesafety/
        MainActivity.java
        KakaoRouteRepository.java
        RiskDataRepository.java
        RiskPoint.java
        MapApplication.java
        NavigationTracker.java
        SafetyRoutePlanner.java
        NavigationGpsGuard.java
        RiskWarningGate.java
        RecentRouteStore.java
      java/com/example/app/ui/
        BikeUiBridge.kt
        BikeApp.kt
        main/MainScreen.kt
        main/NavigationScreen.kt
        loading/BikeLoadingScreen.kt
        theme/Soft.kt
      assets/seoul_bicycle_accidents.json
  docs/
    01_일정과_구현현황.md
    02_팀API_연동계약.md
    03_학교실습_체크리스트.md
    04_보안_기본수칙.md
    05_새UI_카카오로그인_통합대기.md
    06~11 (질문, 점검 결과, 수정 내역)
    참고_기존안내/                <- 이전 README 원문
    학교제출_초안/                <- S6·S7 점검 PDF 초안
  tests/                          <- 정적 검사 스크립트
  gradle/, settings.gradle.kts, build.gradle.kts
```

## 5. 경로 검색 데이터 흐름

```text
MainScreen.kt (현재 위치 출발 / 목적지 검색·자동완성 / 즐겨찾기 UI)
  ↓
BikeUiBridge.kt → MainActivity.java (메인 스레드에서 클릭 처리)
  ↓ 별도 백그라운드 스레드
KakaoRouteRepository.java
  ① 출발지·목적지 좌표 확정 (GPS 좌표 또는 자동완성 선택값, 없으면 키워드·주소 검색 첫 결과)
  ② 카카오 자전거 경로 API 2회 (BIKE_ONLY / SHORTEST)
  ③ SafetyRoutePlanner: 사고 이력이 남으면 좌우 우회 지점을 거치는 후보 2개 추가 조회
  → 3가지 경로(안전 우선 / 최단 / 자전거도로 우선)와 경로 150m 이내 사고 지점 수
  ↓
route.legs[].steps[].path.points[] 순서대로 처리
  ↓ 메인 스레드
MainActivity.java: KakaoMap RouteLine 추가 + 카메라 이동
  ↓
BikeUiBridge.kt → NavigationScreen.kt (3가지 경로 비교 카드 → 안내 시작)
```

## 6. 반드시 구분해야 하는 것

- **경로 3종:** `자전거도로 우선`은 카카오 `BIKE_ONLY`, `최단 경로`는 `SHORTEST` 모드입니다. `안전 우선`은 카카오에 안전 모드가 없어서, 두 기본 경로와 **위험 점수가 큰 사고 지점 옆 좌우 300m·600m + 경로 중간 좌우 650m** 우회 지점(최대 8곳)을 거치는 실제 경로 후보를 동시에 조회하고, **가중 위험 점수(사고 건수 + 사상자 0.5, 경로와 가까울수록 가중) + 늘어난 거리/300m** 가 가장 낮은 경로를 고르는 시범 구현입니다. 기본 경로의 1.35배를 넘거나 우회 지점을 찍고 되돌아오는 경로는 제외합니다. 더 적은 경로를 못 찾으면 '별도 회피 경로를 찾지 못함'으로 표시합니다. **실제 안전을 보장하거나 모든 경로를 탐색하는 최적화가 아닙니다.**
- **장소 검색:** 장소 이름과 주소를 한 번에 검색합니다(카카오 키워드·주소 검색 2회를 합쳐 최대 8개). 자동완성 후보를 고르면 그 좌표를 그대로 씁니다. 후보를 고르지 않고 검색하면 **첫 번째 결과를 자동 선택**하니 표시된 장소명을 확인하세요.
- **출발지:** 기본은 현재 위치입니다. 다른 출발지로 찾은 경로는 소요 시간 확인용이며, 실제 안내는 `내 위치에서 안내`로 현재 위치에서 같은 목적지·같은 경로 종류로 다시 찾은 뒤 시작합니다.
- **최근 경로:** 경로 검색에 성공하면 최대 5개까지 이 휴대폰에만 저장합니다(서버·계정 연동 아님). 출발지가 현재 위치였던 경로는 다시 누를 때의 현재 위치에서 찾습니다.
- **오르막:** 카카오 경로 응답에 높이 정보가 없어 `— m`로 표시됩니다.
- **사고 데이터:** 2,079건은 과거 공공데이터를 가공한 **오프라인 자료**입니다. 지도 성능을 위해 현재 화면 중심 또는 경로 주변 **최대 80개 마커만** 표시합니다. 팀 서버가 연결된 경우에만 서버 자료로 바뀝니다.
- **접근 경고 범위 표시:** 지도에 보이는 사고다발지역 중 가까운 40곳까지, 접근 안내가 시작되는 반경 150m를 빨간 원으로 표시합니다. 카카오맵 도형은 그라데이션을 지원하지 않아 반경이 다른 반투명 원 5개를 겹쳐 가운데가 진하게 보이도록 했고, 150m 경계에는 얇은 테두리가 있습니다. 반경은 `MainActivity.WARNING_DISTANCE_METERS`를 따릅니다.
- **경로 위험 표시:** 경로선 주변 **150m 이내** 과거 사고다발지역 개수를 단순히 세어 보여 줄 뿐, 위험도를 추정하거나 경로를 바꾸지 않습니다.
- **GPS·TTS:** 권한을 받은 뒤 **앱을 사용하는 동안에만** 위치를 요청합니다. 위치 오차가 80m 이하일 때만 150m 반경 접근 경고를 적용하며, 접근 경고와 안내 시작 문구는 시연용입니다. 위치 정확도와 TTS 엔진에 따라 결과가 달라지므로 실제 도로 내비게이션으로 사용하면 안 됩니다. 안내는 **"과거 사고 이력"** 기준이며 실시간 사고나 안전을 보장하지 않습니다.
- **길 안내 화면:** 카카오 자전거 경로의 안내 문구(guidance)로 회전 방향을 판별하고, 남은 거리·도착 시각은 경로 길이와 예상 시간 비율로 계산합니다. 지도는 북쪽이 위인 상태로 현재 위치를 따라가고, 위치 화살표만 휴대폰 방향 센서(없으면 GPS 이동 방향)로 회전합니다. 주행 속도 표시는 제거했습니다. 앱이 화면에 있을 때만 동작하며 화면 꺼짐 방지가 켜집니다. 시연용이며 실제 도로 내비게이션을 대신하지 않습니다.
- **현재 위치 받기:** Play 서비스가 있는 폰(갤럭시 등)은 Google Fused 위치(GPS + Wi-Fi + 기지국)를 사용해 첫 위치를 빠르게 받습니다. Play 서비스가 없으면 기존 기본 GPS(LocationManager)로 자동 전환합니다. Gradle Sync 때 `play-services-location`을 내려받으므로 네트워크가 필요합니다.
- **GPS 보호:** 경로 검색 **출발지**는 오차 100m·2분 이내 좌표면 바로 사용합니다(카카오 경로 API가 가까운 도로로 맞춤). 반면 **지도 위치 반영 50m, 주행 35m, 자동 도착 20m** 기준과 오래된 좌표·위치 튐 거르기는 그대로입니다. 자동 도착 종료는 오차 20m 이내 측정이 3번 연속일 때만 일어납니다.
- **백그라운드 안내:** 길 안내 중에는 위치 타입 포그라운드 서비스와 상단 알림으로 화면을 꺼도 GPS·음성 안내·위험 경고가 계속됩니다. 안내를 시작할 때(앱이 화면에 있을 때)만 켜지므로 '항상 허용' 위치 권한은 필요 없습니다. 최근 앱 목록에서 앱을 지우면 안내도 종료됩니다.
- **카카오 로그인:** 마이페이지 프로필 카드에서 로그인합니다. 서버 주소(`TEAM_API_BASE_URL`)가 있으면 서버가 카카오에 토큰을 확인한 뒤 세션을 발급하고(`서버 인증됨`), 없으면 `서버 검증 전`으로 표시합니다. 카카오 디벨로퍼스에서 카카오 로그인 ON, 닉네임 동의항목 설정이 필요합니다.
- **위치 표시 크기:** 안내 중 화살표와 평소 위치 점은 지도 줌 레벨(12~18)에 맞춰 단계별로 커지고 작아집니다.
- **지도 줌 제한:** 최대 확대·축소 시 튕김을 줄이려고 카메라 줌을 10~18레벨로 제한합니다. 원인이 카카오맵 네이티브 그래픽이라면 제한만으로 해결되지 않을 수 있으니, 재발하면 Logcat을 확인하세요.
- **즐겨찾기·마이페이지·제보하기:** 화면 자리만 있으며 저장·조회 기능은 팀원 작업분과 연결 전입니다.
- **디자인 v4:** `2026-11-11_ui_v4.zip`의 원통형 메뉴·경로창·페이지·테마를 기반으로 했습니다. v4의 `평지 위주` 옵션은 대응 API가 확정되지 않아 제외했습니다.
- **계정 기능:** 12/9 작업 대상입니다. 로그인·회원가입 API가 아직 없어 화면에는 **미구현** 안내가 표시됩니다. 카카오 로그인 패치(11/4 기준)는 현재 빌드에 포함하지 않았으며, 검토 내용은 `docs/05_새UI_카카오로그인_통합대기.md`에 있습니다.

## 7. 오류가 날 때

| 증상 | 확인할 것 |
|---|---|
| 빌드 실패 | `Build Output`의 **첫 번째 오류** 전문 확인 |
| Gradle JDK 호환 오류 | Android Studio의 Gradle JDK를 Embedded JDK/JBR(호환 버전)로 설정 |
| 경로 분석 시 "REST API 키가 없습니다" | `local.properties`의 키 이름과 값 확인 → Gradle Sync + Rebuild |
| HTTP 401 / 403 | REST API 키 종류, 재발급 여부, 카카오맵 서비스 사용 설정·권한 확인 |
| 장소 검색 결과 없음 | 주소나 장소명을 더 구체적으로 입력 |
| 200 OK인데 경로 없음 | 두 지점이 너무 멀거나 자전거 길찾기 미지원 지역인지 확인 |
| 지도는 보이는데 경로선 실패 | Logcat에서 `BicycleSafety` 필터로 오류 확인 |
| 앱 화면이 검게 나옴 | Logcat에서 먼저 `is:crash` 검색. 결과가 없으면 `BicycleSafetyStartup` 검색 → `1.`~`6.` 단계와 `Compose screen=LOADING/MAIN` 중 어디서 멈췄는지 확인 |
| `libK3fAndroid.so not found` | x86 에뮬레이터 문제. 카카오맵은 ARM만 지원하므로 ARM64 Pixel 에뮬레이터나 실기기 사용 |
| `System UI isn't responding`, `Component activation exception` | 앱 코드 오류로 단정하기 전에 에뮬레이터 상태(WHPX, 시스템 이미지, 그래픽 렌더링)와 카카오맵 ANR 확인. Logcat에서 `FATAL EXCEPTION`, `ANR`, `BicycleSafety`를 함께 확인 |

오래되고 느린 에뮬레이터는 카카오맵 SDK와 충돌할 수 있습니다. 카카오맵은 공식 ARM ABI 실행 환경이 필요합니다.

## 8. 버전 이력

| 버전 | 주요 내용 |
|---|---|
| 11/11 최종 UI 통합 작업본 | Java 카카오맵 SDK 연결에 Kotlin/Compose 디자인(로딩 애니메이션, 원통 메뉴, 경로 시트, 설정·마이페이지, 밝은/블랙 테마)을 통합. 실제 Kakao `MapView`를 Compose `AndroidView`로 넣고, 안전 확인 게이트를 새 디자인 팝업으로 다시 그림. 로고를 런처 아이콘과 로딩 화면에 반영 |
| 11/11 카카오 자전거 경로 설정 통합본 | 경로 분석 버튼에 카카오 장소 검색 + 자전거 경로 REST API를 연결해 실제 경로선 표시. REST API 키를 `local.properties`로 분리 |
| 11/25 길 안내 화면 추가 | 경로 분석 후 미리보기 카드, 카카오맵 방식 길 안내 화면(회전 카드·속도·진행 막대·도착 예정 시각), 회전 150m/30m 전 음성 안내, 경로 이탈 시 자동 재탐색, 도착 시 자동 종료 |
| 12/2 작업 준비본 | KOROAD 사고 데이터 2,079건 동봉, 선택적 팀 서버 API, GPS 현재 위치와 150m 접근 경고 TTS, 경로 주변 사고다발지역 개수 표시, UI v4 반영, JDK 25 강제 설정 제거 |
| 11/25 실기기 6기능 | 실기기 자동 GPS, 내 위치 출발지, 장소 자동완성·주소 검색, 3가지 경로 비교(안전 우선 시범), 주행 화살표 |
| 11/25 GPS·UI 수정 | GPS 정확도 보호와 도착 3회 확인, 겹친 위험구역 1회 경고, 경로창 스크롤, 속도 UI 제거, 휴대폰 방향 화살표, 주행 중 목적지 검색, 경로 설정창 간소화 |
| 11/25 줌 제한·검은 화면 진단·GPS 속도 | 카메라 줌 10~18 제한, 화면 전환 Crossfade 제거, `BicycleSafetyStartup` 시작 단계 로그, Google Fused 위치, 출발지 GPS 기준 완화(100m) |
| 11/25 안내 화면 개편·최근 경로 | 위치 화살표 줌 비례, 안내 시작 자동 확대, 카카오내비형 안내 화면, 하단 동그라미 목적지 검색, 장소·주소 통합 검색, 다른 출발지 + 내 위치에서 안내, 최근 경로 5개, 미리보기 전체 경로 자동 맞춤 |
| **11/25 백그라운드·안전 경로 강화·카카오 로그인 (기준)** | 화면 꺼짐 중 안내 유지(포그라운드 서비스), 가중 위험 점수·위험 지점 맞춤 우회, 카카오 로그인 + 서버 토큰 검증, 마이페이지·제보 데이터 틀, 주행 기록 자동 저장 |

이전 버전의 안내 원문은 `docs/참고_기존안내/`에 있습니다.

## 9. 검증 상태

- XML·JSON·ZIP 정적 점검과 Java 코드 로컬 컴파일 스텁 검사를 했습니다. 실제 Android SDK 빌드와는 다릅니다.
- **Android Studio 실제 Gradle 빌드와 기기 실행은 학교 실습실에서 확인해야 합니다.**
- 협업은 `docs/04_보안_기본수칙.md`대로 Jira 이슈별 브랜치 → 커밋 → PR → 팀원 승인 순서로 진행합니다.

참고: [카카오 로컬·길찾기 REST API](https://developers.kakao.com/docs/ko/kakaomap/rest-api), [카카오맵 Android v2 RouteLine](https://apis.map.kakao.com/android_v2/docs/api-guide/routeline/)
