package com.test.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {
		HttpClient client = HttpClient.newBuilder()
				         .version(Version.HTTP_2)
				         .followRedirects(Redirect.NORMAL)
				         .connectTimeout(Duration.ofSeconds(20))
				         .build();
		HttpRequest request = HttpRequest.newBuilder()
				          .uri(URI.create("http://localhost:8088/1"))
				          .build();
				    client.sendAsync(request, BodyHandlers.ofString())
				          .thenApply(HttpResponse::body)
				          .thenAccept(System.out::println)
				          .join();
		
//		HttpRequest request=HttpRequest.newBuilder().uri(URI.create("https://localhost:8088/1")).GET().build();
//		client.sendAsync(request,HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).thenAccept(System.out::println).join();
	}

}
