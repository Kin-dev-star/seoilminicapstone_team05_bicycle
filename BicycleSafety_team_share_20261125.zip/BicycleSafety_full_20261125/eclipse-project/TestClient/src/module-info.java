/**
 * 
 */
/**
 * 
 */
module TestClient {
	requires java.net.http;
}