# MainServer 2026-11-25 변경: 카카오 로그인 토큰 검증 + JSON API

기존 기능(`/1` 사고 데이터 텍스트, `/2아이디,비번,이름,TTS` 회원가입)은 그대로 동작합니다.
새 기능은 모두 `/api/...` 경로에 추가했습니다.

## 1. 실행 준비
1. `server.properties.example` 을 복사해 `server.properties` 로 저장하고 `kakao.appId` 에 **카카오 앱 ID(숫자)** 입력
   (DB 계정이 root/root 가 아니면 `db.user`, `db.password` 도 수정)
2. MySQL 실행 → Eclipse에서 `com.server.Main` 실행
   - 콘솔에 `로그인 테이블 준비 완료 (kakao_user, user_session)` 가 나오면 성공 (테이블 자동 생성, `sql/schema.sql` 과 같은 내용)
3. 휴대폰에서 접속하려면
   - PC와 휴대폰을 **같은 와이파이**에 연결, PC의 IP 확인 (`cmd` → `ipconfig` → IPv4 주소, 예: 192.168.0.10)
   - Windows 방화벽에서 **8088 포트 인바운드 허용** (처음 실행 시 뜨는 방화벽 창에서 '허용')
   - 앱 `local.properties` 에 `TEAM_API_BASE_URL=http://192.168.0.10:8088` 추가 → Gradle Sync → 실행
   - 휴대폰 브라우저에서 `http://192.168.0.10:8088/api/health` 가 `{"ok":true}` 면 연결 성공
   - 학교 와이파이는 기기끼리 접속을 막는 경우가 있습니다. 안 되면 휴대폰 핫스팟에 PC를 연결해 보세요.

## 2. 새 API

| 메서드 | 경로 | 설명 |
|---|---|---|
| POST | `/api/auth/kakao` | 본문 `{"accessToken":"카카오 액세스 토큰"}` → 카카오에 토큰 확인 후 `{"ok":true,"kakaoId":..,"nickname":"..","sessionToken":"..","expiresAt":..}` |
| GET | `/api/me` | 헤더 `Authorization: Bearer 세션토큰` → `{"ok":true,"kakaoId":..,"nickname":".."}` |
| POST | `/api/auth/logout` | 헤더 `Authorization: Bearer 세션토큰` → 세션 삭제 |
| GET | `/api/hazards` | 사고다발지역 2,079곳 JSON `{"ok":true,"count":2079,"items":[{id,name,latitude,longitude,accidentCount,casualtyCount}]}` (앱이 지도에 바로 사용) |
| GET | `/api/health` | 연결 확인 `{"ok":true}` |

오류는 항상 `{"ok":false,"error":"설명"}` 과 HTTP 상태(400/401/404/405/500/503)로 돌려줍니다.

## 3. 토큰 검증 방식 (발표용 설명)
1. 앱이 카카오 로그인으로 받은 **카카오 액세스 토큰**을 서버에 보냄
2. 서버가 `https://kapi.kakao.com/v1/user/access_token_info` 로 토큰이 유효한지, **우리 앱(app_id)에서 발급된 토큰인지** 확인
3. `https://kapi.kakao.com/v2/user/me` 로 회원번호·닉네임 확인 (토큰 정보의 회원번호와 같아야 함)
4. 서버가 자체 **세션 토큰**(무작위 64자리)을 발급, DB에는 **SHA-256 해시만** 저장 (유효기간 30일)
5. 앱은 카카오 토큰을 저장하지 않고 세션 토큰만 저장 → 이후 API는 `Authorization: Bearer 세션토큰` 으로 사용자 구분

앱이 보낸 사용자 ID를 그대로 믿지 않고 서버가 카카오에 직접 확인하므로, 다른 사람의 ID를 넣어 로그인하는 것을 막습니다.

## 4. 백엔드 담당: 즐겨찾기·주행 기록·제보 API 추가 방법
`com/server/api/ApiRouter.java` 의 `handle()` 에 경로를 추가하고, 로그인 사용자는 이렇게 확인합니다.

```java
if (p.equals("/api/favorites") && m.equals("GET")) {
    long kakaoId = auth.requireUser(request);      // 로그인 안 했으면 자동으로 401
    // SELECT ... FROM favorite_place WHERE kakao_id = ?   (PreparedStatement 사용)
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("items", list);                         // List<Map<String,Object>>
    return ok(out);
}
```
- 요청 본문 JSON: `MiniJson.parseObject(request.body)`
- 앱이 기대하는 요청·응답 JSON은 앱 프로젝트 `docs/TEAM_INTEGRATION_GUIDE.md` 4장에 있습니다. 테이블 예시는 `sql/schema.sql` 아래쪽 주석.
- 앱은 `AppRepositories.USE_SERVER_FOR_FAVORITES` 등을 `true` 로 바꾸면 서버 API를 쓰기 시작합니다.
- 주행 기록 JSON에 `hazardZonesPassed`(지나간 사고 다발 구간 수, 정수) 필드가 추가됐습니다 (2026-11-25). 테이블 예시에 `hazard_zones_passed` 열 반영.

## 5. 함께 고친 점
- 요청 헤더·본문(POST)을 끝까지 읽고 응답에 `Content-Type`, `Content-Length` 를 붙임 (Android에서 안정적으로 읽힘)
- 기존 `/2` 회원가입 파라미터 끝에 `" HTTP/1.1"` 이 붙어 TTS 값이 항상 false 가 되던 문제 수정 (경로 부분만 전달, URL 인코딩 해제)
- 서비스 반복문이 쉬지 않고 돌아 CPU를 100% 쓰던 문제 → 20ms씩 쉼
- 포트·DB 계정·카카오 앱 ID를 `server.properties` 로 분리 (파일이 없으면 기존 값 8088, root/root 사용)
- `/1` 원본 텍스트(`src/res/output.txt`)에서 **중랑구 면목동(면목두산2단지아파트정문 부근)** 지점명이 두 줄로 나뉘어 있어,
  15줄씩 읽으면 그 뒤 1,060건이 한 칸씩 밀립니다. `/api/hazards` 는 폴리곤 줄 기준으로 읽어 2,079건 모두 정상
  (앱에 들어 있는 데이터와 ID·좌표·건수 전부 일치 확인). `/1` 을 직접 쓰는 코드가 있다면 같은 문제가 있으니 `/api/hazards` 사용을 권장.

## 6. 확인한 것 / 못 한 것
- 확인: Java 17로 전체 컴파일, 로컬 실행 후 `/api/health`, `/api/hazards`(2,079건), `/1`, `/api/me`(로그인 없음 → 401),
  `/api/auth/kakao`(본문 없음 → 400, 잘못된 방식 → 405), 없는 경로 → 404 응답 확인
- 못 한 것: 이 작업 환경에서는 MySQL과 카카오 서버에 접속할 수 없어 **실제 카카오 토큰 검증·DB 저장은 학교/집 PC에서 확인**해야 합니다.
