@echo off
rem ============================================================
rem  BicycleSafety MainServer - Eclipse 없이 실행 (Windows)
rem  이 파일을 MainServer 폴더에 두고 더블클릭하세요.
rem  Java는 Android Studio에 들어 있는 것(jbr)을 먼저 찾고, 없으면 PC에 설치된 java를 씁니다.
rem ============================================================
chcp 65001 > nul
cd /d "%~dp0"

set "JBIN="
if exist "C:\Program Files\Android\Android Studio\jbr\bin\javac.exe" set "JBIN=C:\Program Files\Android\Android Studio\jbr\bin\"
if not defined JBIN if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" set "JBIN=%JAVA_HOME%\bin\"
if not defined JBIN (
  where javac > nul 2> nul
  if errorlevel 1 (
    echo [오류] Java를 찾지 못했습니다. Android Studio 설치 경로를 확인하거나 JDK 17 이상을 설치하세요.
    pause
    exit /b 1
  )
)
echo 사용하는 Java: %JBIN%java
"%JBIN%java" -version

if not exist server.properties (
  echo [안내] server.properties 가 없습니다. server.properties.example 을 복사해 만든 뒤 다시 실행하세요.
  pause
  exit /b 1
)

echo.
echo [1/2] 컴파일 중...
if exist out rmdir /s /q out
dir /s /b src\*.java | findstr /v /i "module-info.java" > sources.txt
"%JBIN%javac" -encoding UTF-8 --release 17 -d out @sources.txt
if errorlevel 1 (
  echo [오류] 컴파일 실패. 위의 첫 번째 error 줄을 알려 주세요.
  del sources.txt
  pause
  exit /b 1
)
del sources.txt

echo [2/2] 서버 실행 (끄려면 이 창을 닫거나 Ctrl+C)
echo.
"%JBIN%java" -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "out;..\external libraries\*" com.server.Main
pause
