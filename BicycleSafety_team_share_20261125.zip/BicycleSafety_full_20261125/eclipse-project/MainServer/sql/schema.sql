-- 카카오 로그인용 테이블 (서버 시작 시 자동 생성되지만, 직접 만들 때 사용)
-- DB: NKK_DATABASE (MySQL 8)

CREATE TABLE IF NOT EXISTS kakao_user (
  kakao_id      BIGINT PRIMARY KEY,                 -- 카카오 회원번호
  nickname      VARCHAR(100) NOT NULL DEFAULT '',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_session (
  token_hash CHAR(64) PRIMARY KEY,                  -- 세션 토큰의 SHA-256 (원문은 저장 안 함)
  kakao_id   BIGINT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,                    -- 발급 후 30일
  INDEX idx_session_user (kakao_id),
  CONSTRAINT fk_session_user FOREIGN KEY (kakao_id) REFERENCES kakao_user(kakao_id) ON DELETE CASCADE
) DEFAULT CHARSET=utf8mb4;

-- ───── 아래는 백엔드 담당이 만들 테이블 예시 (앱 data 패키지 규격과 같은 필드) ─────
-- CREATE TABLE favorite_place (
--   id VARCHAR(40) PRIMARY KEY, kakao_id BIGINT NOT NULL, type VARCHAR(10) NOT NULL,  -- HOME/WORK/OTHER
--   label VARCHAR(50), place_name VARCHAR(200), address VARCHAR(300),
--   latitude DOUBLE NOT NULL, longitude DOUBLE NOT NULL,
--   FOREIGN KEY (kakao_id) REFERENCES kakao_user(kakao_id) ON DELETE CASCADE
-- ) DEFAULT CHARSET=utf8mb4;
-- CREATE TABLE ride_record (
--   id VARCHAR(40) PRIMARY KEY, kakao_id BIGINT NOT NULL, started_at BIGINT, ended_at BIGINT,
--   distance_m INT, duration_s INT, origin_name VARCHAR(200), destination_name VARCHAR(200),
--   route_mode INT, arrived BOOLEAN, hazard_zones_passed INT DEFAULT 0,
--   FOREIGN KEY (kakao_id) REFERENCES kakao_user(kakao_id) ON DELETE CASCADE
-- ) DEFAULT CHARSET=utf8mb4;
-- CREATE TABLE hazard_report (
--   id VARCHAR(40) PRIMARY KEY, kakao_id BIGINT NOT NULL, title VARCHAR(100) NOT NULL, content TEXT NOT NULL,
--   place_name VARCHAR(200), latitude DOUBLE, longitude DOUBLE, created_at BIGINT,
--   FOREIGN KEY (kakao_id) REFERENCES kakao_user(kakao_id) ON DELETE CASCADE
-- ) DEFAULT CHARSET=utf8mb4;
