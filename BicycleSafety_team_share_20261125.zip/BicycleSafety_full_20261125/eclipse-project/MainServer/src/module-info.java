/**
 * 
 */
/**
 * 
 */
module MainServer {
	requires java.sql;
	requires java.net.http; // 카카오 토큰 검증 (kapi.kakao.com 호출)
}