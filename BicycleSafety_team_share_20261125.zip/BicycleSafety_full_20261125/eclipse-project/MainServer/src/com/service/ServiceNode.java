package com.service;

public interface ServiceNode {

}
