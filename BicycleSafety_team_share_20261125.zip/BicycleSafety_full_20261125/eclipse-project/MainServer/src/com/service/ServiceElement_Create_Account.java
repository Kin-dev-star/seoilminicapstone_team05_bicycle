package com.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.server.Context;

public class ServiceElement_Create_Account extends ServiceElement{

	@Override
	public Object submit(Context context, Object obj) throws Exception {
		try {
			String[]attr=((String)obj).split(",");
			if(attr.length!=4)return "-1";
			if(attr[0].length()>21)return "-20";
			if(attr[1].length()>21)return "-21";
			if(attr[2].length()>21)return "-22";
			if(attr[3].length()>21)return "-23";
			String id="",pass="",name="";boolean tts;
			for(int i=0;i<attr[0].length();i++)
				id+=String.valueOf((int)attr[0].charAt(i)+" ");
			MessageDigest digest=MessageDigest.getInstance("SHA-256");
			byte[]pwb=digest.digest(attr[1].getBytes(StandardCharsets.UTF_8));
			for(int i=0;i<pwb.length;i++)
				pass+=String.valueOf(pwb[i]);
			for(int i=0;i<attr[2].length();i++)
				name+=String.valueOf((int)attr[2].charAt(i)+" ");
			tts=Boolean.parseBoolean(attr[3]);
//			System.out.println(new String(pwb));
			Connection c=context.sqlConnector_CreateConnection(0);
			PreparedStatement checkUser=c.prepareStatement("SELECT*FROM account WHERE USER_ID=?");
			checkUser.setString(1,id);
			ResultSet rs=checkUser.executeQuery();
			if(rs.next())return "-3";
			
			PreparedStatement ps=c.prepareStatement("insert into account(user_id,password,user_name,tts_enabled)values(?,?,?,?)");
			ps.setString(1,id);
			ps.setString(2,pass);
			ps.setString(3,name);
			ps.setBoolean(4,tts);
			int result=ps.executeUpdate();
			if(result==1)return "0";
			return "-1";
		}catch(Exception e) {}
		return "-1";
	}

}
