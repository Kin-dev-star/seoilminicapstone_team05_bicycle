package com.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;

import com.server.Context;

public class ServiceElement_GetData extends ServiceElement{

	@Override
	public Object submit(Context c,Object obj) throws SQLException {
//		c.sqlConnector_getQuery(0,"SELECT*FROM bicycle_warning_area");
		String readline="";
		StringBuilder sb=new StringBuilder();
		try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(new File("src/res/output.txt"))))){
			while((readline=br.readLine())!=null) {
				sb.append(readline+"\n");
			}
		}catch(Exception e) {e.printStackTrace();}
//		Connection conn=c.sqlConnector_CreateConnection(0,"SELECT*FROM bicycle_warning_area");
//		Statement stat=conn.createStatement();
//		ResultSet s=stat.executeQuery("SELECT*FROM bicycle_warning_area");
//		if(s!=null) {
//			while(s.next()) {
//				System.out.println(s.getString("AREA_NAME"));
//			}
//			conn.close();
//			stat.close();
//			s.close();
//		}
		
		return sb.toString();
	}

}
