package com.service;

import com.server.Context;

public class ServiceExampleCallback extends ServiceElement{
	
	public ServiceExampleCallback() {}
	@Override
	public Object submit(Context c,Object obj) {
		System.out.println("ServiceExample: "+(String)obj);
		return "received";
	}

}
