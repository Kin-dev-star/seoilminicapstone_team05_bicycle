package com.service;

import com.server.Context;

public abstract class ServiceElement {
	public abstract Object submit(Context context,Object obj)throws Exception;
}
