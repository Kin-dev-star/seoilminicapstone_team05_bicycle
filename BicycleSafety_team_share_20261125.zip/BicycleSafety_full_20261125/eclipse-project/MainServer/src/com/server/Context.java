package com.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Vector;

import com.service.ServiceElement;
import com.service.ServiceElement_Create_Account;
import com.service.ServiceElement_GetData;
import com.service.ServiceExampleCallback;

public class Context {
	int serviceTimeout=10000;
	int serviceCount=10;
	boolean serviceMake=false;
	Vector<ServiceElement>api=new Vector<ServiceElement>();
	Vector<ClientService>clientTasks=new Vector<ClientService>();
	Vector<ServerSocket>sockets=new Vector<ServerSocket>();
	Vector<SQLConnector>database=new Vector<SQLConnector>();
	Vector<ClientService>userServices=new Vector<ClientService>();
	public Context() {
		
		ServiceElement e1=new ServiceExampleCallback();
		ServiceElement e2=new ServiceElement_GetData();
		ServiceElement e3=new ServiceElement_Create_Account();
		api.add(e1);api.add(e2);api.add(e3);
	}
	void startService() {
		serviceMake=true;
		runClientService();
	}
	private void runClientService() {
		System.out.println("startService");
		while(serviceMake) {
			userServices.setSize(serviceCount);
			for(int i=0;i<serviceCount;i++) {
				if(userServices.get(i)==null) {
					ClientService newTask=new ClientService(this,"localhost",0,serviceTimeout);
					userServices.set(i,newTask);
					newTask.start();
					System.out.println("Created Service:"+i);
				}else if(!userServices.get(i).getStatus()) {
					userServices.get(i).interrupt();
					userServices.set(i, null);
					System.out.println("Finish Service:"+i);
				}
			}
			// 2026-11-25: 쉬지 않고 도는 반복문이 CPU를 100% 쓰던 문제 → 잠깐씩 쉼
			try { Thread.sleep(20); } catch (InterruptedException e) { serviceMake=false; }
			
		}
		
	}
	boolean checkAPI(int i) {return i>=0&&i<api.size();}
	void createSocket(int port) throws IOException {sockets.add(new ServerSocket(port));}
	void createDatabase(SQLConnector c) {database.add(c);}
	ServerSocket getServerSocket(int idx) {return sockets.get(idx);}
	Object runApi(Context c,int idx,Object v) throws Exception {return api.get(idx).submit(c,v);}
	public Connection sqlConnector_CreateConnection(int selectDatabaseIndex) throws SQLException {return database.get(selectDatabaseIndex).createConnection();}
	public int sqlConnector_setQuery(int selectDatabaseIndex,String inputQuery) {return database.get(selectDatabaseIndex).setQuery("SELECT*FROM bicycle_warning_area");}
}
