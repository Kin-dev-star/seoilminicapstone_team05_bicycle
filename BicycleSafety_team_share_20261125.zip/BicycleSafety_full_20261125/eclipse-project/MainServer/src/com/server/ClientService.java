package com.server;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

import com.server.api.ApiRequest;
import com.server.api.ApiResponse;
import com.server.api.ApiRouter;

/**
 * 연결 1개를 처리하는 작업 스레드.
 * - /api/... : JSON API (카카오 로그인 검증, 사고 데이터 등) → ApiRouter
 * - 그 외 : 기존 방식 /<API번호><파라미터> (예: /1 사고 데이터 텍스트, /2아이디,비번,이름,true 회원가입)
 * 2026-11-25 변경: 요청 헤더·본문(POST)을 끝까지 읽고, 응답에 Content-Type/Content-Length를 붙임.
 * 기존 방식은 파라미터 뒤에 " HTTP/1.1"이 붙어 들어가던 문제를 고쳐 경로 부분만 전달합니다.
 */
public class ClientService extends Thread{
	boolean isActivity;
	int timeout;
	Context context;
	String baseURL;
	ServerSocket ss;
	Socket s;
	public ClientService(Context context,String url,int useServerSocketIDX,int timeout) {
		this.timeout=timeout;this.context=context;baseURL=url;
		ss=context.getServerSocket(useServerSocketIDX);
		isActivity=true;
	}
	public void run() {
		try {
			s=ss.accept();
			s.setSoTimeout(timeout);
			ApiRequest request=ApiRequest.read(new BufferedInputStream(s.getInputStream()));
			OutputStream out=s.getOutputStream();
			if(request!=null) {
				// 요청 경로만 기록 (토큰·본문은 기록하지 않음)
				System.out.println(request.method+" "+request.path);
				ApiResponse response;
				if(request.path.startsWith("/api/")) {
					response=ApiRouter.handle(context,request);
				}else {
					String get=request.path.length()>1?URLDecoder.decode(request.path.substring(1),StandardCharsets.UTF_8):"";
					String result="";
					if(!get.isEmpty()&&Character.isDigit(get.charAt(0))) {
						int selectHead=get.charAt(0)-'0';
						if(context.checkAPI(selectHead))
							result=String.valueOf(context.runApi(context,selectHead,(Object)get.substring(1)));
					}
					response=ApiResponse.text(200,result);
				}
				response.writeTo(out);
			}
		}catch(java.net.SocketTimeoutException e) {
			// 브라우저·폰이 연결만 미리 열고 요청을 안 보낸 경우 (정상, 기록 안 함)
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {if(s!=null)s.close();}catch(Exception e2) {}
		}
		isActivity=false;
	}
	public boolean getStatus() {return isActivity;}

}
