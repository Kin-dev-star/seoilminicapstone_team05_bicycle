package com.server;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// 2026-11-25: 포트·DB 계정·카카오 앱 ID를 server.properties 에서 읽음 (없으면 기존 기본값 8088, root/root)
		ServerConfig config=ServerConfig.load();
		Context context=new Context();
		context.createSocket(config.port);
		context.createDatabase(new SQLConnector(config.dbUrl,config.dbUser,config.dbPassword));
		com.server.api.ApiRouter.init(context,config);
		System.out.println("서버 시작: 포트 "+config.port+" (휴대폰에서는 http://이PC의IP:"+config.port+" 로 접속)");
		context.startService();
		System.out.println("finish server");
	}

}
