package com.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLConnector {
	String url="jdbc:mysql://localhost:3306/NKK_DATABASE";
	String user="root";
	String password="root";
	public SQLConnector(String url,String user,String pass) {
		this.url=url;this.user=user;this.password=pass;
	}
	public Connection createConnection() throws SQLException {
		return DriverManager.getConnection(url,user,password);
	}
	public int getQuery(ResultSetAdapter s,String query) {
		try(Connection conn=DriverManager.getConnection(url,user,password)){
			Statement ps=conn.createStatement();
			s.s=ps.executeQuery(query);
			while(s.s.next()) {
				System.out.println(s.s.getString("AREA_NAME"));
			}
			conn.close();
//			ps.close();
		}catch(Exception e) {e.printStackTrace();return 1;}
		return 0;
	}
	public int setQuery(String query) {
		try(Connection conn=DriverManager.getConnection(url,user,password)){
			PreparedStatement ps=conn.prepareStatement("INSERT INTO bicycle_warning_area(LATITUDE,HARDNESS,WARNING_LEVEL,RADIUS,AREA_NAME) VALUES(1.0,1.0,1.0,1.0,\"name\")");
			ps.executeUpdate();
			conn.close();
			ps.close();
		}catch(Exception e) {e.printStackTrace();return 1;}
		return 0;
	}
}
