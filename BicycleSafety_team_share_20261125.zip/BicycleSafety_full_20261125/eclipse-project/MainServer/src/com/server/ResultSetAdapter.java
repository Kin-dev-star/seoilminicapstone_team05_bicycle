package com.server;

import java.sql.ResultSet;

public class ResultSetAdapter {
	public ResultSet s;
}
