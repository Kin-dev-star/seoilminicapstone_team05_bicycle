package com.server.api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** 소켓에서 읽은 HTTP 요청 (요청 줄 + 헤더 + 본문). 헤더 이름은 소문자로 저장 */
public final class ApiRequest {
    private static final int MAX_HEADER_BYTES = 16 * 1024;
    private static final int MAX_BODY_BYTES = 1024 * 1024;

    public final String method;
    /** '?' 앞부분 (예: /api/auth/kakao, /1) */
    public final String path;
    public final Map<String, String> query;
    public final Map<String, String> headers;
    public final String body;

    private ApiRequest(String method, String path, Map<String, String> query, Map<String, String> headers, String body) {
        this.method = method; this.path = path; this.query = query; this.headers = headers; this.body = body;
    }

    public String header(String name) {
        return headers.get(name.toLowerCase());
    }

    /** 요청을 읽습니다. 빈 연결이면 null */
    public static ApiRequest read(InputStream in) throws IOException {
        String head = readHead(in);
        if (head == null || head.isBlank()) return null;
        String[] lines = head.split("\r\n");
        String[] first = lines[0].split(" ");
        if (first.length < 2) throw new IOException("잘못된 요청 줄");
        String method = first[0].trim().toUpperCase();
        String target = first[1].trim();
        Map<String, String> headers = new LinkedHashMap<>();
        for (int k = 1; k < lines.length; k++) {
            int colon = lines[k].indexOf(':');
            if (colon > 0) headers.put(lines[k].substring(0, colon).trim().toLowerCase(), lines[k].substring(colon + 1).trim());
        }
        String path = target, rawQuery = "";
        int q = target.indexOf('?');
        if (q >= 0) { path = target.substring(0, q); rawQuery = target.substring(q + 1); }
        Map<String, String> query = new LinkedHashMap<>();
        for (String pair : rawQuery.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = eq >= 0 ? pair.substring(0, eq) : pair;
            String v = eq >= 0 ? pair.substring(eq + 1) : "";
            query.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        int length = 0;
        try { length = Integer.parseInt(headers.getOrDefault("content-length", "0")); } catch (NumberFormatException ignored) { }
        if (length < 0 || length > MAX_BODY_BYTES) throw new IOException("요청 본문이 너무 큽니다");
        byte[] body = in.readNBytes(length);
        return new ApiRequest(method, path, query, headers, new String(body, StandardCharsets.UTF_8));
    }

    /** 빈 줄(\r\n\r\n)까지 읽기 */
    private static String readHead(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int b, state = 0;
        while ((b = in.read()) != -1) {
            out.write(b);
            if (out.size() > MAX_HEADER_BYTES) throw new IOException("요청 헤더가 너무 큽니다");
            if ((state == 0 || state == 2) && b == '\r') state++;
            else if ((state == 1 || state == 3) && b == '\n') state++;
            else state = b == '\r' ? 1 : 0;
            if (state == 4) break;
        }
        if (out.size() == 0) return null;
        return out.toString(StandardCharsets.UTF_8).trim();
    }
}
