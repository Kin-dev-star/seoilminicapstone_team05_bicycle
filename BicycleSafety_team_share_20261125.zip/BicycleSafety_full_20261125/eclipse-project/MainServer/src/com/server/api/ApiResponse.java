package com.server.api;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** HTTP 응답 (상태 줄 + Content-Type/Content-Length 헤더 + 본문) */
public final class ApiResponse {
    public final int status;
    public final String contentType;
    public final byte[] body;

    private ApiResponse(int status, String contentType, String body) {
        this.status = status;
        this.contentType = contentType;
        this.body = body.getBytes(StandardCharsets.UTF_8);
    }

    public static ApiResponse json(int status, Map<String, Object> body) {
        return new ApiResponse(status, "application/json; charset=utf-8", MiniJson.stringify(body));
    }

    public static ApiResponse rawJson(int status, String json) {
        return new ApiResponse(status, "application/json; charset=utf-8", json);
    }

    public static ApiResponse text(int status, String text) {
        return new ApiResponse(status, "text/plain; charset=utf-8", text == null ? "" : text);
    }

    public static ApiResponse error(int status, String message) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ok", false);
        m.put("error", message);
        return json(status, m);
    }

    public void writeTo(OutputStream out) throws IOException {
        String head = "HTTP/1.1 " + status + " " + reason(status) + "\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }

    private static String reason(int status) {
        switch (status) {
            case 200: return "OK";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 404: return "Not Found";
            case 405: return "Method Not Allowed";
            case 503: return "Service Unavailable";
            default: return status >= 500 ? "Internal Server Error" : "OK";
        }
    }
}
