package com.server.api;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 기존 /1 API가 보내던 사고다발지역 텍스트(src/res/output.txt, 15줄 = 1건)를
 * 앱이 바로 쓰는 JSON {"ok":true,"items":[{id,name,latitude,longitude,accidentCount,casualtyCount}]} 으로 바꿉니다.
 * 열 순서: fid, id, 법정동코드, 지점코드, 시도시군구명, 지점명, 사고건수, 사상자수, 사망자수, 중상자수, 경상자수,
 *          부상신고자수, 경도, 위도, 다발지역폴리곤
 */
public final class HazardData {
    private HazardData() {}
    private static final int COLUMNS = 15;
    private static String cachedJson;

    public static synchronized String json() throws Exception {
        if (cachedJson == null) cachedJson = MiniJson.stringify(build(readLines()));
        return cachedJson;
    }

    private static List<String> readLines() throws Exception {
        for (String candidate : new String[]{"src/res/output.txt", "res/output.txt", "bin/res/output.txt"}) {
            Path p = Path.of(candidate);
            if (Files.exists(p)) return Files.readAllLines(p, StandardCharsets.UTF_8);
        }
        throw new IllegalStateException("사고 데이터 파일(src/res/output.txt)을 찾을 수 없습니다.");
    }

    static Map<String, Object> build(List<String> lines) {
        // 한 건은 '다발지역폴리곤' 줄({"type":...)로 끝납니다. 지점명에 줄바꿈이 섞인 행이 있어(예: 중랑구 면목동)
        // 15줄씩 자르면 그 뒤가 모두 밀리므로, 폴리곤 줄을 기준으로 한 건씩 나눕니다.
        List<Object> items = new ArrayList<>();
        List<String> fields = new ArrayList<>();
        for (String raw : lines) {
            String line = raw.trim();
            if (line.startsWith("{")) {
                Map<String, Object> item = toItem(fields);
                if (item != null) items.add(item);
                fields.clear();
            } else if (!line.isEmpty()) {
                fields.add(line);
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ok", true);
        out.put("source", "KOROAD 서울 자전거 사고다발지역 (팀 서버)");
        out.put("count", items.size());
        out.put("items", items);
        return out;
    }

    /** 폴리곤 앞 필드: 앞 5개(fid, id, 법정동코드, 지점코드, 시도시군구명) + 지점명(여러 줄 가능) + 뒤 8개 숫자 */
    private static Map<String, Object> toItem(List<String> f) {
        if (f.size() < COLUMNS - 1) return null;
        try {
            int n = f.size();
            StringBuilder name = new StringBuilder();
            for (int k = 5; k < n - 8; k++) name.append(f.get(k));
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", f.get(0));
            item.put("name", name.toString());
            item.put("latitude", Double.parseDouble(f.get(n - 1)));
            item.put("longitude", Double.parseDouble(f.get(n - 2)));
            item.put("accidentCount", Long.parseLong(f.get(n - 8)));
            item.put("casualtyCount", Long.parseLong(f.get(n - 7)));
            return item;
        } catch (Exception skip) {
            return null; // 형식이 맞지 않는 행은 건너뜀
        }
    }
}
