package com.server.api;

import com.server.Context;
import com.server.ServerConfig;
import com.server.auth.AuthService;
import com.server.auth.KakaoTokenVerifier;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * /api/... JSON API. 기존 /1, /2 방식은 ClientService에서 그대로 처리합니다.
 *
 *  POST /api/auth/kakao   {"accessToken":"..."}  → 카카오 토큰 검증 후 세션 발급
 *  GET  /api/me           (Authorization: Bearer 세션) → 로그인 사용자
 *  POST /api/auth/logout  (Authorization: Bearer 세션) → 세션 삭제
 *  GET  /api/hazards      → 사고다발지역 JSON (앱 지도 표시용)
 *
 * 백엔드 담당이 즐겨찾기·주행 기록·제보 API를 추가할 때는 handle()에 경로를 더하고,
 * 로그인 사용자 확인은 auth.requireUser(request) 를 쓰면 됩니다 (README_SERVER_KAKAO_AUTH.md 참고).
 */
public final class ApiRouter {
    private ApiRouter() {}

    private static AuthService auth;
    private static KakaoTokenVerifier verifier;

    /** 서버 시작 시 1번 호출. DB 테이블 생성 실패는 로그만 남기고 서버는 계속 실행 */
    public static synchronized void init(Context context, ServerConfig config) {
        auth = new AuthService(context);
        verifier = new KakaoTokenVerifier(config.kakaoAppId);
        try {
            auth.ensureTables();
            System.out.println("로그인 테이블 준비 완료 (kakao_user, user_session)");
        } catch (SQLException e) {
            System.out.println("로그인 테이블 준비 실패 - MySQL 연결을 확인하세요: " + e.getMessage());
        }
        if (config.kakaoAppId <= 0) {
            System.out.println("경고: kakao.appId 미설정 → /api/auth/kakao 는 오류를 돌려줍니다.");
        }
    }

    public static ApiResponse handle(Context context, ApiRequest request) {
        if (auth == null) init(context, ServerConfig.current());
        try {
            String p = request.path;
            String m = request.method;
            if (p.equals("/api/auth/kakao")) return m.equals("POST") ? kakaoLogin(request) : notAllowed();
            if (p.equals("/api/auth/logout")) return m.equals("POST") ? logout(request) : notAllowed();
            if (p.equals("/api/me")) return m.equals("GET") ? me(request) : notAllowed();
            if (p.equals("/api/hazards")) return m.equals("GET") ? ApiResponse.rawJson(200, HazardData.json()) : notAllowed();
            if (p.equals("/api/health")) return ok(new LinkedHashMap<>());
            return ApiResponse.error(404, "없는 API입니다: " + p);
        } catch (KakaoTokenVerifier.VerifyException e) {
            return ApiResponse.error(e.status, e.getMessage());
        } catch (AuthService.UnauthorizedException e) {
            return ApiResponse.error(401, e.getMessage());
        } catch (SQLException e) {
            System.out.println("DB 오류: " + e.getMessage());
            return ApiResponse.error(503, "데이터베이스에 연결하지 못했습니다.");
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(400, "요청 형식이 올바르지 않습니다: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.error(500, "서버 오류가 발생했습니다.");
        }
    }

    private static ApiResponse kakaoLogin(ApiRequest request) throws Exception {
        Map<String, Object> body = MiniJson.parseObject(request.body.isBlank() ? "{}" : request.body);
        KakaoTokenVerifier.KakaoUser user = verifier.verify(MiniJson.str(body, "accessToken"));
        AuthService.Session session = auth.login(user);
        System.out.println("카카오 로그인 성공: 회원번호 " + user.id);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("kakaoId", session.kakaoId);
        out.put("nickname", session.nickname);
        out.put("sessionToken", session.token);
        out.put("expiresAt", session.expiresAt);
        return ok(out);
    }

    private static ApiResponse me(ApiRequest request) throws Exception {
        long kakaoId = auth.requireUser(request);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("kakaoId", kakaoId);
        out.put("nickname", auth.nicknameOf(kakaoId));
        return ok(out);
    }

    private static ApiResponse logout(ApiRequest request) throws Exception {
        auth.logout(request);
        return ok(new LinkedHashMap<>());
    }

    /** 다른 API에서 로그인 사용자 확인용 */
    public static AuthService auth() {
        return auth;
    }

    private static ApiResponse ok(Map<String, Object> fields) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ok", true);
        out.putAll(fields);
        return ApiResponse.json(200, out);
    }

    private static ApiResponse notAllowed() {
        return ApiResponse.error(405, "지원하지 않는 요청 방식입니다.");
    }
}
