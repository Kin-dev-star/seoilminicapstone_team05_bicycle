package com.server.auth;

import com.server.api.MiniJson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

/**
 * 앱이 보낸 카카오 액세스 토큰을 카카오 서버에 직접 확인합니다.
 * 1) GET https://kapi.kakao.com/v1/user/access_token_info → 토큰 유효 + app_id 가 우리 앱 ID와 같은지 확인
 *    (다른 앱에서 받은 토큰으로 로그인하는 것을 막음)
 * 2) GET https://kapi.kakao.com/v2/user/me → 회원번호(id)·닉네임
 * 토큰 원문은 로그에 남기지 않습니다.
 */
public final class KakaoTokenVerifier {
    private static final String TOKEN_INFO_URL = "https://kapi.kakao.com/v1/user/access_token_info";
    private static final String USER_ME_URL = "https://kapi.kakao.com/v2/user/me";

    public static final class KakaoUser {
        public final long id;
        public final String nickname;
        public KakaoUser(long id, String nickname) { this.id = id; this.nickname = nickname == null ? "" : nickname; }
    }

    public static final class VerifyException extends Exception {
        public final int status;
        public VerifyException(int status, String message) { super(message); this.status = status; }
    }

    private final long expectedAppId;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    public KakaoTokenVerifier(long expectedAppId) {
        this.expectedAppId = expectedAppId;
    }

    public KakaoUser verify(String accessToken) throws VerifyException {
        if (accessToken == null || accessToken.isBlank() || accessToken.length() > 1024) {
            throw new VerifyException(400, "accessToken 이 필요합니다.");
        }
        if (expectedAppId <= 0) {
            throw new VerifyException(500, "서버 설정에 카카오 앱 ID(kakao.appId)가 없습니다. server.properties를 확인하세요.");
        }
        Map<String, Object> info = getJson(TOKEN_INFO_URL, accessToken);
        long appId = MiniJson.num(info, "app_id", -1);
        long id = MiniJson.num(info, "id", -1);
        if (appId != expectedAppId) {
            throw new VerifyException(401, "다른 앱에서 발급된 카카오 토큰입니다.");
        }
        Map<String, Object> me = getJson(USER_ME_URL, accessToken);
        if (MiniJson.num(me, "id", -2) != id) {
            throw new VerifyException(401, "카카오 사용자 정보가 토큰과 일치하지 않습니다.");
        }
        return new KakaoUser(id, nicknameOf(me));
    }

    private static String nicknameOf(Map<String, Object> me) {
        String nickname = MiniJson.str(MiniJson.obj(me.get("properties")), "nickname");
        if (nickname == null) {
            Map<String, Object> account = MiniJson.obj(me.get("kakao_account"));
            nickname = MiniJson.str(MiniJson.obj(account == null ? null : account.get("profile")), "nickname");
        }
        return nickname == null ? "" : nickname;
    }

    private Map<String, Object> getJson(String url, String accessToken) throws VerifyException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Authorization", "Bearer " + accessToken)
                .GET()
                .build();
        HttpResponse<String> response;
        try {
            response = http.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new VerifyException(503, "카카오 서버 확인이 중단되었습니다.");
        } catch (Exception e) {
            throw new VerifyException(503, "카카오 서버에 연결하지 못했습니다: " + e.getMessage());
        }
        if (response.statusCode() == 401) throw new VerifyException(401, "유효하지 않거나 만료된 카카오 토큰입니다.");
        if (response.statusCode() != 200) throw new VerifyException(502, "카카오 토큰 확인 실패 (HTTP " + response.statusCode() + ")");
        try {
            return MiniJson.parseObject(response.body());
        } catch (Exception e) {
            throw new VerifyException(502, "카카오 응답을 읽지 못했습니다.");
        }
    }
}
