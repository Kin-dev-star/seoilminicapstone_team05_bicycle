package com.server.auth;

import com.server.Context;
import com.server.api.ApiRequest;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

/**
 * 카카오 로그인 사용자와 서버 세션 관리 (MySQL).
 * - kakao_user: 카카오 회원번호, 닉네임
 * - user_session: 세션 토큰의 SHA-256 해시(원문은 저장하지 않음), 만료 시각(30일)
 * 다른 API(즐겨찾기·주행 기록·제보)는 requireUser()로 로그인 사용자를 확인하면 됩니다.
 */
public final class AuthService {
    public static final long SESSION_DAYS = 30;
    private static final SecureRandom RANDOM = new SecureRandom();
    private final Context context;

    public static final class Session {
        public final long kakaoId;
        public final String nickname;
        public final String token;
        public final long expiresAt;
        Session(long kakaoId, String nickname, String token, long expiresAt) {
            this.kakaoId = kakaoId; this.nickname = nickname; this.token = token; this.expiresAt = expiresAt;
        }
    }

    public static final class UnauthorizedException extends Exception {
        public UnauthorizedException(String message) { super(message); }
    }

    public AuthService(Context context) {
        this.context = context;
    }

    /** 서버 시작 시 테이블이 없으면 만듭니다 (sql/schema.sql 과 같은 내용) */
    public void ensureTables() throws SQLException {
        try (Connection c = context.sqlConnector_CreateConnection(0); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS kakao_user ("
                    + "kakao_id BIGINT PRIMARY KEY,"
                    + "nickname VARCHAR(100) NOT NULL DEFAULT '',"
                    + "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                    + "last_login_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
                    + ") DEFAULT CHARSET=utf8mb4");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS user_session ("
                    + "token_hash CHAR(64) PRIMARY KEY,"
                    + "kakao_id BIGINT NOT NULL,"
                    + "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                    + "expires_at TIMESTAMP NOT NULL,"
                    + "INDEX idx_session_user (kakao_id),"
                    + "CONSTRAINT fk_session_user FOREIGN KEY (kakao_id) REFERENCES kakao_user(kakao_id) ON DELETE CASCADE"
                    + ") DEFAULT CHARSET=utf8mb4");
        }
    }

    /** 검증된 카카오 사용자를 저장(처음이면 가입)하고 새 세션 발급 */
    public Session login(KakaoTokenVerifier.KakaoUser user) throws SQLException {
        String token = newToken();
        long expiresAt = System.currentTimeMillis() + SESSION_DAYS * 24L * 60 * 60 * 1000;
        try (Connection c = context.sqlConnector_CreateConnection(0)) {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO kakao_user(kakao_id, nickname) VALUES(?, ?) "
                            + "ON DUPLICATE KEY UPDATE nickname = VALUES(nickname), last_login_at = CURRENT_TIMESTAMP")) {
                ps.setLong(1, user.id);
                ps.setString(2, user.nickname);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO user_session(token_hash, kakao_id, expires_at) VALUES(?, ?, ?)")) {
                ps.setString(1, sha256(token));
                ps.setLong(2, user.id);
                ps.setTimestamp(3, new Timestamp(expiresAt));
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "DELETE FROM user_session WHERE expires_at < CURRENT_TIMESTAMP")) {
                ps.executeUpdate();
            }
        }
        return new Session(user.id, user.nickname, token, expiresAt);
    }

    /** Authorization: Bearer 세션토큰 → 카카오 회원번호. 없거나 만료면 UnauthorizedException */
    public long requireUser(ApiRequest request) throws UnauthorizedException, SQLException {
        String token = bearer(request);
        if (token == null) throw new UnauthorizedException("로그인이 필요합니다.");
        try (Connection c = context.sqlConnector_CreateConnection(0);
             PreparedStatement ps = c.prepareStatement(
                     "SELECT kakao_id FROM user_session WHERE token_hash = ? AND expires_at > CURRENT_TIMESTAMP")) {
            ps.setString(1, sha256(token));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getLong(1);
            }
        }
        throw new UnauthorizedException("로그인이 만료되었습니다. 다시 로그인해 주세요.");
    }

    public String nicknameOf(long kakaoId) throws SQLException {
        try (Connection c = context.sqlConnector_CreateConnection(0);
             PreparedStatement ps = c.prepareStatement("SELECT nickname FROM kakao_user WHERE kakao_id = ?")) {
            ps.setLong(1, kakaoId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : "";
            }
        }
    }

    public void logout(ApiRequest request) throws SQLException {
        String token = bearer(request);
        if (token == null) return;
        try (Connection c = context.sqlConnector_CreateConnection(0);
             PreparedStatement ps = c.prepareStatement("DELETE FROM user_session WHERE token_hash = ?")) {
            ps.setString(1, sha256(token));
            ps.executeUpdate();
        }
    }

    public static String bearer(ApiRequest request) {
        String h = request.header("authorization");
        if (h == null || !h.regionMatches(true, 0, "Bearer ", 0, 7)) return null;
        String token = h.substring(7).trim();
        return token.isEmpty() || token.length() > 200 ? null : token;
    }

    private static String newToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return hex(bytes);
    }

    static String sha256(String text) {
        try {
            return hex(MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder b = new StringBuilder(bytes.length * 2);
        for (byte x : bytes) b.append(String.format("%02x", x & 0xff));
        return b.toString();
    }
}
