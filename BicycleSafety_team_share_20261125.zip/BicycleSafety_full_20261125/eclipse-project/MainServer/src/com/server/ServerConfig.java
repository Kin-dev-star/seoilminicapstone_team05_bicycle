package com.server;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * 서버 설정. 작업 폴더(Eclipse에서는 MainServer 폴더)의 server.properties 를 읽고,
 * 같은 이름의 환경변수가 있으면 그 값을 우선합니다. 파일이 없으면 기존 기본값(8088, root/root)을 그대로 씁니다.
 * server.properties 는 비밀번호·앱 ID가 들어가므로 GitHub에 올리지 않습니다 (server.properties.example 참고).
 */
public final class ServerConfig {
    public final int port;
    public final String dbUrl;
    public final String dbUser;
    public final String dbPassword;
    /** 카카오 디벨로퍼스 '앱 ID'(숫자). 토큰이 우리 앱에서 발급됐는지 확인할 때 사용 */
    public final long kakaoAppId;

    private static ServerConfig current;

    private ServerConfig(int port, String dbUrl, String dbUser, String dbPassword, long kakaoAppId) {
        this.port = port; this.dbUrl = dbUrl; this.dbUser = dbUser; this.dbPassword = dbPassword;
        this.kakaoAppId = kakaoAppId;
    }

    public static synchronized ServerConfig load() {
        Properties p = new Properties();
        Path file = Path.of("server.properties");
        if (Files.exists(file)) {
            try (InputStream in = new FileInputStream(file.toFile())) {
                p.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
                System.out.println("설정 파일 읽음: " + file.toAbsolutePath());
            } catch (Exception e) {
                System.out.println("server.properties 읽기 실패, 기본값 사용: " + e.getMessage());
            }
        } else {
            System.out.println("server.properties 없음 → 기본값 사용 (카카오 로그인 검증은 kakao.appId 설정 후 동작)");
        }
        int port = parseInt(value(p, "server.port", "SERVER_PORT", "8088"), 8088);
        String url = value(p, "db.url", "DB_URL", "jdbc:mysql://localhost:3306/NKK_DATABASE");
        String user = value(p, "db.user", "DB_USER", "root");
        String pass = value(p, "db.password", "DB_PASSWORD", "root");
        long appId = parseLong(value(p, "kakao.appId", "KAKAO_APP_ID", "0"), 0);
        current = new ServerConfig(port, url, user, pass, appId);
        return current;
    }

    public static synchronized ServerConfig current() {
        return current != null ? current : load();
    }

    private static String value(Properties p, String key, String env, String fallback) {
        String fromEnv = System.getenv(env);
        if (fromEnv != null && !fromEnv.isBlank()) return fromEnv.trim();
        String fromFile = p.getProperty(key);
        return fromFile != null && !fromFile.isBlank() ? fromFile.trim() : fallback;
    }

    private static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return fallback; }
    }
}
