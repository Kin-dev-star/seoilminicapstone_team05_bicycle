package com.data.manager;

public class DataContext {

}
