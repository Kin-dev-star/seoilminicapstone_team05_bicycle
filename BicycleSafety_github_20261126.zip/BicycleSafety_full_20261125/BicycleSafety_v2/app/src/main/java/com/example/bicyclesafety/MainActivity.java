package com.example.bicyclesafety;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.PowerManager;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.os.SystemClock;
import com.kakao.vectormap.label.Label;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import java.util.Comparator;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import androidx.compose.ui.platform.ComposeView;

import com.example.app.ui.BikeUiBridge;
import com.example.app.ui.RouteChoiceUi;
import com.example.app.ui.RecentRouteUi;
import com.example.bicyclesafety.data.AppRepositories;
import com.example.bicyclesafety.data.RideRecord;
import com.example.bicyclesafety.data.SessionStore;
import com.example.bicyclesafety.data.UserSession;
import com.kakao.vectormap.label.TransformMethod;
import com.kakao.vectormap.GestureType;
import com.kakao.vectormap.KakaoMap;
import com.kakao.vectormap.KakaoMapReadyCallback;
import com.kakao.vectormap.MapOverlay;
import com.kakao.vectormap.LatLng;
import com.kakao.vectormap.MapLifeCycleCallback;
import com.kakao.vectormap.MapView;
import com.kakao.vectormap.camera.CameraUpdateFactory;
import com.kakao.vectormap.route.RouteLineLayer;
import com.kakao.vectormap.route.RouteLineOptions;
import com.kakao.vectormap.route.RouteLineSegment;
import com.kakao.vectormap.route.RouteLineStyle;
import com.kakao.vectormap.route.RouteLineStyles;
import com.kakao.vectormap.route.RouteLineStylesSet;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.kakao.vectormap.label.LabelLayer;
import com.kakao.vectormap.label.LabelLayerOptions;
import com.kakao.vectormap.label.LabelOptions;
import com.kakao.vectormap.label.LabelStyle;
import com.kakao.vectormap.label.LabelTextBuilder;
import com.kakao.vectormap.shape.DotPoints;
import com.kakao.vectormap.shape.PolygonOptions;
import com.kakao.vectormap.shape.PolygonStyles;
import com.kakao.vectormap.shape.PolygonStylesSet;

/**
 * Java feature layer retained from the tested 11/11 project.
 * Compose owns the screen; Kakao MapView and hazard callbacks remain here.
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "BicycleSafety";
    /** 시작 단계 진단 로그. 검은 화면일 때 Logcat 검색어: BicycleSafetyStartup */
    private static final String STARTUP_TAG = "BicycleSafetyStartup";
    /** 최대 확대·축소 시 지도 튕김 방지를 위한 카메라 줌 범위 (카카오맵 레벨) */
    private static final int MIN_CAMERA_LEVEL = 10;
    private static final int MAX_CAMERA_LEVEL = 18;
    /**
     * 내 위치 표시가 지도 확대·축소에 맞춰 커지고 작아지도록 줌 레벨별 크기를 나눕니다.
     * 카카오 LabelStyle은 낮은 줌 레벨부터 순서대로 넣어야 합니다.
     */
    private static final int[] MARKER_ZOOM_LEVELS = {0, 12, 13, 14, 15, 16, 17, 18};
    private static final int[] NAV_ARROW_ICONS = {
            R.drawable.ic_nav_self_arrow_z10, R.drawable.ic_nav_self_arrow_z12,
            R.drawable.ic_nav_self_arrow_z13, R.drawable.ic_nav_self_arrow_z14,
            R.drawable.ic_nav_self_arrow_z15, R.drawable.ic_nav_self_arrow_z16,
            R.drawable.ic_nav_self_arrow_z17, R.drawable.ic_nav_self_arrow};
    private static final int[] LOCATION_DOT_SIZES = {22, 26, 30, 34, 38, 42, 46, 50};
    private MapView mapView;
    private boolean isMapStarted = false;
    private boolean isSafetyConfirmed = false;
    private KakaoMap activeMap;
    private RouteLineLayer routeLayer;
    private KakaoRouteRepository.Result pendingRoute;
    private final ExecutorService routeWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService hazardWorker = Executors.newSingleThreadExecutor();
    private final List<RiskPoint> hazardPoints = new ArrayList<>();
    // 경로 검색 후에는 GPS 갱신이 있어도 경로 주변 사고 마커를 유지합니다.
    private final List<RiskPoint> routeHazardsVisible = new ArrayList<>();
    private boolean lastRouteBicycleFirst = true;
    private final Map<Integer, KakaoRouteRepository.Result> comparedRoutes = new HashMap<>();
    private final List<RouteChoiceUi> comparedUi = new ArrayList<>();
    private int currentRouteMode = 2; // 0 사고이력 최소, 1 최단, 2 자전거도로
    private final ExecutorService placeWorker = Executors.newSingleThreadExecutor();
    private int placeSearchRevision = 0;
    private boolean pendingOriginLocation = false;
    private String hazardSource = "미수신";
    private Label currentLocationLabel;
    private boolean currentMarkerNavigation = false;
    private Location lastLocation;
    private Location markerCenterLocation;
    private LocationManager locationManager;
    private LocationListener locationListener;
    /** Google Fused 위치(GPS+Wi-Fi+기지국). Play 서비스가 없으면 null → 기존 LocationManager 사용 */
    private FusedLocationProviderClient fusedClient;
    private LocationCallback fusedCallback;
    private CancellationTokenSource quickFixCancel;
    /** 경로 검색 출발지 후보 (오차 100m·2분 이내). 주행·도착·위험 판정에는 쓰지 않음 */
    private Location lastOriginCandidate;
    /** 경로 미리보기 카드 높이(px). 전체 경로가 카드에 가리지 않게 카메라를 맞출 때 사용 */
    private int previewPanelHeightPx = 0;
    /** 마지막 경로 검색의 출발지가 현재 위치(GPS)였는지 → 미리보기 버튼 '안내 시작' / '내 위치에서 안내' */
    private boolean lastRouteFromGps = true;
    /** '내 위치에서 안내'를 누른 경우: 경로 검색이 끝나면 바로 안내 시작 */
    private boolean startGuidanceAfterAnalysis = false;
    /** 안내 중 지도가 내 위치를 따라가는지. 손으로 지도를 움직이면 꺼지고 '내 위치' 버튼으로 다시 켬 */
    private volatile boolean followMyLocation = true;
    /** 주행 기록: 안내 시작 시각, GPS로 실제 이동한 거리, 출발지 이름 */
    private long rideStartedAt = 0;
    private double rideDistanceMeters = 0;
    private String rideOriginName = "";
    /** 재탐색 전 경로에서 이미 지나간 사고 다발 구간 수 */
    private int rideZonesPassedBase = 0;
    /** 설정 화면에서 바꾼 값을 바로 반영 (리스너는 약하게 참조되므로 필드로 보관) */
    private final SharedPreferences.OnSharedPreferenceChangeListener settingsListener =
            (prefs, key) -> runOnUiThread(() -> onSettingChanged(key));
    /** 주행 시뮬레이션(시연 모드): 경로를 따라 가짜 GPS를 1초마다 넣어 실내에서 안내·경고·백그라운드를 확인 */
    public static final String SIMULATION_PROVIDER = "simulation";
    private static final double SIMULATION_SPEED_MPS = 6.0;   // 약 21.6 km/h
    private static final long SIMULATION_TICK_MS = 1000L;
    private boolean simulationActive = false;
    private final Handler simulationHandler = new Handler(Looper.getMainLooper());
    private Runnable simulationTick;
    private PowerManager.WakeLock simulationWakeLock;
    private boolean trackingLocation = false;
    private boolean centerOnNextLocation = false;
    private boolean approximateCenteredOnce = false;
    // 실기기에서는 GPS 진행방향이 아닌 휴대폰의 실제 방위(회전 벡터)를 사용합니다.
    private SensorManager sensorManager;
    private Sensor directionSensor;
    private SensorEventListener directionListener;
    private boolean directionSensorRegistered = false;
    private float deviceHeadingDegrees = Float.NaN;
    private long lastHeadingUpdateMs = 0;
    private long lastQuickFixRequestMs = 0;
    private boolean pendingGuidancePermission = false;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean guidanceActive = false;
    // ── 내비게이션 화면 상태 ──
    private NavigationTracker navTracker;
    private int lastPreAnnouncedStep = -1;   // "150미터 앞에서 ~" 안내를 한 단계
    private int lastSpokenStep = -1;         // 회전 직전 안내를 한 단계
    /** 안내 중 경로 앞쪽 사고 다발 구간 (300m 전 위젯, 300m·100m 음성) */
    private HazardAheadGuide hazardAhead;
    private int offRouteCount = 0;           // 연속으로 경로를 벗어난 위치 수
    private long lastRerouteAt = 0;
    private boolean rerouting = false;
    private Location previousNavLocation;
    // 저정확도/오래된/순간적으로 튄 좌표로 도착을 오판하지 않도록 상태를 분리합니다.
    private final NavigationGpsGuard navigationGpsGuard = new NavigationGpsGuard();
    private boolean gpsUnstableMessageShown = false;
    private static final double OFF_ROUTE_METERS = 40.0;
    private static final int NAV_ZOOM = 17;
    private final RiskWarningGate riskWarningGate = new RiskWarningGate();
    private static final int LOCATION_REQUEST = 501;
    private static final int NOTIFICATION_REQUEST = 502;
    /** 백그라운드 안내 알림 갱신 간격 제한 */
    private long lastNavNotificationMs = 0;
    private int lastNavNotificationStep = -2;
    private static final double WARNING_DISTANCE_METERS = 150.0;
    private static final double ROUTE_HAZARD_METERS = 150.0;
    // 접근 경고 범위 표시: 반경이 다른 반투명 원을 겹쳐 가운데가 진한 그라데이션처럼 보이게 함
    private static final int ZONE_RINGS = 5;
    private static final int ZONE_RING_ALPHA = 20;      // 원 하나의 투명도 (0~255)
    private static final int ZONE_EDGE_ALPHA = 110;     // 150m 경계선 투명도
    private static final int MAX_WARNING_ZONES = 40;    // 지도 부하를 줄이려고 가까운 지점만 표시
    private int routeRequestRevision = 0;
    private boolean routeRequestInProgress = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppPrefs.prefs(this).registerOnSharedPreferenceChangeListener(settingsListener);
        Log.i(STARTUP_TAG, "1. onCreate 시작 (복원=" + (savedInstanceState != null) + ")");
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null) {
            isSafetyConfirmed = savedInstanceState.getBoolean("safety_confirmed", false);
        }
        BikeUiBridge.attach(this, (ComposeView) findViewById(R.id.compose_root),
                !isSafetyConfirmed);
        Log.i(STARTUP_TAG, "2. Compose 화면 연결 완료 (안전 안내 필요=" + !isSafetyConfirmed + ")");
        publishRecentRoutes(RecentRouteStore.load(this));
        publishAccount(SessionStore.load(this), null);
        // 지도/팝업/안내 UI가 만든 직후 실제 사고 기록을 백그라운드에서 읽습니다.
        loadRiskData();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = location -> runOnUiThread(() -> onLocationChanged(location));
        setUpFusedLocation();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            directionSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (directionSensor == null) directionSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
            directionListener = new SensorEventListener() {
                @Override public void onSensorChanged(SensorEvent event) {
                    float[] rotation = new float[9];
                    float[] values = new float[3];
                    SensorManager.getRotationMatrixFromVector(rotation, event.values);
                    SensorManager.getOrientation(rotation, values);
                    float next = (float)((Math.toDegrees(values[0]) + 360.0) % 360.0);
                    if (Float.isNaN(deviceHeadingDegrees)) deviceHeadingDegrees = next;
                    else {
                        // 359도→0도 전환 시에도 자연스럽게 회전하도록 최단 각도로 보간.
                        float delta = (next - deviceHeadingDegrees + 540f) % 360f - 180f;
                        deviceHeadingDegrees = (deviceHeadingDegrees + delta * 0.28f + 360f) % 360f;
                    }
                    long now = SystemClock.elapsedRealtime();
                    if (now - lastHeadingUpdateMs >= 90) {
                        lastHeadingUpdateMs = now;
                        if (guidanceActive && currentLocationLabel != null) {
                            try { currentLocationLabel.rotateTo((float)Math.toRadians(deviceHeadingDegrees)); }
                            catch (Exception e) { Log.w(TAG, "폰 방향 마커 회전 실패", e); }
                        }
                    }
                }
                @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
            };
        }
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                int languageResult = textToSpeech.setLanguage(Locale.KOREAN);
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA
                        && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        // MapView는 안전 팝업을 확인하고 화면에 붙은 후에만 시작합니다.
    }

    /** Called by AndroidView once the new screen is ready to host the real map. */
    public View acquireMapView() {
        if (mapView == null) {
            Log.i(STARTUP_TAG, "3. MapView 생성");
            mapView = new MapView(this);
            // start() after AndroidView attaches the MapView; avoids early-start races.
            mapView.post(this::startMapAfterSafety);
        }
        return mapView;
    }

    /** The Compose-designed safety dialog calls these; map gate is unchanged. */
    public void onSafetyConfirmed() {
        Log.i(STARTUP_TAG, "4. 안전 안내 확인");
        isSafetyConfirmed = true;
        startMapAfterSafety();
        // 갤럭시 실제 GPS 자동 요청: 수동 호천관 위치는 사용하지 않음
        onCurrentLocationRequested();
    }

    public void onSafetyExit() {
        finish();
    }

    private void startMapAfterSafety() {
        if (!isSafetyConfirmed || mapView == null || isMapStarted) return;
        if (BuildConfig.KAKAO_NATIVE_APP_KEY.isEmpty()) {
            Toast.makeText(this, "카카오 네이티브 앱 키가 없습니다. local.properties를 확인해 주세요.", Toast.LENGTH_LONG).show();
            return;
        }
        isMapStarted = true;
        Log.i(STARTUP_TAG, "5. 카카오맵 시작 요청");
        mapView.start(new MapLifeCycleCallback() {
            @Override
            public void onMapDestroy() {
                Log.d(TAG, "지도 종료");
                runOnUiThread(() -> {
                    isMapStarted = false;
                    activeMap = null;
                    routeLayer = null;
                });
            }

            @Override
            public void onMapError(Exception error) {
                Log.e(TAG, "카카오맵 시작 오류", error);
                Log.e(STARTUP_TAG, "5-오류. 카카오맵 시작 실패: " + error);
                runOnUiThread(() -> {
                    isMapStarted = false;
                    Toast.makeText(MainActivity.this,
                            "카카오맵을 불러오지 못했습니다. 인증과 네트워크를 확인하세요.",
                            Toast.LENGTH_LONG).show();
                });
            }
        }, new KakaoMapReadyCallback() {
            @Override
            public void onMapReady(KakaoMap kakaoMap) {
                Log.d(TAG, "카카오맵 연결 성공");
                Log.i(STARTUP_TAG, "6. 카카오맵 준비 완료");
                activeMap = kakaoMap;
                applyCameraZoomLimits(kakaoMap);
                applyBikeLaneOverlay();
                routeLayer = kakaoMap.getRouteLineManager().getLayer();
                // Render a route retrieved before map initialization, if any.
                if (pendingRoute != null && !showRouteOnMap(pendingRoute)) {
                    pendingRoute = null;
                    routeHazardsVisible.clear();
                    BikeUiBridge.routeFailed("경로선 표시 실패: 지도 로그를 확인해 주세요.");
                }
                refreshHazardMarkers(pendingRoute == null ? null : routeHazardsVisible);
                if (lastLocation != null) moveCameraToLocation(lastLocation);

                // 안내 중 사용자가 지도를 직접 움직이면 자동 따라가기를 멈추고 '내 위치' 버튼을 보여 줌
                kakaoMap.setOnCameraMoveStartListener((map, gestureType) -> {
                    if (guidanceActive && followMyLocation && gestureType != GestureType.Unknown) {
                        Log.d(TAG, "사용자 지도 조작: " + gestureType + " → 내 위치 따라가기 해제");
                        followMyLocation = false;
                        runOnUiThread(() -> BikeUiBridge.navFollowing(false));
                    }
                });

                kakaoMap.setOnLabelClickListener((map, layer, label) -> {
                    Object tag = label.getTag();
                    if (tag instanceof RiskPoint) {
                        RiskPoint clickedPoint = (RiskPoint) tag;
                        runOnUiThread(() -> BikeUiBridge.displayRiskPoint(clickedPoint));
                        return true;
                    }
                    return false;
                });
            }

            @Override
            public LatLng getPosition() {
                return lastLocation == null ? LatLng.from(37.5665, 126.9780)
                        : LatLng.from(lastLocation.getLatitude(), lastLocation.getLongitude());
            }

            @Override
            public int getZoomLevel() { return 15; }
        });
    }

    /**
     * 손가락으로 최대 확대·축소할 때 지도가 튕기던 문제를 줄이려고 카메라 줌을 10~18레벨로 제한합니다.
     * SDK가 허용하는 범위(getMinZoomLevel~getMaxZoomLevel)를 벗어나지 않도록 맞춥니다.
     * 네이티브 그래픽 문제가 원인이라면 이 제한만으로 해결되지 않을 수 있습니다.
     */
    private void applyCameraZoomLimits(KakaoMap kakaoMap) {
        try {
            int min = Math.max(MIN_CAMERA_LEVEL, kakaoMap.getMinZoomLevel());
            int max = Math.min(MAX_CAMERA_LEVEL, kakaoMap.getMaxZoomLevel());
            if (min > max) {
                Log.w(TAG, "줌 제한 생략: SDK 범위 " + kakaoMap.getMinZoomLevel() + "~" + kakaoMap.getMaxZoomLevel());
                return;
            }
            kakaoMap.setCameraMinLevel(min);
            kakaoMap.setCameraMaxLevel(max);
            Log.i(STARTUP_TAG, "지도 줌 제한 적용: " + min + "~" + max);
        } catch (Exception error) {
            Log.w(TAG, "지도 줌 제한 설정 실패", error);
        }
    }

    /** 서울 자전거 사고다발지역 공공데이터. 팀 서버 준비 전에는 동봉된 CSV 가공본 사용. */
    private void loadRiskData() {
        hazardWorker.execute(() -> {
            List<RiskPoint> loaded = new ArrayList<>();
            String source = "오프라인 공공데이터";
            try {
                loaded = RiskDataRepository.loadBundled(getApplicationContext());
                String api = BuildConfig.TEAM_HAZARD_API_URL.trim();
                // 별도 사고 API 주소가 없으면 팀 서버 기본 주소의 /api/hazards 사용
                if (api.isEmpty() && com.example.bicyclesafety.data.ApiClient.isConfigured()) {
                    api = com.example.bicyclesafety.data.ApiClient.baseUrl() + "/api/hazards";
                }
                if (!api.isEmpty()) {
                    try {
                        List<RiskPoint> response = RiskDataRepository.loadFromTeamServer(api);
                        if (response.isEmpty()) throw new IllegalStateException("사고 API 결과가 비어 있습니다.");
                        loaded = response;
                        source = "팀 서버 API";
                    } catch (Exception error) {
                        Log.w(TAG, "팀 사고 API 조회 실패, 오프라인 자료 사용", error);
                        source = "오프라인 공공데이터(서버 연결 실패)";
                    }
                }
            } catch (Exception error) {
                Log.e(TAG, "사고 자료 로딩 실패", error);
                source = "데이터 로딩 실패";
            }
            final List<RiskPoint> result = loaded;
            final String dataSource = source;
            runOnUiThread(() -> {
                if (isDestroyed()) return;
                hazardPoints.clear();
                hazardPoints.addAll(result);
                hazardSource = dataSource;
                Log.i(TAG, "사고 자료: " + hazardSource + " / " + hazardPoints.size() + "건");
                Log.i(STARTUP_TAG, "사고 자료 로딩 완료: " + hazardPoints.size() + "건");
                // 경로가 먼저 조회되고 사고 자료가 나중에 로딩된 경우에도 결과를 갱신합니다.
                if (pendingRoute != null) {
                    routeHazardsVisible.clear();
                    routeHazardsVisible.addAll(hazardsAlongRoute(pendingRoute.points));
                    if (!comparedUi.isEmpty()) updateComparisonUi();
                }
                if (activeMap != null) {
                    refreshHazardMarkers(pendingRoute == null ? null : routeHazardsVisible);
                    markerCenterLocation = lastLocation == null ? null : new Location(lastLocation);
                }
            });
        });
    }

    /** 지도 렌더링 부하를 낮추기 위해 현재 지도나 조회 경로 주변 최대 80개만 표시. */
    private void refreshHazardMarkers(List<RiskPoint> nearRoute) {
        if (activeMap == null) return;
        try {
            activeMap.getLabelManager().getLayer().removeAll();
            activeMap.getShapeManager().getLayer().removeAll();
            currentLocationLabel = null;
            currentMarkerNavigation = false;
            List<RiskPoint> targets = new ArrayList<>();
            if (nearRoute != null) {
                targets.addAll(nearRoute);
            } else {
                double centerLat = lastLocation == null ? 37.5665 : lastLocation.getLatitude();
                double centerLng = lastLocation == null ? 126.9780 : lastLocation.getLongitude();
                for (RiskPoint point : hazardPoints) {
                    if (distanceMeters(centerLat, centerLng, point.latitude, point.longitude) < 3500) targets.add(point);
                }
                targets.sort(Comparator.comparingDouble(p ->
                        distanceMeters(centerLat, centerLng, p.latitude, p.longitude)));
            }
            int shown = 0;
            for (RiskPoint point : targets) {
                if (shown >= 80) break;
                if (shown < MAX_WARNING_ZONES) addWarningZone(activeMap, point);
                addRiskMarker(activeMap, point);
                shown++;
            }
            if (lastLocation != null) drawCurrentLocation(lastLocation);
        } catch (Exception error) {
            Log.e(TAG, "사고 마커 표시 오류", error);
        }
    }

    private static double distanceMeters(double lat1, double lng1, double lat2, double lng2) {
        // 근거리 계산용 구면거리(Haversine), 미터 단위
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.pow(Math.sin(dLat/2),2) + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.pow(Math.sin(dLng/2),2);
        return 6371000.0 * 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    /** 지도에서 선분까지의 최소 거리; 단순 위험 정보 표시용이며 회피 경로 계산이 아님. */
    private static double distanceToRoute(RiskPoint p, List<KakaoRouteRepository.Point> path) {
        double best = Double.POSITIVE_INFINITY;
        double scaleX = 111320.0 * Math.cos(Math.toRadians(p.latitude));
        for (int i = 1; i < path.size(); i++) {
            KakaoRouteRepository.Point first = path.get(i-1);
            KakaoRouteRepository.Point second = path.get(i);
            double ax = (first.longitude - p.longitude) * scaleX;
            double ay = (first.latitude - p.latitude) * 111320;
            double bx = (second.longitude - p.longitude) * scaleX;
            double by = (second.latitude - p.latitude) * 111320;
            double vx = bx - ax, vy = by - ay;
            double t = (vx*vx+vy*vy) < 0.001 ? 0 : Math.max(0, Math.min(1, -(ax*vx+ay*vy)/(vx*vx+vy*vy)));
            best = Math.min(best, Math.hypot(ax + t*vx, ay + t*vy));
        }
        return best;
    }

    private List<RiskPoint> hazardsAlongRoute(List<KakaoRouteRepository.Point> path) {
        List<RiskPoint> result = new ArrayList<>();
        if (path.size() < 2) return result;
        for (RiskPoint point : hazardPoints) {
            if (distanceToRoute(point, path) <= ROUTE_HAZARD_METERS) result.add(point);
        }
        return result;
    }

    /**
     * 사고다발지역 접근 안내가 시작되는 범위(WARNING_DISTANCE_METERS, 150m)를 지도에 표시합니다.
     * 카카오맵 도형은 그라데이션을 지원하지 않아서, 반경이 다른 반투명 원 ZONE_RINGS개를 겹쳐
     * 가운데로 갈수록 진해지게 하고, 바깥 경계에는 얇은 테두리를 그립니다.
     */
    private void addWarningZone(KakaoMap kakaoMap, RiskPoint point) {
        try {
            LatLng center = LatLng.from(point.latitude, point.longitude);
            for (int i = ZONE_RINGS; i >= 1; i--) {
                float radius = (float) (WARNING_DISTANCE_METERS * i / ZONE_RINGS);
                kakaoMap.getShapeManager().getLayer().addPolygon(
                        PolygonOptions.from(DotPoints.fromCircle(center, radius))
                                .setStylesSet(PolygonStylesSet.from(PolygonStyles.from(
                                        Color.argb(ZONE_RING_ALPHA, 217, 58, 58)))));
            }
            float edge = (float) WARNING_DISTANCE_METERS;
            kakaoMap.getShapeManager().getLayer().addPolygon(
                    PolygonOptions.from(DotPoints.fromCircle(center, edge).setHoleCircle((int) WARNING_DISTANCE_METERS - 4))
                            .setStylesSet(PolygonStylesSet.from(PolygonStyles.from(
                                    Color.argb(ZONE_EDGE_ALPHA, 217, 58, 58)))));
        } catch (Exception error) {
            Log.w(TAG, "접근 경고 범위 표시 실패: " + point.id, error);
        }
    }

    private void addRiskMarker(KakaoMap kakaoMap, RiskPoint point) {
        LabelOptions marker = LabelOptions.from(
                        point.id, LatLng.from(point.latitude, point.longitude))
                .setStyles(LabelStyle.from().setTextStyles(36, Color.RED))
                .setTexts(new LabelTextBuilder().setTexts("●"))
                .setClickable(true)
                .setTag(point);
        kakaoMap.getLabelManager().getLayer().addLabel(marker);
    }

    /** Called whenever a user edits either address or switches route mode. */
    public void onRouteFormChanged() {
        clearPlaceFocus();
        routeRequestRevision++; // Invalidate callbacks from an outdated query.
        routeRequestInProgress = false;
        pendingRoute = null;
        comparedRoutes.clear();
        comparedUi.clear();
        routeHazardsVisible.clear();
        startGuidanceAfterAnalysis = false;
        if (guidanceActive) stopGuidance(null);
        if (routeLayer != null) routeLayer.removeAll();
        refreshHazardMarkers(null);
        BikeUiBridge.routeCleared();
    }

    /** 장소·주소 자동완성: 마지막 입력 결과만 반영하고 검색 요청은 UI 스레드 밖에서 실행. */
    public void onSearchPlaces(int field, String text, boolean addressOnly) {
        final String query = text == null ? "" : text.trim();
        final int revision = ++placeSearchRevision;
        if (query.length() < 2) {
            BikeUiBridge.placesUpdated(field, query, Collections.emptyList(), "");
            return;
        }
        placeWorker.execute(() -> {
            try {
                // 장소 이름 + 주소를 한 번에 검색 (addressOnly 값은 더 이상 사용하지 않음)
                List<KakaoRouteRepository.PlaceOption> places = KakaoRouteRepository.searchPlacesCombined(
                        BuildConfig.KAKAO_REST_API_KEY, query);
                runOnUiThread(() -> {
                    if (!isDestroyed() && placeSearchRevision == revision)
                        BikeUiBridge.placesUpdated(field, query, places,
                                places.isEmpty() ? "검색 결과가 없습니다. 다른 이름이나 주소로 검색해 보세요." : "");
                });
            } catch (Exception error) {
                Log.w(TAG, "장소 자동완성 오류", error);
                runOnUiThread(() -> {
                    if (!isDestroyed() && placeSearchRevision == revision)
                        BikeUiBridge.placesUpdated(field, query, Collections.emptyList(), "검색 실패 · 네트워크/REST 키 확인");
                });
            }
        });
    }

    /** 출발지로 갤럭시의 최근 정확한 GPS를 넣고, 없으면 새 좌표가 올 때까지 기다림. */
    public void onUseCurrentLocationAsOrigin() {
        if (!hasLocationPermission()) {
            pendingOriginLocation = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
            return;
        }
        pendingOriginLocation = true;
        trackingLocation = true;
        startLocationUpdates();
        Location best = isFreshLocation(lastLocation) ? lastLocation
                : isOriginFix(lastOriginCandidate) ? lastOriginCandidate : null;
        if (best != null) applyGpsOrigin(best);
        else Toast.makeText(this,"현재 위치를 확인하는 중입니다.",Toast.LENGTH_SHORT).show();
    }
    /** 경로 검색 출발지용: 오차 100m·2분 이내면 사용 (카카오 경로 API가 가까운 도로로 맞춤). */
    private static boolean isOriginFix(Location location) {
        return location != null && NavigationGpsGuard.isUsableOriginFix(
                location.hasAccuracy(), location.getAccuracy(),
                location.getElapsedRealtimeNanos(), SystemClock.elapsedRealtimeNanos());
    }
    private static boolean isFreshLocation(Location location) {
        return location != null && NavigationGpsGuard.isUsableFix(
                location.hasAccuracy(), location.getAccuracy(),
                location.getElapsedRealtimeNanos(), SystemClock.elapsedRealtimeNanos(),
                NavigationGpsGuard.MAX_MAP_ACCURACY_METERS);
    }
    private void applyGpsOrigin(Location location) {
        if (location == null) return;
        pendingOriginLocation = false;
        BikeUiBridge.originSelected(location.getLatitude(), location.getLongitude());
    }

    /** 카카오 자전거 경로 2개 + 실제 우회 후보를 사고 데이터로 비교해서 선택합니다. */
    public void onAnalyzeRoute(String origin, String destination, int initialMode,
            KakaoRouteRepository.PlaceOption selectedOrigin,
            KakaoRouteRepository.PlaceOption selectedDestination) {
        if (origin.trim().isEmpty() || destination.trim().isEmpty()) {
            BikeUiBridge.routeFailed("출발지와 도착지를 모두 입력해 주세요.");
            return;
        }
        if (routeRequestInProgress) return;
        if (BuildConfig.KAKAO_REST_API_KEY.isEmpty()) {
            BikeUiBridge.routeFailed("REST API 키가 없습니다. local.properties를 확인하세요.");
            return;
        }
        final int revision = ++routeRequestRevision;
        final boolean fromGps = selectedOrigin != null && "GPS".equals(selectedOrigin.address);
        routeRequestInProgress = true;
        pendingRoute = null;
        comparedRoutes.clear();
        comparedUi.clear();
        routeHazardsVisible.clear();
        if (routeLayer != null) routeLayer.removeAll();
        refreshHazardMarkers(null);
        BikeUiBridge.routeStarted();
        final List<RiskPoint> accidents = new ArrayList<>(hazardPoints);
        routeWorker.execute(() -> {
            try {
                KakaoRouteRepository.PlaceOption from = KakaoRouteRepository.resolvePlace(
                        BuildConfig.KAKAO_REST_API_KEY, origin, selectedOrigin);
                KakaoRouteRepository.PlaceOption to = KakaoRouteRepository.resolvePlace(
                        BuildConfig.KAKAO_REST_API_KEY, destination, selectedDestination);
                if (Math.hypot(from.latitude-to.latitude,from.longitude-to.longitude)<0.00001)
                    throw new IllegalArgumentException("출발지와 도착지가 동일합니다.");
                KakaoRouteRepository.Result bike=null, shortest=null;
                String bikeErr="",shortErr="";
                try {bike=KakaoRouteRepository.routeBetween(BuildConfig.KAKAO_REST_API_KEY,from,to,true);}
                catch(Exception e) {bikeErr=e.getMessage();}
                try {shortest=KakaoRouteRepository.routeBetween(BuildConfig.KAKAO_REST_API_KEY,from,to,false);}
                catch(Exception e) {shortErr=e.getMessage();}
                if (bike==null && shortest==null)
                    throw new IllegalStateException("자전거 경로 조회 실패: " + bikeErr + " / " + shortErr);
                SafetyRoutePlanner.Selection safest=SafetyRoutePlanner.choose(
                        BuildConfig.KAKAO_REST_API_KEY,from,to,bike,shortest,accidents);
                final Map<Integer,KakaoRouteRepository.Result> results=new HashMap<>();
                if (safest != null) results.put(0,safest.route);
                if (shortest != null) results.put(1,shortest);
                if (bike != null) results.put(2,bike);
                final List<RouteChoiceUi> choices=new ArrayList<>();
                int baseline = Math.min(bike==null?Integer.MAX_VALUE:SafetyRoutePlanner.riskCount(accidents,bike.points),
                        shortest==null?Integer.MAX_VALUE:SafetyRoutePlanner.riskCount(accidents,shortest.points));
                for(int mode=0;mode<3;mode++) {
                    KakaoRouteRepository.Result r=results.get(mode);
                    String name= mode==0 ? "안전 우선" : mode==1 ? "최단 경로" : "자전거도로 우선";
                    int risk=r==null?-1:SafetyRoutePlanner.riskCount(accidents,r.points);
                    // 안전 우선: 가중 위험 점수(사고 건수·사상자·경로와의 거리)로 비교한 결과를 표시
                    String note = mode==0 ? safetyNote(safest, baseline, risk)
                        : "사고 이력 150m 이내 단순 집계";
                    choices.add(new RouteChoiceUi(mode,name,r==null?0:r.distanceMeters,
                            r==null?0:r.durationSeconds,risk,r!=null,note));
                }
                int selected = results.containsKey(initialMode)?initialMode:
                        results.containsKey(2)?2:1;
                runOnUiThread(() -> {
                    if (isDestroyed() || revision != routeRequestRevision) return;
                    routeRequestInProgress=false;
                    lastRouteFromGps = fromGps;
                    comparedRoutes.clear(); comparedRoutes.putAll(results);
                    comparedUi.clear(); comparedUi.addAll(choices);
                    selectComparedRoute(selected);
                    saveRecentRoute(from, to, fromGps);
                    if (startGuidanceAfterAnalysis) {
                        startGuidanceAfterAnalysis = false;
                        if (pendingRoute != null) onStartGuidanceRequested();
                    }
                });
            } catch(Exception e) {
                Log.w(TAG,"세 경로 비교 실패",e);
                runOnUiThread(() -> {
                    if (isDestroyed() || revision != routeRequestRevision) return;
                    routeRequestInProgress=false;
                    startGuidanceAfterAnalysis = false;
                    BikeUiBridge.routeFailed(e.getMessage()==null?"경로 조회 실패":e.getMessage());
                });
            }
        });
    }

    public void selectComparedRoute(int mode) {
        KakaoRouteRepository.Result candidate=comparedRoutes.get(mode);
        if (candidate == null || guidanceActive) return;
        currentRouteMode=mode;
        pendingRoute=candidate;
        lastRouteBicycleFirst=candidate.bicycleFirst;
        routeHazardsVisible.clear();
        routeHazardsVisible.addAll(hazardsAlongRoute(candidate.points));
        refreshHazardMarkers(routeHazardsVisible);
        if (!showRouteOnMap(candidate)) {
            BikeUiBridge.routeFailed("경로선 렌더링 실패 · Logcat 확인"); return;
        }
        updateComparisonUi();
    }
    private void updateComparisonUi() {
        if (pendingRoute == null) return;
        BikeUiBridge.routesCompared(comparedUi,currentRouteMode,pendingRoute.matchedOrigin,
                pendingRoute.matchedDestination,hazardSource,lastRouteFromGps);
    }

    /** RouteLine 레이어만 갱신: 사고 마커는 Label 레이어에 따로 유지됩니다. */
    private boolean showRouteOnMap(KakaoRouteRepository.Result result) {
        return showRouteOnMap(result, true);
    }

    /** @param fitCamera false면 안내 중 재탐색처럼 카메라를 현재 위치에 둔 채 선만 바꿉니다. */
    private boolean showRouteOnMap(KakaoRouteRepository.Result result, boolean fitCamera) {
        // Map loading is asynchronous: keep the result until onMapReady() calls us.
        if (activeMap == null || routeLayer == null) return true;
        List<LatLng> points = new ArrayList<>();
        double minLat = 90.0;
        double maxLat = -90.0;
        double minLng = 180.0;
        double maxLng = -180.0;
        for (KakaoRouteRepository.Point p : result.points) {
            points.add(LatLng.from(p.latitude, p.longitude));
            minLat = Math.min(minLat, p.latitude);
            maxLat = Math.max(maxLat, p.latitude);
            minLng = Math.min(minLng, p.longitude);
            maxLng = Math.max(maxLng, p.longitude);
        }
        if (points.size() < 2) return false;
        try {
            routeLayer.removeAll();
            RouteLineStylesSet styles = RouteLineStylesSet.from(
                    RouteLineStyles.from(RouteLineStyle.from(
                            11f, Color.rgb(44, 114, 235), 2f, Color.WHITE)));
            RouteLineSegment segment = RouteLineSegment.from(points)
                    .setStyles(styles.getStyles(0));
            routeLayer.addRouteLine(RouteLineOptions.from(segment).setStylesSet(styles));
            // 전체 경로가 아래 미리보기 카드에 가리지 않도록 카드 위쪽 영역에 맞춥니다.
            if (fitCamera) fitRouteCamera(minLat, maxLat, minLng, maxLng);
            return true;
        } catch (Exception error) {
            Log.e(TAG, "경로선 표시 오류", error);
            return false;
        }
    }

    /** 위치 기능은 화면 사용 중에만 작동합니다. 위치 권한이 없으면 먼저 권한 요청. */
    public void onCurrentLocationRequested() {
        if (!hasLocationPermission()) {
            centerOnNextLocation = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
            return;
        }
        centerOnNextLocation = true;
        approximateCenteredOnce = false;
        trackingLocation = true;
        startLocationUpdates();
        if (isFreshLocation(lastLocation)) {
            // 최근에 수신한 실제 좌표일 때만 즉시 이동합니다.
            drawCurrentLocation(lastLocation);
            moveCameraToLocation(lastLocation);
            centerOnNextLocation = false;
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != LOCATION_REQUEST) return;
        if (hasLocationPermission()) {
            if (pendingOriginLocation) {
                onUseCurrentLocationAsOrigin();
            } else if (pendingGuidancePermission) {
                pendingGuidancePermission = false;
                onStartGuidanceRequested();
            } else {
                onCurrentLocationRequested();
            }
        } else {
            pendingGuidancePermission = false;
            pendingOriginLocation = false;
            guidanceActive = false;
            centerOnNextLocation = false;
            Toast.makeText(this, "위치 권한이 없어 현재 위치와 접근 알림을 사용할 수 없습니다.", Toast.LENGTH_LONG).show();
        }
    }

    /** 휴대폰 자이로/지자기 센서에서 방향을 받습니다. 지도 자체를 과도하게 돌리지 않습니다. */
    private void startDirectionSensor() {
        if (sensorManager == null || directionSensor == null || directionListener == null || directionSensorRegistered) return;
        directionSensorRegistered = sensorManager.registerListener(directionListener, directionSensor, SensorManager.SENSOR_DELAY_GAME);
    }
    private void stopDirectionSensor() {
        if (sensorManager != null && directionListener != null && directionSensorRegistered)
            sensorManager.unregisterListener(directionListener);
        directionSensorRegistered = false;
    }

    /** 내비게이션용 정밀 GPS는 기존 검증을 유지하고, 화면에는 최근 위치를 먼저 띄웁니다. */
    @SuppressWarnings("MissingPermission")
    private void requestQuickLocationFix(boolean fine) {
        if (locationManager == null || !trackingLocation) return;
        long now = SystemClock.elapsedRealtime();
        if (lastQuickFixRequestMs > 0 && now - lastQuickFixRequestMs < 10000L) return;
        lastQuickFixRequestMs = now;
        String[] providers = fine ? new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}
                                  : new String[]{LocationManager.NETWORK_PROVIDER};
        for (String provider : providers) {
            try {
                if (!locationManager.isProviderEnabled(provider)) continue;
                Location cached = locationManager.getLastKnownLocation(provider);
                if (cached != null) onLocationChanged(cached);
                // Android 11 이상: 이전 위치만 기다리지 않고 단발성 새 좌표 요청.
                if (Build.VERSION.SDK_INT >= 30) {
                    locationManager.getCurrentLocation(provider, new CancellationSignal(), getMainExecutor(),
                            location -> { if (location != null && trackingLocation) onLocationChanged(location); });
                }
            } catch (SecurityException | IllegalArgumentException e) { Log.w(TAG, "빠른 GPS 요청 실패: " + provider, e); }
        }
    }

    @SuppressWarnings("MissingPermission")
    private void startLocationUpdates() {
        if (simulationActive) return; // 시뮬레이션 중에는 실제 GPS를 쓰지 않음
        if (!hasLocationPermission()) return;
        if (fusedClient != null && fusedCallback != null) {
            startFusedUpdates(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED);
            return;
        }
        if (locationManager == null || locationListener == null) return;
        try {
            locationManager.removeUpdates(locationListener);
            boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
            boolean requested=false;
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        guidanceActive?1000L:2000L, guidanceActive?0f:3f,locationListener,Looper.getMainLooper());
                requested=true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        guidanceActive?1500L:3000L,5f,locationListener,Looper.getMainLooper());
                requested=true;
            }
            if (!requested) Toast.makeText(this,"휴대폰 위치 서비스를 켜주세요.",Toast.LENGTH_LONG).show();
            else if (lastLocation == null || !isFreshLocation(lastLocation)) requestQuickLocationFix(fine);
        } catch(Exception e) {Log.e(TAG,"실제 GPS 시작 오류",e);}
    }

    /** Play 서비스가 있으면 Google Fused 위치를 사용합니다. 없으면 기존 LocationManager를 그대로 씁니다. */
    private void setUpFusedLocation() {
        try {
            if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)
                    != ConnectionResult.SUCCESS) {
                Log.i(STARTUP_TAG, "위치: Play 서비스 없음 → 기본 GPS(LocationManager) 사용");
                return;
            }
            fusedClient = LocationServices.getFusedLocationProviderClient(this);
            fusedCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult result) {
                    Location location = result.getLastLocation();
                    if (location != null) onLocationChanged(location);
                }
            };
            Log.i(STARTUP_TAG, "위치: Google Fused 위치 사용");
        } catch (Exception error) {
            fusedClient = null;
            fusedCallback = null;
            Log.w(TAG, "Fused 위치 준비 실패, 기본 GPS 사용", error);
        }
    }

    @SuppressWarnings("MissingPermission")
    private void startFusedUpdates(boolean fine) {
        try {
            if (locationManager != null && Build.VERSION.SDK_INT >= 28 && !locationManager.isLocationEnabled()) {
                Toast.makeText(this, "휴대폰 위치 서비스를 켜주세요.", Toast.LENGTH_LONG).show();
                return;
            }
            fusedClient.removeLocationUpdates(fusedCallback);
            int priority = fine ? Priority.PRIORITY_HIGH_ACCURACY : Priority.PRIORITY_BALANCED_POWER_ACCURACY;
            LocationRequest request = new LocationRequest.Builder(priority, guidanceActive ? 1000L : 2000L)
                    .setMinUpdateIntervalMillis(guidanceActive ? 500L : 1000L)
                    .setMinUpdateDistanceMeters(guidanceActive ? 0f : 3f)
                    .setWaitForAccurateLocation(false)
                    .build();
            fusedClient.requestLocationUpdates(request, fusedCallback, Looper.getMainLooper());
            if (lastLocation == null || !isFreshLocation(lastLocation)) requestFusedQuickFix(priority);
        } catch (Exception error) {
            Log.e(TAG, "Fused 위치 시작 오류, 기본 GPS로 전환", error);
            fusedClient = null;
            fusedCallback = null;
            startLocationUpdates();
        }
    }

    /** 휴대폰이 이미 알고 있는 최근 위치 + 1회성 새 위치를 바로 요청해 첫 표시를 앞당깁니다. */
    @SuppressWarnings("MissingPermission")
    private void requestFusedQuickFix(int priority) {
        if (fusedClient == null || !trackingLocation) return;
        long now = SystemClock.elapsedRealtime();
        if (lastQuickFixRequestMs > 0 && now - lastQuickFixRequestMs < 10000L) return;
        lastQuickFixRequestMs = now;
        fusedClient.getLastLocation().addOnSuccessListener(this, this::deliverQuickFix);
        if (quickFixCancel != null) quickFixCancel.cancel();
        quickFixCancel = new CancellationTokenSource();
        fusedClient.getCurrentLocation(priority, quickFixCancel.getToken())
                .addOnSuccessListener(this, this::deliverQuickFix);
    }

    /** 이미 받은 좌표보다 오래된 1회성 좌표는 버려서 'GPS 불안정'으로 잘못 처리되지 않게 합니다. */
    private void deliverQuickFix(Location location) {
        if (location == null || !trackingLocation) return;
        if (lastLocation != null && location.getElapsedRealtimeNanos() <= lastLocation.getElapsedRealtimeNanos()) return;
        onLocationChanged(location);
    }

    private void stopLocationUpdates() {
        if (fusedClient != null && fusedCallback != null) fusedClient.removeLocationUpdates(fusedCallback);
        if (quickFixCancel != null) { quickFixCancel.cancel(); quickFixCancel = null; }
        if (locationManager != null && locationListener != null) locationManager.removeUpdates(locationListener);
    }

    private void onLocationChanged(Location location) {
        // 시뮬레이션 중에는 남아 있던 실제 GPS 콜백을 무시 (가짜 위치와 섞이지 않게)
        if (simulationActive && location != null && !SIMULATION_PROVIDER.equals(location.getProvider())) return;
        if (location == null || !trackingLocation ||
                !Double.isFinite(location.getLatitude()) || !Double.isFinite(location.getLongitude())) return;
        // 출발지는 느슨한 기준으로 먼저 채워 'GPS 확인 중' 대기를 줄입니다. (주행 판정은 아래 엄격한 기준 유지)
        if (isOriginFix(location)) {
            lastOriginCandidate = new Location(location);
            if (pendingOriginLocation) applyGpsOrigin(location);
        }
        // 위치서비스가 순간적으로 수백 m 이상 튀거나 정확도/수신시각을 보장하지 않으면
        // 지도 카메라, 경로 진행률, 도착 판정 어느 쪽에도 반영하지 않습니다.
        float maxAccuracy = guidanceActive ? NavigationGpsGuard.MAX_NAV_ACCURACY_METERS
                : NavigationGpsGuard.MAX_MAP_ACCURACY_METERS;
        boolean usable = NavigationGpsGuard.isUsableFix(
                location.hasAccuracy(), location.getAccuracy(),
                location.getElapsedRealtimeNanos(), SystemClock.elapsedRealtimeNanos(), maxAccuracy);
        if (usable && lastLocation != null) {
            usable = NavigationGpsGuard.isPlausibleMovement(
                    lastLocation.distanceTo(location),
                    lastLocation.getElapsedRealtimeNanos(), location.getElapsedRealtimeNanos());
        }
        if (!usable) {
            // 이미 정확한 GPS 위치가 있을 때 보조 네트워크 좌표로 주행 판정을 초기화하지 않습니다.
            if (guidanceActive && LocationManager.NETWORK_PROVIDER.equals(location.getProvider())
                    && isFreshLocation(lastLocation)) return;
            // 지도 초기화용 대략 위치만 조기에 표시; 주행 계산·위험 경고·도착 판정에는 미사용.
            if (!guidanceActive && lastLocation == null && activeMap != null
                    && location.hasAccuracy() && location.getAccuracy() <= 100f
                    && location.getElapsedRealtimeNanos() > 0
                    && SystemClock.elapsedRealtimeNanos() - location.getElapsedRealtimeNanos() < 30000000000L) {
                drawCurrentLocation(location);
                if (centerOnNextLocation && !approximateCenteredOnce) {
                    moveCameraToLocation(location);
                    approximateCenteredOnce = true;
                }
            }
            onGpsSignalUnstable();
            return;
        }
        lastLocation = new Location(location);
        gpsUnstableMessageShown = false;
        if (activeMap != null) {
            // 현재 위치가 지도 마커 범위에서 멀어지면 그 주변 사고 이력을 다시 표시합니다.
            if (markerCenterLocation == null || markerCenterLocation.distanceTo(location) > 900f) {
                refreshHazardMarkers(pendingRoute == null ? null : routeHazardsVisible);
                markerCenterLocation = new Location(location);
            } else {
                drawCurrentLocation(location);
            }
            if (centerOnNextLocation) {
                moveCameraToLocation(location);
                centerOnNextLocation = false;
                approximateCenteredOnce = false;
            }
        }
        if (guidanceActive) {
            updateNavigation(location);
            // 안내 중에는 경로 기준 '사고 다발 구간 N m 앞' 안내가 대신하므로 반경 경고는 끕니다.
            if (riskWarningGate.isActive()) riskWarningGate.reset();
            BikeUiBridge.showProximityWarning(null);
            return;
        }
        // 정확도가 확인되고 오차 80m 이하인 좌표에만 시연용 근접 경고를 적용합니다.
        if (!location.hasAccuracy() || location.getAccuracy() > 80f) {
            if (!riskWarningGate.isActive()) {
                BikeUiBridge.showProximityWarning("GPS 정확도를 확인할 수 없거나 오차가 커서 위험 접근 판별을 보류했습니다.");
            }
            return;
        }
        RiskPoint nearest = null;
        double nearestDistance = WARNING_DISTANCE_METERS;
        boolean insideExitBuffer = false;
        for (RiskPoint point : hazardPoints) {
            double distance = distanceMeters(location.getLatitude(), location.getLongitude(),
                    point.latitude, point.longitude);
            if (distance <= WARNING_DISTANCE_METERS + RiskWarningGate.EXIT_BUFFER_METERS) {
                insideExitBuffer = true;
            }
            if (distance < nearestDistance) {
                nearest = point;
                nearestDistance = distance;
            }
        }
        // 겹친 여러 위험 원을 통과하는 동안 첫 진입 지점만 한 번 알립니다.
        // 170m 밖으로 완전히 나간 다음 새 구역에 진입해야 화면/TTS가 다시 나타납니다.
        RiskWarningGate.Transition transition =
                riskWarningGate.update(nearest != null, insideExitBuffer);
        if (transition == RiskWarningGate.Transition.ENTER) {
            BikeUiBridge.showProximityWarning("과거 사고다발지역 접근: " + nearest.name + " (약 "
                    + Math.round(nearestDistance) + "m) · 실시간 위험 판단 아님");
            speak("사고 다발 구간입니다. 주의하세요.");
        } else if (transition == RiskWarningGate.Transition.EXIT) {
            BikeUiBridge.showProximityWarning(null);
        }
    }

    /** GPS가 불안정해도 주행 화면을 종료하지 않고 다음 정상 좌표를 기다립니다. */
    private void onGpsSignalUnstable() {
        if (!guidanceActive) return;
        navigationGpsGuard.resetArrival();
        if (!gpsUnstableMessageShown) {
            gpsUnstableMessageShown = true;
            BikeUiBridge.navMessage("GPS 정확도 낮음 · 경로 안내 유지 중");
        }
    }

    private void drawCurrentLocation(Location location) {
        if (activeMap == null) return;
        try {
            LatLng coordinate = LatLng.from(location.getLatitude(), location.getLongitude());
            if (currentLocationLabel == null) {
                LabelOptions marker = LabelOptions.from("CURRENT_GPS", coordinate)
                        .setStyles(guidanceActive ? navArrowStyles() : locationDotStyles())
                        .setTexts(new LabelTextBuilder().setTexts(guidanceActive ? "" : "●"))
                        .setTransform(TransformMethod.AbsoluteRotation);
                currentLocationLabel = activeMap.getLabelManager().getLayer().addLabel(marker);
                currentMarkerNavigation = guidanceActive;
            } else {
                currentLocationLabel.moveTo(coordinate);
                if (currentMarkerNavigation != guidanceActive) {
                    currentMarkerNavigation = guidanceActive;
                    if (guidanceActive) {
                        currentLocationLabel.setStyles(navArrowStyles());
                        currentLocationLabel.setTexts(new LabelTextBuilder().setTexts(""));
                    } else {
                        currentLocationLabel.setStyles(locationDotStyles());
                        currentLocationLabel.setTexts(new LabelTextBuilder().setTexts("●"));
                    }
                    currentLocationLabel.invalidate();
                }
            }
            if (guidanceActive) {
                float direction = deviceHeadingDegrees;
                // 센서가 없는 기기에서는 기존 GPS 이동 방향으로 대체합니다.
                if (Float.isNaN(direction) && location.hasBearing()) direction = location.getBearing();
                if (!Float.isNaN(direction)) currentLocationLabel.rotateTo((float)Math.toRadians(direction));
            }
        } catch(Exception error) { Log.w(TAG, "현재 위치 화살표 표시 실패", error); }
    }

    /** 안내 중 화살표: 줌 레벨이 높을수록(확대) 큰 이미지. 회전 중심이 맞도록 가운데 기준. */
    private static LabelStyle[] navArrowStyles() {
        LabelStyle[] styles = new LabelStyle[MARKER_ZOOM_LEVELS.length];
        for (int i = 0; i < styles.length; i++) {
            styles[i] = LabelStyle.from(NAV_ARROW_ICONS[i])
                    .setAnchorPoint(0.5f, 0.5f)
                    .setZoomLevel(MARKER_ZOOM_LEVELS[i]);
        }
        return styles;
    }

    /** 평소 내 위치 점: 줌 레벨에 따라 글자 크기를 바꿔 지도와 함께 커지고 작아짐. */
    private static LabelStyle[] locationDotStyles() {
        LabelStyle[] styles = new LabelStyle[MARKER_ZOOM_LEVELS.length];
        for (int i = 0; i < styles.length; i++) {
            styles[i] = LabelStyle.from().setTextStyles(LOCATION_DOT_SIZES[i], Color.BLUE)
                    .setZoomLevel(MARKER_ZOOM_LEVELS[i]);
        }
        return styles;
    }

    /** 사용자가 현재 위치 버튼을 누른 경우에만 지도 중심 이동; 안내 중 지도 자동 추적 아님. */
    private void moveCameraToLocation(Location location) {
        moveCameraToLocation(location, 15);
    }

    private void moveCameraToLocation(Location location, int zoomLevel) {
        moveCameraToPoint(location.getLatitude(), location.getLongitude(), zoomLevel);
    }

    /** 제보 위치 표시 전용 마커층. 사고 마커를 다시 그릴 때 기본 층을 비워도 이 층은 남음 */
    private static final String PLACE_FOCUS_LAYER = "place_focus_layer";

    /**
     * 제보게시판 '지도에서 보기': 우리 앱 지도를 그 위치로 옮기고 이름이 붙은 마커를 표시 (2026-11-26).
     * 지도가 아직 준비되지 않았거나 실패하면 예전처럼 카카오맵 링크로 엽니다.
     */
    public void showPlaceOnMap(String name, double latitude, double longitude) {
        String label = (name == null || name.trim().isEmpty()) ? "제보 위치" : name.trim();
        if (label.length() > 18) label = label.substring(0, 18) + "…";
        boolean shown = false;
        if (activeMap != null && !guidanceActive) {
            try {
                LabelLayer layer = activeMap.getLabelManager().addLayer(
                        LabelLayerOptions.from(PLACE_FOCUS_LAYER).setZOrder(10001));
                if (layer != null) {
                    layer.removeAll();
                    LatLng spot = LatLng.from(latitude, longitude);
                    // 정확한 위치: 파란 점 (사고 지점 빨간 점과 구분)
                    layer.addLabel(LabelOptions.from("place_focus_dot", spot)
                            .setStyles(LabelStyle.from().setTextStyles(40, Color.rgb(37, 99, 235), 4, Color.WHITE))
                            .setTexts(new LabelTextBuilder().setTexts("●")));
                    // 이름: 점 위쪽
                    layer.addLabel(LabelOptions.from("place_focus_name", spot)
                            .setStyles(LabelStyle.from()
                                    .setTextStyles(30, Color.rgb(37, 99, 235), 4, Color.WHITE)
                                    .setAnchorPoint(0.5f, 1.6f))
                            .setTexts(new LabelTextBuilder().setTexts(label)));
                    centerOnNextLocation = false; // 첫 GPS 위치로 화면이 되돌아가지 않게
                    moveCameraToPoint(latitude, longitude, 16);
                    shown = true;
                }
            } catch (Exception error) {
                Log.w(TAG, "제보 위치 지도 표시 실패", error);
            }
        }
        if (!shown) {
            try {
                Uri uri = Uri.parse("https://map.kakao.com/link/map/" + Uri.encode(label) + "," + latitude + "," + longitude);
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception error) {
                Toast.makeText(this, "지도를 열 수 없습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** 경로를 새로 찾거나 안내를 시작하면 제보 위치 마커를 지움 */
    private void clearPlaceFocus() {
        if (activeMap == null) return;
        try {
            LabelLayer layer = activeMap.getLabelManager().getLayer(PLACE_FOCUS_LAYER);
            if (layer != null) layer.removeAll();
        } catch (Exception error) {
            Log.w(TAG, "제보 위치 마커 지우기 실패", error);
        }
    }

    private void moveCameraToPoint(double latitude, double longitude, int zoomLevel) {
        if (activeMap == null) return;
        try {
            activeMap.moveCamera(CameraUpdateFactory.newCenterPosition(
                    LatLng.from(latitude, longitude), zoomLevel));
        } catch (Exception error) {
            Log.w(TAG, "지도 이동 실패", error);
        }
    }

    /**
     * 경로 전체(minLat~maxLat, minLng~maxLng)가 화면 위쪽 여백과 아래 미리보기 카드 사이에 보이도록
     * 카메라 영역을 계산해서 맞춥니다. 카카오맵 줌은 정수 단계라 실제로는 조금 더 넓게 보일 수 있습니다.
     */
    private void fitRouteCamera(double minLat, double maxLat, double minLng, double maxLng) {
        if (activeMap == null) return;
        try {
            float density = getResources().getDisplayMetrics().density;
            int w = mapView != null && mapView.getWidth() > 0 ? mapView.getWidth()
                    : getResources().getDisplayMetrics().widthPixels;
            int h = mapView != null && mapView.getHeight() > 0 ? mapView.getHeight()
                    : getResources().getDisplayMetrics().heightPixels;
            double topFrac = Math.min(0.25, (64f * density) / h);
            double bottomPx = previewPanelHeightPx > 0 ? previewPanelHeightPx + 16f * density : 32f * density;
            double bottomFrac = Math.min(0.68, bottomPx / h);
            double visibleFrac = Math.max(0.2, 1.0 - topFrac - bottomFrac);
            double midLat = (minLat + maxLat) / 2.0;
            double midLng = (minLng + maxLng) / 2.0;
            double cos = Math.max(0.2, Math.cos(Math.toRadians(midLat)));
            double spanY = Math.max((maxLat - minLat) * 111320.0, 80.0);
            double spanX = Math.max((maxLng - minLng) * 111320.0 * cos, 80.0);
            double metersPerPx = Math.max(spanX / (w * 0.84), spanY / (h * visibleFrac));
            double viewHeightDeg = metersPerPx * h / 111320.0;
            double viewWidthDeg = metersPerPx * w / (111320.0 * cos);
            // 경로 가운데가 '보이는 영역'의 가운데에 오도록 지도 중심을 아래로 내립니다.
            double routeCenterFromTop = topFrac + visibleFrac / 2.0;
            double centerLat = midLat + (routeCenterFromTop - 0.5) * viewHeightDeg;
            LatLng southWest = LatLng.from(centerLat - viewHeightDeg / 2.0, midLng - viewWidthDeg / 2.0);
            LatLng northEast = LatLng.from(centerLat + viewHeightDeg / 2.0, midLng + viewWidthDeg / 2.0);
            activeMap.moveCamera(CameraUpdateFactory.fitMapPoints(new LatLng[]{southWest, northEast}, 0));
        } catch (Exception error) {
            Log.w(TAG, "전체 경로 화면 맞춤 실패", error);
        }
    }

    private void fitRouteCamera(KakaoRouteRepository.Result result) {
        if (result == null || result.points.size() < 2) return;
        double minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
        for (KakaoRouteRepository.Point p : result.points) {
            minLat = Math.min(minLat, p.latitude); maxLat = Math.max(maxLat, p.latitude);
            minLng = Math.min(minLng, p.longitude); maxLng = Math.max(maxLng, p.longitude);
        }
        fitRouteCamera(minLat, maxLat, minLng, maxLng);
    }

    /** Compose 미리보기 카드가 그려지거나 높이가 바뀌면 호출 → 전체 경로를 카드 위쪽에 다시 맞춤 */
    public void onRoutePreviewLayout(int panelHeightPx) {
        if (panelHeightPx <= 0) return;
        boolean changed = Math.abs(panelHeightPx - previewPanelHeightPx) > 4;
        previewPanelHeightPx = panelHeightPx;
        if (changed && pendingRoute != null && !guidanceActive) fitRouteCamera(pendingRoute);
    }

    /** 출발지·안내 시작용 현재 위치: 정밀 좌표 우선, 없으면 100m·2분 이내 좌표 */
    private Location currentOriginFix() {
        if (isFreshLocation(lastLocation)) return lastLocation;
        if (isOriginFix(lastOriginCandidate)) return lastOriginCandidate;
        return null;
    }

    /**
     * 다른 출발지로 소요 시간만 확인한 경우의 '내 위치에서 안내' 버튼:
     * 같은 목적지·같은 경로 종류로 현재 위치에서 다시 검색하고 끝나면 바로 안내를 시작합니다.
     */
    public void onGuideFromMyLocation() {
        if (pendingRoute == null || routeRequestInProgress) return;
        if (!hasLocationPermission()) {
            onUseCurrentLocationAsOrigin();
            return;
        }
        Location here = currentOriginFix();
        if (here == null) {
            trackingLocation = true;
            startLocationUpdates();
            Toast.makeText(this, "현재 위치를 확인하는 중입니다. 잠시 후 다시 눌러 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        KakaoRouteRepository.PlaceOption start = new KakaoRouteRepository.PlaceOption(
                "현재 위치", "GPS", here.getLatitude(), here.getLongitude());
        KakaoRouteRepository.PlaceOption destination = new KakaoRouteRepository.PlaceOption(
                pendingRoute.destinationName, "", pendingRoute.endLatitude, pendingRoute.endLongitude);
        int mode = currentRouteMode;
        startGuidanceAfterAnalysis = true;
        onAnalyzeRoute("현재 위치", destination.name, mode, start, destination);
    }

    // ── 최근 경로 ──

    private void saveRecentRoute(KakaoRouteRepository.PlaceOption from,
                                 KakaoRouteRepository.PlaceOption to, boolean fromGps) {
        try {
            RecentRouteStore.Entry entry = new RecentRouteStore.Entry(
                    fromGps ? "현재 위치" : from.name, fromGps, from.latitude, from.longitude,
                    to.name, to.latitude, to.longitude, System.currentTimeMillis());
            publishRecentRoutes(RecentRouteStore.add(this, entry));
        } catch (Exception error) {
            Log.w(TAG, "최근 경로 저장 실패", error);
        }
    }

    private void publishRecentRoutes(List<RecentRouteStore.Entry> items) {
        List<RecentRouteUi> ui = new ArrayList<>();
        for (RecentRouteStore.Entry e : items) {
            ui.add(new RecentRouteUi(e.originName, e.destinationName, e.originGps));
        }
        BikeUiBridge.recentRoutesUpdated(ui);
    }

    /** 경로 설정 창의 최근 경로를 누르면 같은 출발·도착으로 다시 3가지 경로를 검색합니다. */
    public void onRecentRouteSelected(int index) {
        List<RecentRouteStore.Entry> items = RecentRouteStore.load(this);
        if (index < 0 || index >= items.size()) return;
        RecentRouteStore.Entry e = items.get(index);
        KakaoRouteRepository.PlaceOption destination = new KakaoRouteRepository.PlaceOption(
                e.destinationName, "", e.destinationLatitude, e.destinationLongitude);
        KakaoRouteRepository.PlaceOption origin;
        if (e.originGps) {
            Location here = currentOriginFix();
            if (here == null) {
                trackingLocation = true;
                startLocationUpdates();
                BikeUiBridge.routeFailed("현재 위치를 확인하는 중입니다. 잠시 후 다시 눌러 주세요.");
                return;
            }
            origin = new KakaoRouteRepository.PlaceOption("현재 위치", "GPS", here.getLatitude(), here.getLongitude());
        } else {
            origin = new KakaoRouteRepository.PlaceOption(e.originName, "", e.originLatitude, e.originLongitude);
        }
        onAnalyzeRoute(origin.name, destination.name, 2, origin, destination);
    }

    public void onRecentRouteRemoved(int index) {
        publishRecentRoutes(RecentRouteStore.remove(this, index));
    }

    /**
     * 안내 시작: 내비게이션 화면으로 전환하고 현재 위치를 1초마다 추적합니다.
     * 회전 안내·남은 거리·도착 판단은 NavigationTracker가 계산합니다. (시연용, 실도로 내비 아님)
     */
    public void onStartGuidanceRequested() {
        if (pendingRoute == null || pendingRoute.points.size() < 2) {
            Toast.makeText(this, "먼저 경로를 분석해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasLocationPermission()) {
            pendingGuidancePermission = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
            return;
        }
        guidanceActive = true;
        followMyLocation = true;
        // 안내 중에는 잠금화면 위에도 안내 화면을 보여 줌 (알림을 누르면 잠금 해제 없이 확인)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true);
        startDirectionSensor();
        // 화면을 끄거나 다른 앱을 써도 위치·음성 안내가 계속되도록 포그라운드 서비스 시작
        requestNotificationPermissionOnce();
        lastNavNotificationStep = -2;
        rideStartedAt = System.currentTimeMillis();
        rideDistanceMeters = 0;
        rideOriginName = pendingRoute.matchedOrigin;
        rideZonesPassedBase = 0;
        hazardAhead = null;
        NavigationForegroundService.start(this, simulationActive ? "주행 시뮬레이션 중" : "자전거 길 안내 중",
                pendingRoute.destinationName + "까지 안내 · 화면을 꺼도 음성 안내가 계속됩니다");
        navTracker = new NavigationTracker(pendingRoute.points, pendingRoute.guideSteps);
        resetNavAnnouncements();
        rebuildHazardAhead();
        offRouteCount = 0;
        rerouting = false;
        previousNavLocation = null;
        navigationGpsGuard.resetArrival();
        gpsUnstableMessageShown = false;
        applyKeepScreenOn();
        BikeUiBridge.navStarted(pendingRoute.destinationName, pendingRoute.durationSeconds,
                pendingRoute.distanceMeters, hazardFractions());
        BikeUiBridge.navMessage("경로 안내를 시작합니다.");
        speak("경로 안내를 시작합니다.");
        trackingLocation = true;
        centerOnNextLocation = false;
        startLocationUpdates();
        // 자전거 안내: 안내 시작 즉시 내 위치(없으면 경로 출발점)로 확대합니다.
        Location startView = currentOriginFix();
        if (startView != null) {
            moveCameraToPoint(startView.getLatitude(), startView.getLongitude(), NAV_ZOOM);
        } else {
            KakaoRouteRepository.Point first = pendingRoute.points.get(0);
            moveCameraToPoint(first.latitude, first.longitude, NAV_ZOOM);
        }
        if (isFreshLocation(lastLocation) &&
                lastLocation.getAccuracy() <= NavigationGpsGuard.MAX_NAV_ACCURACY_METERS) {
            drawCurrentLocation(lastLocation);
            updateNavigation(lastLocation);
        } else {
            onGpsSignalUnstable();
        }
    }

    /** 주행 화면 상단 검색으로 목적지를 바로 변경 (종료 X 버튼 불필요). */
    public void onSearchDestinationDuringGuidance(String destination) {
        String query = destination == null ? "" : destination.trim();
        if (!guidanceActive || query.isEmpty()) return;
        if (lastLocation == null || !isFreshLocation(lastLocation)) {
            BikeUiBridge.navMessage("정확한 현재 위치를 확인한 뒤 다시 검색해 주세요.");
            startLocationUpdates();
            return;
        }
        Location origin = new Location(lastLocation);
        KakaoRouteRepository.PlaceOption start = new KakaoRouteRepository.PlaceOption(
                "현재 위치", "GPS", origin.getLatitude(), origin.getLongitude());
        stopGuidance(null);
        BikeUiBridge.routeCleared();
        onAnalyzeRoute("현재 위치", query, 2, start, null);
    }

    /** 알림의 '안내 종료' 버튼 (잠금화면에서도 누를 수 있음) */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && NavigationForegroundService.ACTION_END_GUIDANCE.equals(intent.getAction())) {
            onEndGuidanceRequested();
        }
    }

    // ── 주행 시뮬레이션 (시연 모드) ──

    /**
     * 미리보기의 '주행 시뮬레이션' 버튼: 현재 경로의 출발점부터 약 22km/h로 이동하는 가짜 GPS를 1초마다 넣고
     * 길 안내를 시작합니다. 회전 음성·위험 경고·도착 종료·잠금화면 알림이 실제 주행과 같은 코드로 동작합니다.
     * 화면을 꺼도 계속되도록 시뮬레이션 동안만 CPU 깨우기(WakeLock)를 유지합니다. 주행 기록에는 저장하지 않습니다.
     */
    public void onSimulateGuidanceRequested() {
        if (pendingRoute == null || pendingRoute.points.size() < 2 || guidanceActive) return;
        if (!hasLocationPermission()) {
            // 포그라운드 서비스(위치) 시작에 위치 권한이 필요
            onCurrentLocationRequested();
            Toast.makeText(this, "위치 권한을 허용한 뒤 다시 눌러 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        stopLocationUpdates();
        simulationActive = true;
        lastLocation = null;
        lastOriginCandidate = null;
        previousNavLocation = null;
        trackingLocation = true;
        BikeUiBridge.navSimulated(false);
        onStartGuidanceRequested();
        if (!guidanceActive) { stopSimulation(); return; }
        BikeUiBridge.navSimulated(true);
        BikeUiBridge.navMessage("주행 시뮬레이션을 시작합니다 · 실제 GPS 아님");
        acquireSimulationWakeLock();
        startSimulationFeed(pendingRoute.points);
    }

    private void startSimulationFeed(List<KakaoRouteRepository.Point> route) {
        final List<KakaoRouteRepository.Point> points = new ArrayList<>(route);
        final double[] cumulative = new double[points.size()];
        for (int i = 1; i < points.size(); i++) {
            cumulative[i] = cumulative[i - 1] + distanceMeters(points.get(i - 1).latitude, points.get(i - 1).longitude,
                    points.get(i).latitude, points.get(i).longitude);
        }
        final double total = cumulative[cumulative.length - 1];
        final double[] travelled = {0};
        final int[] ticksAtEnd = {0};
        simulationTick = new Runnable() {
            @Override public void run() {
                if (!simulationActive || !guidanceActive) return;
                double d = Math.min(total, travelled[0]);
                int seg = 1;
                while (seg < cumulative.length - 1 && cumulative[seg] < d) seg++;
                KakaoRouteRepository.Point a = points.get(seg - 1), b = points.get(seg);
                double segLen = Math.max(1e-6, cumulative[seg] - cumulative[seg - 1]);
                double t = Math.max(0, Math.min(1, (d - cumulative[seg - 1]) / segLen));
                Location fake = new Location(SIMULATION_PROVIDER);
                fake.setLatitude(a.latitude + (b.latitude - a.latitude) * t);
                fake.setLongitude(a.longitude + (b.longitude - a.longitude) * t);
                fake.setAccuracy(5f);
                fake.setSpeed(d >= total ? 0f : (float) SIMULATION_SPEED_MPS);
                fake.setBearing((float) bearingDegrees(a.latitude, a.longitude, b.latitude, b.longitude));
                fake.setTime(System.currentTimeMillis());
                fake.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                onLocationChanged(fake);
                if (d >= total) {
                    // 도착 지점에서 몇 번 더 보내 '3회 연속 확인' 도착 판정이 되게 함
                    if (++ticksAtEnd[0] > 8) { stopGuidance("시뮬레이션을 마쳤습니다."); return; }
                } else {
                    travelled[0] += SIMULATION_SPEED_MPS * (SIMULATION_TICK_MS / 1000.0);
                }
                if (simulationActive) simulationHandler.postDelayed(this, SIMULATION_TICK_MS);
            }
        };
        simulationHandler.post(simulationTick);
    }

    private static double bearingDegrees(double lat1, double lng1, double lat2, double lng2) {
        double dx = (lng2 - lng1) * Math.cos(Math.toRadians((lat1 + lat2) / 2));
        double dy = lat2 - lat1;
        return (Math.toDegrees(Math.atan2(dx, dy)) + 360.0) % 360.0;
    }

    @SuppressWarnings("WakelockTimeout")
    private void acquireSimulationWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            simulationWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BicycleSafety:simulation");
            simulationWakeLock.acquire(2 * 60 * 60 * 1000L); // 최대 2시간
        } catch (Exception error) {
            Log.w(TAG, "시뮬레이션 화면 꺼짐 유지 실패", error);
        }
    }

    private void stopSimulation() {
        if (!simulationActive) return;
        simulationActive = false;
        if (simulationTick != null) simulationHandler.removeCallbacks(simulationTick);
        simulationTick = null;
        try {
            if (simulationWakeLock != null && simulationWakeLock.isHeld()) simulationWakeLock.release();
        } catch (Exception ignored) { }
        simulationWakeLock = null;
        // 가짜 위치가 실제 위치 판정에 섞이지 않도록 초기화
        lastLocation = null;
        lastOriginCandidate = null;
        previousNavLocation = null;
        markerCenterLocation = null;
        BikeUiBridge.navSimulated(false);
    }

    /** 내비게이션 화면의 종료 버튼 */
    public void onEndGuidanceRequested() {
        if (guidanceActive) stopGuidance("경로 안내를 종료합니다.");
    }

    /** 길 안내 화면의 '내 위치' 버튼: 다시 내 위치로 이동하고 따라가기를 켭니다. */
    public void onRecenterRequested() {
        followMyLocation = true;
        BikeUiBridge.navFollowing(true);
        Location here = currentOriginFix();
        if (here != null) moveCameraToLocation(here, NAV_ZOOM);
    }

    /** 내비게이션 화면의 재탐색 버튼 */
    public void onRerouteRequested() {
        if (!guidanceActive) return;
        if (lastLocation == null) {
            BikeUiBridge.navMessage("현재 위치를 확인하는 중입니다.");
            return;
        }
        requestReroute(lastLocation, false);
    }

    private void stopGuidance(String spoken) {
        // 시뮬레이션은 기록에 저장하지 않음 (요약 카드만 표시). spoken == null 은 내부 전환이라 카드도 생략
        boolean arrivedEnd = spoken != null && (spoken.contains("도착") || spoken.contains("시뮬레이션을 마쳤"));
        finishRide(arrivedEnd, simulationActive, spoken != null);
        rideStartedAt = 0;
        stopSimulation();
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(false);
        guidanceActive = false;
        followMyLocation = true;
        NavigationForegroundService.stop(this);
        stopDirectionSensor();
        navTracker = null;
        hazardAhead = null;
        rerouting = false;
        offRouteCount = 0;
        previousNavLocation = null;
        navigationGpsGuard.resetArrival();
        gpsUnstableMessageShown = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BikeUiBridge.navEnded();
        if (lastLocation != null) drawCurrentLocation(lastLocation);
        if (spoken != null) speak(spoken);
        // 안내가 끝나면 전체 경로가 보이게 되돌리고, 위치 갱신 간격도 평소대로
        if (pendingRoute != null) showRouteOnMap(pendingRoute, true);
        if (trackingLocation && hasLocationPermission()) startLocationUpdates();
    }

    private void resetNavAnnouncements() {
        lastPreAnnouncedStep = -1;
        lastSpokenStep = -1;
    }

    /** 경로 주변 사고다발지역의 경로상 위치 (오른쪽 진행 막대 표시용, 0~1) */
    private float[] hazardFractions() {
        if (navTracker == null) return new float[0];
        float[] result = new float[routeHazardsVisible.size()];
        for (int i = 0; i < result.length; i++) {
            RiskPoint p = routeHazardsVisible.get(i);
            result[i] = (float) navTracker.fractionAlong(p.latitude, p.longitude);
        }
        return result;
    }

    /** '안전 우선' 카드 아래 설명 (대안이 없을 때는 왜 없는지 진단 정보도 표시) */
    private static String safetyNote(SafetyRoutePlanner.Selection safest, int baselineCount, int risk) {
        if (safest == null) return "별도 회피 경로를 찾지 못함 · 기존 경로와 동일";
        if (safest.distinct) {
            return "위험 점수 " + safest.reductionPercent() + "% 감소"
                    + (baselineCount > risk ? " · 사고 이력 " + (baselineCount - risk) + "곳 감소" : "")
                    + (safest.safetyFallback ? " · 조금 더 돌아감" : "")
                    + " · 과거 자료 기반";
        }
        if (safest.baselineScore <= 0) return "경로 주변 사고 이력 없음 · 기존 경로 그대로 안전";
        String base = "별도 회피 경로를 찾지 못함 · 기존 경로와 동일";
        if (safest.candidatesTried > 0) {
            base += " (우회 후보 " + safest.candidatesTried + "개 중 " + safest.candidatesValid + "개 검토)";
        }
        return base;
    }

    /** 경로 주변 위험지점을 경로상 위치(m)로 바꿔 '앞쪽 사고 다발 구간' 목록을 만듭니다. */
    private void rebuildHazardAhead() {
        BikeUiBridge.navHazard(null, false, 0);
        // 재탐색으로 구간 목록을 새로 만들기 전, 지금까지 지나간 구간 수를 누적
        if (hazardAhead != null) rideZonesPassedBase += hazardAhead.passedCount();
        if (navTracker == null) { hazardAhead = null; return; }
        double total = navTracker.getTotalMeters();
        double[] along = new double[routeHazardsVisible.size()];
        int[] accidents = new int[along.length];
        for (int i = 0; i < along.length; i++) {
            RiskPoint p = routeHazardsVisible.get(i);
            along[i] = navTracker.fractionAlong(p.latitude, p.longitude) * total;
            accidents[i] = p.accidentCount;
        }
        hazardAhead = new HazardAheadGuide(along, accidents);
    }

    /** 위젯 갱신 + 음성. 같은 위치에서 회전 안내를 했으면 회전 먼저, 1초 쉬고 위험 안내. */
    private void updateHazardAhead(NavigationTracker.Snapshot snap, boolean turnSpoken) {
        if (hazardAhead == null || navTracker == null) return;
        double along = Math.max(0, navTracker.getTotalMeters() - snap.remainingMeters);
        HazardAheadGuide.State state = hazardAhead.update(along);
        if (!state.visible) {
            BikeUiBridge.navHazard(null, false, 0);
        } else if (state.inside) {
            BikeUiBridge.navHazard("사고 다발 구간 통과 중", true, state.accidents);
        } else {
            BikeUiBridge.navHazard("사고 다발 구간 " + state.displayMeters + "m 앞", false, state.accidents);
        }
        String speech = HazardAheadGuide.speech(state);
        if (speech == null || rerouting) return;
        if (turnSpoken && ttsReady && textToSpeech != null) {
            textToSpeech.playSilentUtterance(1000, TextToSpeech.QUEUE_ADD, "pause_" + SystemClock.uptimeMillis());
        }
        speakQueued(speech);
    }

    private void updateNavigation(Location location) {
        if (!guidanceActive || navTracker == null || pendingRoute == null) return;
        if (location == null || !NavigationGpsGuard.isUsableFix(
                location.hasAccuracy(), location.getAccuracy(),
                location.getElapsedRealtimeNanos(), SystemClock.elapsedRealtimeNanos(),
                NavigationGpsGuard.MAX_NAV_ACCURACY_METERS)) {
            onGpsSignalUnstable();
            return;
        }
        // 정밀도가 확인된 GPS만 지도 추적과 길 안내 계산에 반영합니다.
        NavigationTracker.Snapshot snap = navTracker.update(location.getLatitude(), location.getLongitude());
        if (followMyLocation) moveCameraToLocation(location, NAV_ZOOM);
        boolean offRoute = snap.offRouteMeters > OFF_ROUTE_METERS;

        // 경로 투영 결과만으로 '도착' 처리하면 GPS 튐/교차 경로 때문에 오종료될 수 있습니다.
        // 실제 목적지까지 25m 이내 + 경로 끝 25m 이내 + 경로 위 + 오차 20m 이하,
        // 서로 다른 GPS 수신 시각의 연속 3회 모두 충족할 때만 안내를 종료합니다.
        KakaoRouteRepository.Point destination = pendingRoute.points.get(pendingRoute.points.size() - 1);
        float[] destinationDistance = new float[1];
        Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                destination.latitude, destination.longitude, destinationDistance);
        boolean plausibleArrival = snap.arrived
                && snap.remainingMeters <= NavigationTracker.ARRIVE_METERS
                && destinationDistance[0] <= NavigationTracker.ARRIVE_METERS
                && snap.offRouteMeters <= NavigationTracker.ARRIVE_METERS
                && location.getAccuracy() <= NavigationGpsGuard.MAX_ARRIVAL_ACCURACY_METERS;
        if (navigationGpsGuard.confirmArrival(plausibleArrival, location.getElapsedRealtimeNanos())) {
            stopGuidance("목적지에 도착했습니다. 경로 안내를 종료합니다.");
            Toast.makeText(this, "목적지에 도착했습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        // GPS 튐을 피하려고 3번 연속 벗어났을 때만 자동 재탐색 (15초 간격)
        offRouteCount = offRoute ? offRouteCount + 1 : 0;
        if (offRouteCount >= 3 && !rerouting
                && SystemClock.elapsedRealtime() - lastRerouteAt > 15000) {
            requestReroute(location, true);
        }

        List<KakaoRouteRepository.GuideStep> steps = navTracker.getSteps();
        NavigationTracker.Maneuver maneuver = NavigationTracker.Maneuver.ARRIVE;
        String instruction = "목적지까지 이동";
        if (snap.nextStepIndex >= 0) {
            instruction = steps.get(snap.nextStepIndex).guidance;
            maneuver = NavigationTracker.maneuverOf(instruction);
        }
        String following = null;
        if (snap.followingStepIndex >= 0) {
            following = NavigationTracker.maneuverOf(steps.get(snap.followingStepIndex).guidance).name();
        }
        double total = Math.max(1.0, navTracker.getTotalMeters());
        int remainingSeconds = (int) Math.round(pendingRoute.durationSeconds * (snap.remainingMeters / total));
        BikeUiBridge.navProgress(maneuver.name(), NavigationTracker.labelOf(maneuver), instruction,
                (int) Math.round(snap.distanceToNext), following, (int) Math.round(snap.followingDistance),
                (int) Math.round(snap.remainingMeters), remainingSeconds, speedKmh(location),
                (float) snap.progress, offRoute);
        boolean turnSpoken = announceGuidance(snap, steps);
        updateHazardAhead(snap, turnSpoken);
        updateNavNotification(snap.nextStepIndex, NavigationTracker.labelOf(maneuver),
                (int) Math.round(snap.distanceToNext), (int) Math.round(snap.remainingMeters), snap.progress);
        if (previousNavLocation != null) {
            float moved = previousNavLocation.distanceTo(location);
            if (moved < 200f) rideDistanceMeters += moved; // GPS 튐(200m 이상 순간 이동)은 기록에서 제외
        }
        previousNavLocation = new Location(location);
    }

    /** 백그라운드 알림: 다음 안내가 바뀌거나 10초가 지났을 때만 갱신 (배터리·알림 깜빡임 방지) */
    private void updateNavNotification(int stepIndex, String label, int distanceToNext, int remaining,
                                       double progress) {
        long now = SystemClock.elapsedRealtime();
        if (stepIndex == lastNavNotificationStep && now - lastNavNotificationMs < 5000L) return;
        lastNavNotificationStep = stepIndex;
        lastNavNotificationMs = now;
        String remain = remaining >= 1000 ? String.format(Locale.KOREA, "%.1fkm", remaining / 1000.0) : remaining + "m";
        String next = stepIndex >= 0 ? distanceToNext + "m 앞 " + label : "목적지까지 이동";
        NavigationForegroundService.update(this,
                (simulationActive ? "[시뮬레이션] " : "") + next,
                (pendingRoute == null ? "목적지" : pendingRoute.destinationName) + " · 남은 거리 " + remain,
                (int) Math.round(Math.max(0, Math.min(1, progress)) * 1000));
    }

    /**
     * 길 안내가 끝나면 주행 기록을 저장합니다 (마이페이지 '최근 주행'·통계용).
     * 1분 미만이면서 100m 미만인 시험 안내는 저장하지 않습니다. 저장소는 AppRepositories가 고릅니다.
     * 끝나면 주행 요약 카드(거리·시간·평균 속도·지나간 사고 다발 구간)를 띄웁니다.
     */
    private void finishRide(boolean arrived, boolean simulated, boolean showSummary) {
        if (rideStartedAt <= 0) return;
        long start = rideStartedAt;
        long end = System.currentTimeMillis();
        rideStartedAt = 0;
        int seconds = (int) ((end - start) / 1000L);
        int meters = (int) Math.round(rideDistanceMeters);
        int zones = rideZonesPassedBase + (hazardAhead == null ? 0 : hazardAhead.passedCount());
        if (seconds < 60 && meters < 100) return; // 너무 짧은 주행은 저장·요약 모두 생략
        String destination = pendingRoute == null ? "" : pendingRoute.destinationName;
        boolean saved = false;
        if (!simulated) {
            RideRecord record = new RideRecord("", start, end, meters, seconds,
                    rideOriginName, destination, currentRouteMode, arrived, zones);
            try {
                AppRepositories.rides(this).add(record, null);
                saved = true;
            } catch (Exception error) {
                Log.w(TAG, "주행 기록 저장 실패", error);
            }
        }
        if (showSummary) {
            BikeUiBridge.rideFinished(arrived, destination, meters, seconds, zones,
                    currentRouteMode == 0, simulated, saved);
        }
    }

    // ── 카카오 로그인 (마이페이지 프로필 카드) ──

    public void onKakaoLoginRequested() {
        BikeUiBridge.accountUpdated(false, "", false, "카카오 로그인 중…", true);
        KakaoAuthManager.login(this, (session, message) -> {
            if (!isDestroyed()) publishAccount(session, message);
        });
    }

    public void onKakaoLogoutRequested() {
        KakaoAuthManager.logout(this, () -> {
            if (!isDestroyed()) publishAccount(null, "로그아웃했어요.");
        });
    }

    private void publishAccount(UserSession session, String message) {
        String text = message == null ? "" : message;
        if (session == null) BikeUiBridge.accountUpdated(false, "", false, text, false);
        else BikeUiBridge.accountUpdated(true, session.nickname, session.serverVerified, text, false);
    }

    /** Android 13 이상: 길 안내 알림 표시 권한을 한 번만 요청 (거부해도 안내는 동작) */
    private void requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;
        android.content.SharedPreferences prefs = getSharedPreferences("bike_permissions", MODE_PRIVATE);
        if (prefs.getBoolean("notification_asked", false)) return;
        prefs.edit().putBoolean("notification_asked", true).apply();
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
    }

    /** 회전 150m 전 예고 1번 + 30m 전 1번. 같은 문구를 반복하지 않습니다. */
    private boolean announceGuidance(NavigationTracker.Snapshot snap,
                                     List<KakaoRouteRepository.GuideStep> steps) {
        if (snap.nextStepIndex < 0 || rerouting) return false;
        int index = snap.nextStepIndex;
        // 카카오 안내 문장(주소·횡단보도·OO까지 이동)은 화면에만 보이고, 음성은 방향만 짧게 (카카오맵 방식)
        NavigationTracker.Maneuver m = NavigationTracker.maneuverOf(steps.get(index).guidance);
        if (m == NavigationTracker.Maneuver.STRAIGHT || m == NavigationTracker.Maneuver.START) return false; // 직진은 말하지 않음
        String word = m == NavigationTracker.Maneuver.ARRIVE ? "목적지" : NavigationTracker.labelOf(m);
        double d = snap.distanceToNext;
        if (d <= 35 && lastSpokenStep != index) {
            lastSpokenStep = index;
            lastPreAnnouncedStep = index;
            speakQueued(m == NavigationTracker.Maneuver.ARRIVE ? "목적지 부근입니다" : word);
            return true;
        } else if (d > 60 && d <= 160 && lastPreAnnouncedStep != index) {
            lastPreAnnouncedStep = index;
            long rounded = Math.round(d / 10.0) * 10;
            speakQueued(rounded + "미터 앞 " + word);
            return true;
        }
        return false;
    }

    private int speedKmh(Location location) {
        if (location.hasSpeed()) return Math.max(0, Math.round(location.getSpeed() * 3.6f));
        if (previousNavLocation == null) return -1;
        long dtMs = location.getTime() - previousNavLocation.getTime();
        if (dtMs <= 0) return -1;
        double kmh = previousNavLocation.distanceTo(location) / (dtMs / 1000.0) * 3.6;
        return kmh > 80 ? -1 : (int) Math.round(kmh);
    }

    /** 경로를 벗어났을 때 현재 위치에서 같은 도착지로 다시 찾습니다. */
    private void requestReroute(Location from, boolean automatic) {
        if (rerouting || pendingRoute == null) return;
        if (BuildConfig.KAKAO_REST_API_KEY.isEmpty()) {
            BikeUiBridge.navMessage("REST API 키가 없어 재탐색할 수 없습니다.");
            return;
        }
        rerouting = true;
        lastRerouteAt = SystemClock.elapsedRealtime();
        BikeUiBridge.navRerouting(true);
        if (automatic) speakQueued("경로를 다시 찾습니다.");
        final KakaoRouteRepository.Result previous = pendingRoute;
        final double lat = from.getLatitude();
        final double lng = from.getLongitude();
        final int revision = routeRequestRevision;
        final List<RiskPoint> currentHazards = new ArrayList<>(hazardPoints);
        routeWorker.execute(() -> {
            try {
                KakaoRouteRepository.Result result;
                if (currentRouteMode == 0) {
                    KakaoRouteRepository.PlaceOption startPlace =
                            new KakaoRouteRepository.PlaceOption("현재 위치", "", lat, lng);
                    KakaoRouteRepository.PlaceOption to =
                            new KakaoRouteRepository.PlaceOption(previous.destinationName, "",
                                    previous.endLatitude, previous.endLongitude);
                    KakaoRouteRepository.Result bike = null, shortest = null;
                    try { bike = KakaoRouteRepository.routeBetween(BuildConfig.KAKAO_REST_API_KEY, startPlace, to, true); }
                    catch(Exception error) {Log.w(TAG, "재탐색 자전거도로 경로 실패", error);}
                    try { shortest = KakaoRouteRepository.routeBetween(BuildConfig.KAKAO_REST_API_KEY, startPlace, to, false); }
                    catch(Exception error) {Log.w(TAG, "재탐색 최단 경로 실패", error);}
                    SafetyRoutePlanner.Selection safe = SafetyRoutePlanner.choose(
                            BuildConfig.KAKAO_REST_API_KEY, startPlace, to, bike, shortest, currentHazards);
                    if (safe == null) throw new IllegalStateException("안전 우선 재탐색 후보 없음");
                    result = safe.route;
                } else {
                    result = KakaoRouteRepository.rerouteFrom(
                            BuildConfig.KAKAO_REST_API_KEY, lat, lng, previous);
                }
                List<RiskPoint> nearby = new ArrayList<>();
                for (RiskPoint hazard : currentHazards) {
                    if (distanceToRoute(hazard, result.points) <= ROUTE_HAZARD_METERS) nearby.add(hazard);
                }
                runOnUiThread(() -> {
                    rerouting = false;
                    BikeUiBridge.navRerouting(false);
                    if (isDestroyed() || revision != routeRequestRevision || !guidanceActive) return;
                    offRouteCount = 0;
                    pendingRoute = result;
                    routeHazardsVisible.clear();
                    routeHazardsVisible.addAll(nearby);
                    refreshHazardMarkers(routeHazardsVisible);
                    showRouteOnMap(result, false);
                    navTracker = new NavigationTracker(result.points, result.guideSteps);
                    navigationGpsGuard.resetArrival();
                    resetNavAnnouncements();
                    rebuildHazardAhead();
                    BikeUiBridge.navRouteReplaced(result.durationSeconds, result.distanceMeters, hazardFractions());
                    BikeUiBridge.navMessage("새 경로로 안내합니다.");
                    if (lastLocation != null) updateNavigation(lastLocation);
                });
            } catch (Exception error) {
                Log.w(TAG, "경로 재탐색 실패", error);
                runOnUiThread(() -> {
                    rerouting = false;
                    BikeUiBridge.navRerouting(false);
                    if (isDestroyed() || !guidanceActive) return;
                    BikeUiBridge.navMessage("재탐색 실패 · 네트워크를 확인해 주세요.");
                });
            }
        });
    }

    /** 길 안내 문구는 앞 안내를 끊지 않고 이어서 읽습니다. */
    /** 설정 화면에서 값이 바뀌면 바로 반영 */
    private void onSettingChanged(String key) {
        if (AppPrefs.BIKE_LANES.equals(key)) {
            applyBikeLaneOverlay();
        } else if (AppPrefs.KEEP_SCREEN_ON.equals(key)) {
            applyKeepScreenOn();
        } else if (AppPrefs.VOICE_GUIDE.equals(key) && !AppPrefs.voiceGuide(this) && textToSpeech != null) {
            textToSpeech.stop(); // 말하던 안내도 바로 멈춤
        }
    }

    /** 설정 '자전거도로 표시': 카카오 지도 기본 자전거도로 오버레이 켜기/끄기 */
    private void applyBikeLaneOverlay() {
        if (activeMap == null) return;
        try {
            if (AppPrefs.bikeLanes(this)) activeMap.showOverlay(MapOverlay.BICYCLE_ROAD);
            else activeMap.hideOverlay(MapOverlay.BICYCLE_ROAD);
        } catch (Exception error) {
            Log.w(TAG, "자전거도로 오버레이 설정 실패", error);
        }
    }

    /** 설정 '화면 꺼짐 방지': 길 안내 중에만 화면을 켜 둠 */
    private void applyKeepScreenOn() {
        if (guidanceActive && AppPrefs.keepScreenOn(this)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void speakQueued(String message) {
        if (!AppPrefs.voiceGuide(this)) return; // 설정에서 음성 안내를 끈 경우
        if (ttsReady && textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_ADD, null, "nav_" + SystemClock.uptimeMillis());
        }
    }

    private void speak(String message) {
        if (!AppPrefs.voiceGuide(this)) return; // 설정에서 음성 안내를 끈 경우
        if (ttsReady && textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "bike_" + SystemClock.uptimeMillis());
        } else {
            Toast.makeText(this, "음성 엔진 준비 중: " + message, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("safety_confirmed", isSafetyConfirmed);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        AppPrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(settingsListener);
        stopDirectionSensor();
        routeRequestRevision++;
        routeWorker.shutdownNow();
        hazardWorker.shutdownNow();
        placeWorker.shutdownNow();
        stopLocationUpdates();
        if (guidanceActive) finishRide(false, simulationActive, false); // 앱 종료 시: 기록만 저장, 카드 없음
        stopSimulation();
        NavigationForegroundService.stop(this);
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); }
        activeMap = null;
        routeLayer = null;
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mapView != null && isMapStarted) mapView.resume();
        if (guidanceActive) startDirectionSensor();
        if (isSafetyConfirmed && hasLocationPermission()) {
            trackingLocation = true;
            startLocationUpdates();
        }
    }

    @Override
    protected void onPause() {
        stopDirectionSensor();
        if (mapView != null && isMapStarted) mapView.pause();
        // 길 안내 중이면 화면이 꺼져도 위치 갱신을 유지 (포그라운드 서비스가 백그라운드 위치를 허용)
        if (!guidanceActive) stopLocationUpdates();
        super.onPause();
    }
}
