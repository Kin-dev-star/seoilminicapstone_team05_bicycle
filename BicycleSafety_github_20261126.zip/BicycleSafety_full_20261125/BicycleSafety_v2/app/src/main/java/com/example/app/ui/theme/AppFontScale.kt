package com.example.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

/**
 * 기기 글꼴 크기 설정 따르기 (2026-11-26)
 *
 * - 글꼴 모양: 앱이 따로 글꼴을 지정하지 않아(기본 글꼴) 갤럭시 '글꼴 스타일' 설정을 그대로 따름
 * - 글꼴 크기: 모든 글자가 sp 단위라 기기 '글꼴 크기'를 따름. 다만 접근성 '아주 큰 글자'(최대 약 2배)에서는
 *   카드·버튼이 깨지므로 앱 안에서는 [MIN]~[MAX] 범위로만 반영 (범위 안이면 기기 값을 그대로 사용)
 * - 내비게이션 화면은 원래 글자가 크고 지도를 가리면 안 되므로 [NAV_MAX] 까지만
 */
object AppFontScale {
    const val MIN = 0.85f
    const val MAX = 1.3f
    const val NAV_MAX = 1.15f
}

@Composable
fun FollowDeviceFontScale(max: Float = AppFontScale.MAX, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val scale = density.fontScale.coerceIn(AppFontScale.MIN, max)
    if (scale == density.fontScale) {
        content() // 범위 안: 기기 설정 그대로 (안드로이드 14+의 비선형 글자 확대도 유지)
    } else {
        CompositionLocalProvider(LocalDensity provides Density(density.density, scale), content = content)
    }
}
