package com.example.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import java.util.Locale
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import com.example.bicyclesafety.R
import com.example.app.ui.theme.FollowDeviceFontScale
import com.example.app.ui.theme.Soft
import com.example.bicyclesafety.MainActivity
import com.example.bicyclesafety.RiskPoint
import com.example.bicyclesafety.KakaoRouteRepository

/** 경로 3개 비교 카드. 위험도는 과거 사고지점 150m 이내 단순 개수입니다. */
data class RouteChoiceUi(
    val mode: Int,
    val title: String,
    val distanceMeters: Int,
    val durationSeconds: Int,
    val hazardCount: Int,
    val available: Boolean,
    val note: String,
)

data class PlaceSearchUiState(
    val field: Int = -1,
    val query: String = "",
    val items: List<KakaoRouteRepository.PlaceOption> = emptyList(),
    val status: String = "",
)
data class GpsOriginSelection(val latitude: Double, val longitude: Double, val version: Int)

/** 마이페이지 프로필 카드의 로그인 상태 */
data class AccountUi(
    val loggedIn: Boolean = false,
    val nickname: String = "",
    /** 서버가 카카오 토큰을 확인했는지 */
    val verified: Boolean = false,
    val message: String = "",
    val busy: Boolean = false,
)

/** 경로 설정 창 '최근 경로' 한 줄. 좌표는 Java(RecentRouteStore)가 보관합니다. */
data class RecentRouteUi(
    val originName: String,
    val destinationName: String,
    val originIsGps: Boolean,
)

/** Current query only; elevation cannot be inferred from the bicycle route response. */
data class RouteUiState(
    val loading: Boolean = false,
    val distanceMeters: Int? = null,
    val durationSeconds: Int? = null,
    val message: String = "출발지와 도착지를 입력하면 표시돼요",
    val error: Boolean = false,
    val routeHazards: Int? = null,
    val hazardDataSource: String = "",
    /** 경로 미리보기 카드용: "자전거도로 우선" / "최단 경로", 출발·도착 이름 */
    val modeLabel: String = "",
    val startName: String = "",
    val endName: String = "",
    val choices: List<RouteChoiceUi> = emptyList(),
    val selectedMode: Int = 2,
    /** 출발지가 현재 위치(GPS)인지. 아니면 미리보기에 '내 위치에서 안내' 버튼 표시 */
    val fromCurrentLocation: Boolean = true,
)

/**
 * 길 안내(내비게이션) 화면 상태. Java MainActivity가 위치가 바뀔 때마다 갱신합니다.
 * maneuver 값은 NavigationTracker.Maneuver 이름 (LEFT, RIGHT, STRAIGHT, ...).
 */
/** 특정 장소(제보 위치)를 우리 지도에 보여 달라는 요청. id로 매번 새 요청을 구분 */
data class MapFocusRequest(val id: Long, val name: String, val latitude: Double, val longitude: Double)

/** 안내가 끝난 뒤 보여 주는 주행 요약 */
data class RideFinishedUi(
    val arrived: Boolean,
    val destination: String,
    val distanceMeters: Int,
    val durationSeconds: Int,
    val hazardZonesPassed: Int,
    val safeRoute: Boolean,
    val simulated: Boolean,
    val saved: Boolean,
)

data class NavUiState(
    val active: Boolean = false,
    /** 안내 시작 후 첫 위치를 받았는지 */
    val hasFix: Boolean = false,
    val maneuver: String = "STRAIGHT",
    val maneuverLabel: String = "",
    val instruction: String = "",
    /** 다음 안내 지점까지 남은 거리 (m) */
    val distanceToNext: Int = 0,
    /** 그다음 안내 (없으면 null) */
    val nextManeuver: String? = null,
    val nextDistance: Int = 0,
    val remainingMeters: Int = 0,
    val remainingSeconds: Int = 0,
    /** 현재 속도 km/h (모르면 -1) */
    val speedKmh: Int = -1,
    /** 진행률 0~1 */
    val progress: Float = 0f,
    /** 경로 주변 사고다발지역의 경로상 위치 0~1 */
    val hazardMarks: List<Float> = emptyList(),
    /** 앞쪽 사고 다발 구간 안내 ("사고 다발 구간 250m 앞"), 없으면 null */
    val hazardAhead: String? = null,
    /** 사고 다발 구간을 통과 중인지 */
    val hazardInside: Boolean = false,
    /** 그 구간의 과거 사고 건수 합계 */
    val hazardAccidents: Int = 0,
    val offRoute: Boolean = false,
    val rerouting: Boolean = false,
    /** 지도가 내 위치를 따라가는 중인지 (false면 '내 위치' 버튼 표시) */
    val following: Boolean = true,
    /** 주행 시뮬레이션(시연 모드) 중인지 */
    val simulated: Boolean = false,
    val destination: String = "",
    /** 화면 아래 잠깐 보이는 알림 ("경로 안내를 시작합니다." 등) */
    val message: String? = null,
    val messageId: Int = 0,
)

/** Only place that links the Java map/feature layer with the new Compose design. */
object BikeUiBridge {
    private var activeRiskPoint by mutableStateOf<RiskPoint?>(null)
    private var safetyRequired by mutableStateOf(false)
    private var routeUiState by mutableStateOf(RouteUiState())
    private var proximityWarning by mutableStateOf<String?>(null)
    private var navUiState by mutableStateOf(NavUiState())
    private var placeSearchUi by mutableStateOf(PlaceSearchUiState())
    private var gpsOrigin by mutableStateOf<GpsOriginSelection?>(null)
    private var recentRoutes by mutableStateOf<List<RecentRouteUi>>(emptyList())
    private var accountUi by mutableStateOf(AccountUi())
    private var rideFinishedUi by mutableStateOf<RideFinishedUi?>(null)

    /** 제보게시판 '지도에서 보기' → 화면(MainScreen)은 페이지를 닫고, MainActivity는 지도를 옮김 */
    var mapFocusRequest by mutableStateOf<MapFocusRequest?>(null)
        private set

    fun showOnMap(name: String, latitude: Double, longitude: Double) {
        mapFocusRequest = MapFocusRequest(System.nanoTime(), name, latitude, longitude)
    }

    @JvmStatic
    fun accountUpdated(loggedIn: Boolean, nickname: String, verified: Boolean, message: String, busy: Boolean) {
        accountUi = AccountUi(loggedIn, nickname, verified, message, busy)
    }
    private var locationVersion = 0

    @JvmStatic
    fun recentRoutesUpdated(items: List<RecentRouteUi>) { recentRoutes = items.toList() }

    @JvmStatic
    fun routeStarted() { routeUiState = RouteUiState(loading = true, message = "장소 검색 및 자전거 경로 조회 중…") }

    @JvmStatic
    fun routeSucceeded(distanceMeters: Int, durationSeconds: Int, startName: String, endName: String, safe: Boolean, routeHazards: Int, hazardDataSource: String) {
        val mode = if (safe) "자전거도로 우선" else "최단 경로"
        routeUiState = RouteUiState(
            distanceMeters = distanceMeters, durationSeconds = durationSeconds,
            message = "$mode · $startName → $endName\n" +
                    (if (routeHazards < 0) "사고 데이터가 준비되지 않아 주변 사고 이력을 확인하지 못했습니다.\n실제 안전 회피 계산 미적용 · 첫 번째 장소 검색 결과 사용"
                    else "경로 주변 150m 이내 과거 사고다발지역: ${routeHazards}곳 ($hazardDataSource)\n실제 안전 회피 계산 미적용 · 첫 번째 장소 검색 결과 사용"),
            routeHazards = routeHazards, hazardDataSource = hazardDataSource,
            modeLabel = mode, startName = startName, endName = endName,
        )
    }

    @JvmStatic
    fun placesUpdated(field: Int, query: String,
                      items: List<KakaoRouteRepository.PlaceOption>, status: String) {
        placeSearchUi = PlaceSearchUiState(field, query, items, status)
    }

    @JvmStatic
    fun originSelected(latitude: Double, longitude: Double) {
        gpsOrigin = GpsOriginSelection(latitude, longitude, ++locationVersion)
    }

    @JvmStatic
    fun routesCompared(items: List<RouteChoiceUi>, selectedMode: Int,
                       start: String, end: String, dataSource: String,
                       fromCurrentLocation: Boolean) {
        val choice = items.firstOrNull { it.mode == selectedMode && it.available } ?: return
        routeUiState = RouteUiState(
            distanceMeters = choice.distanceMeters,
            durationSeconds = choice.durationSeconds,
            routeHazards = choice.hazardCount,
            hazardDataSource = dataSource,
            modeLabel = choice.title,
            startName = start,
            endName = end,
            choices = items.toList(),
            selectedMode = selectedMode,
            fromCurrentLocation = fromCurrentLocation,
            message = "${choice.title} · 경로 주변 과거 사고 이력 ${choice.hazardCount}곳 ($dataSource)\n" +
                    "${choice.note} · 과거 데이터이며 안전을 보장하지 않습니다.",
        )
    }

    // ── 길 안내 화면 (MainActivity → Compose) ──

    @JvmStatic
    fun navStarted(destination: String, durationSeconds: Int, distanceMeters: Int, hazardMarks: FloatArray) {
        navUiState = NavUiState(
            active = true, destination = destination,
            remainingMeters = distanceMeters, remainingSeconds = durationSeconds,
            hazardMarks = hazardMarks.toList(),
        )
    }

    @JvmStatic
    fun navProgress(
        maneuver: String, maneuverLabel: String, instruction: String, distanceToNext: Int,
        nextManeuver: String?, nextDistance: Int, remainingMeters: Int, remainingSeconds: Int,
        speedKmh: Int, progress: Float, offRoute: Boolean,
    ) {
        if (!navUiState.active) return
        navUiState = navUiState.copy(
            hasFix = true, maneuver = maneuver, maneuverLabel = maneuverLabel, instruction = instruction,
            distanceToNext = distanceToNext, nextManeuver = nextManeuver, nextDistance = nextDistance,
            remainingMeters = remainingMeters, remainingSeconds = remainingSeconds,
            speedKmh = speedKmh, progress = progress, offRoute = offRoute,
        )
    }

    @JvmStatic
    fun navSimulated(simulated: Boolean) {
        if (navUiState.active) navUiState = navUiState.copy(simulated = simulated)
    }

    @JvmStatic
    fun navHazard(text: String?, inside: Boolean, accidents: Int) {
        if (!navUiState.active) return
        val s = navUiState
        if (s.hazardAhead == text && s.hazardInside == inside && s.hazardAccidents == accidents) return
        navUiState = s.copy(hazardAhead = text, hazardInside = inside, hazardAccidents = accidents)
    }

    @JvmStatic
    fun navFollowing(following: Boolean) {
        if (navUiState.active) navUiState = navUiState.copy(following = following)
    }

    @JvmStatic
    fun navRerouting(rerouting: Boolean) {
        if (navUiState.active) navUiState = navUiState.copy(rerouting = rerouting)
    }

    @JvmStatic
    fun navRouteReplaced(durationSeconds: Int, distanceMeters: Int, hazardMarks: FloatArray) {
        if (!navUiState.active) return
        navUiState = navUiState.copy(
            remainingMeters = distanceMeters, remainingSeconds = durationSeconds,
            hazardMarks = hazardMarks.toList(), offRoute = false, progress = 0f,
        )
    }

    @JvmStatic
    fun navMessage(message: String) {
        navUiState = navUiState.copy(message = message, messageId = navUiState.messageId + 1)
    }

    @JvmStatic
    fun navEnded() { navUiState = NavUiState() }

    @JvmStatic
    fun rideFinished(arrived: Boolean, destination: String, distanceMeters: Int, durationSeconds: Int,
                     hazardZonesPassed: Int, safeRoute: Boolean, simulated: Boolean, saved: Boolean) {
        rideFinishedUi = RideFinishedUi(arrived, destination, distanceMeters, durationSeconds,
            hazardZonesPassed, safeRoute, simulated, saved)
    }

    @JvmStatic
    fun routeFailed(message: String) { routeUiState = RouteUiState(message = message, error = true) }

    @JvmStatic
    fun routeCleared() { routeUiState = RouteUiState() }

    @JvmStatic
    fun attach(activity: MainActivity, composeView: ComposeView, requireSafety: Boolean) {
        safetyRequired = requireSafety
        activeRiskPoint = null
        routeCleared()
        placeSearchUi = PlaceSearchUiState()
        gpsOrigin = null
        composeView.setViewCompositionStrategy(
            ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
        )
        composeView.setContent {
            // 기기 글꼴 크기를 따르되 화면이 깨지지 않는 범위로 제한 (AppFontScale.kt)
            FollowDeviceFontScale {
                BikeApp(
                    mapContent = { modifier ->
                        AndroidView(
                            modifier = modifier,
                            factory = { activity.acquireMapView() }
                        )
                    },
                    onAnalyzeRoute = { origin, destination, mode, selectedFrom, selectedTo ->
                        activity.onAnalyzeRoute(origin, destination, mode, selectedFrom, selectedTo)
                    },
                    onSelectRoute = { mode -> activity.selectComparedRoute(mode) },
                    onSearchPlaces = { field, query, addressOnly ->
                        activity.onSearchPlaces(field, query, addressOnly)
                    },
                    onApplyGpsOrigin = { activity.onUseCurrentLocationAsOrigin() },
                    gpsOrigin = gpsOrigin,
                    placeSearchUi = placeSearchUi,
                    onMyLocation = { activity.onCurrentLocationRequested() },
                    onRouteFormChanged = { activity.onRouteFormChanged() },
                    routeUiState = routeUiState,
                    onStartGuidance = { activity.onStartGuidanceRequested() },
                    proximityWarning = proximityWarning,
                    navUiState = navUiState,
                    onEndGuidance = { activity.onEndGuidanceRequested() },
                    onReroute = { activity.onRerouteRequested() },
                    onSearchDestination = { destination -> activity.onSearchDestinationDuringGuidance(destination) },
                    onClearRoute = { activity.onRouteFormChanged() },
                    recentRoutes = recentRoutes,
                    onRecentRoute = { index -> activity.onRecentRouteSelected(index) },
                    onRemoveRecentRoute = { index -> activity.onRecentRouteRemoved(index) },
                    onGuideFromMyLocation = { activity.onGuideFromMyLocation() },
                    onPreviewLayout = { heightPx -> activity.onRoutePreviewLayout(heightPx) },
                    onRecenter = { activity.onRecenterRequested() },
                    onSimulateGuidance = { activity.onSimulateGuidanceRequested() },
                    account = accountUi,
                    onKakaoLogin = { activity.onKakaoLoginRequested() },
                    onKakaoLogout = { activity.onKakaoLogoutRequested() },
                )
            val focus = mapFocusRequest
            LaunchedEffect(focus?.id) {
                if (focus != null) activity.showPlaceOnMap(focus.name, focus.latitude, focus.longitude)
            }
            activeRiskPoint?.let { point ->
                HazardDialog(point = point, onDismiss = { activeRiskPoint = null })
            }
            rideFinishedUi?.let { ride ->
                RideFinishedDialog(ride = ride, onDismiss = { rideFinishedUi = null })
            }
            if (safetyRequired) {
                SafetyDialog(
                    onConfirm = {
                        safetyRequired = false
                        activity.onSafetyConfirmed()
                    },
                    onExit = {
                        safetyRequired = false
                        activity.onSafetyExit()
                    }
                )
            }
            } // FollowDeviceFontScale
        }
    }

    @JvmStatic
    fun displayRiskPoint(point: RiskPoint) { activeRiskPoint = point }

    @JvmStatic
    fun showProximityWarning(warning: String?) { proximityWarning = warning }
}

@Composable
private fun HazardDialog(point: RiskPoint, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Soft.Base)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("위험지점 안내", fontSize = 13.sp, color = Soft.Accent)
            Text(point.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Soft.Text)
            Text("위험도: ${point.riskLevel}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                color = if (point.riskLevel == "높음") Color(0xFFDA413E) else Soft.Text)
            Text(point.description, fontSize = 15.sp, color = Soft.TextSub)
            Text("자료: ${point.source} · 과거 사고 이력으로 실시간 위험을 보장하지 않습니다.",
                fontSize = 11.sp, color = Soft.TextHint)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text("확인", modifier = Modifier.clickable(onClick = onDismiss)
                    .semantics { contentDescription = "위험지점 안내 닫기" }.padding(12.dp),
                    fontSize = 15.sp, color = Soft.Accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** 주행 요약 카드: 도착(또는 종료) 직후 거리·시간·평균 속도·지나간 사고 다발 구간 */
@Composable
private fun RideFinishedDialog(ride: RideFinishedUi, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Soft.Base)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                when {
                    ride.simulated -> "시뮬레이션 주행 완료"
                    ride.arrived -> "도착했어요"
                    else -> "주행을 마쳤어요"
                },
                fontSize = 13.sp, color = Soft.Accent, fontWeight = FontWeight.SemiBold,
            )
            if (ride.destination.isNotBlank()) {
                Text(ride.destination, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Soft.Text, maxLines = 2)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(String.format(Locale.KOREA, "%.1f", ride.distanceMeters / 1000.0),
                    fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Soft.Text)
                Spacer(Modifier.width(4.dp))
                Text("km", fontSize = 16.sp, color = Soft.TextSub, modifier = Modifier.padding(bottom = 8.dp))
            }
            val minutes = ride.durationSeconds / 60
            val time = if (minutes >= 60) "${minutes / 60}시간 ${minutes % 60}분" else "${minutes}분"
            val speed = if (ride.durationSeconds >= 60)
                ride.distanceMeters / 1000.0 / (ride.durationSeconds / 3600.0) else 0.0
            Row(Modifier.fillMaxWidth()) {
                SummaryValue("주행 시간", time, Modifier.weight(1f))
                SummaryValue("평균 속도", if (speed > 0) String.format(Locale.KOREA, "%.1f km/h", speed) else "-",
                    Modifier.weight(1f))
            }
            Column(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (ride.hazardZonesPassed > 0) Color(0x1FD93A3A) else Soft.Accent.copy(alpha = 0.12f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(
                    if (ride.hazardZonesPassed > 0) "사고 다발 구간 ${ride.hazardZonesPassed}곳을 주의해서 지났어요"
                    else "이번 주행에서 지난 사고 다발 구간은 없어요",
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    color = if (ride.hazardZonesPassed > 0) Color(0xFFD93A3A) else Soft.Accent,
                )
                if (ride.safeRoute) Text("안전 우선 경로로 주행했어요", fontSize = 12.sp, color = Soft.TextSub)
            }
            Text(
                when {
                    ride.simulated -> "시뮬레이션은 주행 기록에 저장하지 않아요"
                    ride.saved -> "마이페이지 주행 기록에 저장했어요"
                    else -> "주행 기록을 저장하지 못했어요"
                },
                fontSize = 11.sp, color = Soft.TextHint,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text("확인", modifier = Modifier.clickable(onClick = onDismiss)
                    .semantics { contentDescription = "주행 요약 닫기" }.padding(12.dp),
                    fontSize = 15.sp, color = Soft.Accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SummaryValue(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = Soft.TextSub)
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Soft.Text)
    }
}

/** New-design equivalent of the original blocking pre-ride safety alert. */
@Composable
private fun SafetyDialog(onConfirm: () -> Unit, onExit: () -> Unit) {
    Dialog(onDismissRequest = { /* explicit acknowledgment is mandatory */ }) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Soft.Base)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text(stringResource(R.string.safety_title), fontSize = 21.sp,
                fontWeight = FontWeight.Bold, color = Soft.Text)
            Text(stringResource(R.string.safety_message), fontSize = 14.sp, color = Soft.TextSub)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text(stringResource(R.string.safety_exit),
                    modifier = Modifier.clickable(onClick = onExit).padding(10.dp),
                    fontSize = 14.sp, color = Soft.TextSub)
                Text(stringResource(R.string.safety_confirm),
                    modifier = Modifier.clickable(onClick = onConfirm).padding(10.dp),
                    fontSize = 14.sp, color = Soft.Accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}
