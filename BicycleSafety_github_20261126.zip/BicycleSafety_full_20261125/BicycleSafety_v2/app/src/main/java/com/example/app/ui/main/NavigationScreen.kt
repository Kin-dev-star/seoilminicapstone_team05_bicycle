package com.example.app.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app.ui.NavUiState
import com.example.app.ui.RouteUiState
import com.example.app.ui.theme.Soft
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.roundToInt

// 카카오맵·네이버지도 길 안내 화면을 참고한 색
private val NavBlue = Color(0xFF1E6EF5)
private val NavBlueDark = Color(0xFF1557D0)
private val NavRed = Color(0xFFD93A3A)
private val NavAmber = Color(0xFFF2A516)
private val NavCard = RoundedCornerShape(18.dp)

// ───────────────────────── 경로 미리보기 (경로 분석 직후) ─────────────────────────

/**
 * 경로 분석이 끝나면 지도에 전체 경로를 보여주고 아래에 띄우는 요약 카드.
 * 카카오맵의 "실시간 추천 25분 · 7.2km · [안내시작]" 화면과 같은 역할.
 */
@Composable
fun RoutePreviewPanel(
    state: RouteUiState,
    onSelectRoute: (Int) -> Unit,
    onStartGuidance: () -> Unit,
    onEditRoute: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    onGuideFromMyLocation: () -> Unit = {},
    onSimulateGuidance: () -> Unit = {},
) {
    val minutes = ((state.durationSeconds ?: 0) + 59) / 60
    val (distNumber, distUnit) = formatDistance(state.distanceMeters ?: 0)
    Column(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(12.dp)
            .shadow(14.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(Soft.Base)
            .padding(start = 20.dp, end = 12.dp, top = 14.dp, bottom = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                state.modeLabel.ifEmpty { "자전거 경로" },
                color = NavBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Icon(
                Icons.Filled.Close, contentDescription = "경로 지우기", tint = Soft.TextSub,
                modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(8.dp).size(20.dp),
            )
        }
        // 3가지 경로 비교: 각각 거리·시간·사고 이력을 누르면 지도 경로선도 바뀝니다.
        state.choices.forEach { choice ->
            val selected = choice.mode == state.selectedMode
            Column(
                Modifier.fillMaxWidth()
                    .padding(bottom = 5.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selected) Color(0xFFE2EEFF) else Color(0xFFF2F3F5))
                    .clickable(enabled = choice.available) { onSelectRoute(choice.mode) }
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text((if (selected) "✓ " else "") + choice.title,
                        color = if (choice.available) Color(0xFF172B4B) else Color.Gray,
                        fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    Text(if (!choice.available) "검색 실패" else
                        "${choice.distanceMeters / 1000.0f}km · ${(choice.durationSeconds+59)/60}분 · 사고 ${choice.hazardCount}곳",
                        color = Color(0xFF27384A), fontSize = 11.sp)
                }
                if (choice.mode == 0) Text(choice.note, fontSize = 10.sp,
                    color = if (selected) NavBlue else Color.DarkGray)
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$minutes", color = Soft.Text, fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text("분", color = Soft.Text, fontSize = 20.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
            Spacer(Modifier.width(14.dp))
            Text("$distNumber$distUnit", color = Soft.TextSub, fontSize = 18.sp,
                modifier = Modifier.padding(bottom = 6.dp))
        }
        if (state.startName.isNotEmpty() || state.endName.isNotEmpty()) {
            Text(
                "${state.startName} → ${state.endName}",
                color = Soft.TextSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 8.dp),
            )
        }
        val hazards = state.routeHazards
        Text(
            when {
                hazards == null || hazards < 0 -> "사고 데이터 준비 중 · 실제 사고 회피 계산은 적용되지 않았어요"
                hazards == 0 -> "경로 주변 150m 이내 과거 사고다발지역 없음"
                else -> "경로 주변 150m 이내 과거 사고다발지역 ${hazards}곳 · 안전 보장 아님"
            },
            color = if ((hazards ?: 0) > 0) NavRed else Soft.TextHint,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp, end = 8.dp),
        )
        if (!state.fromCurrentLocation) {
            Text(
                "출발지가 현재 위치가 아니에요 · 소요 시간 확인용 경로입니다",
                color = NavBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 6.dp, end = 8.dp),
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.padding(end = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF6B7280))
                    .clickable(onClick = onEditRoute),
                contentAlignment = Alignment.Center,
            ) {
                Text("경로 변경", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            // 출발지가 현재 위치면 바로 안내, 다른 곳이면 같은 목적지로 내 위치에서 다시 찾아 안내
            val fromHere = state.fromCurrentLocation
            Row(
                Modifier
                    .weight(1.6f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NavBlue)
                    .clickable(onClick = if (fromHere) onStartGuidance else onGuideFromMyLocation),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ManeuverArrow("STRAIGHT", Color.White, 22.dp)
                Spacer(Modifier.width(8.dp))
                Text(if (fromHere) "안내 시작" else "내 위치에서 안내",
                    color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
        // 실내 테스트·발표 시연용: 경로를 따라 가짜 GPS로 주행 (디버그 빌드에서만 표시)
        if (com.example.bicyclesafety.BuildConfig.DEBUG) {
            Text(
                "▶ 주행 시뮬레이션 (실내 테스트·시연용, 실제 GPS 아님)",
                color = NavBlue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onSimulateGuidance)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}

// ───────────────────────── 길 안내 화면 ─────────────────────────

/**
 * 안내 시작 후 지도 위에 겹치는 내비게이션 화면 (카카오내비 화면 구성을 참고).
 * 왼쪽 위: 다음 회전 카드(화살표·남은 거리·안내 문구) + 아래 꼬리 탭(그다음 안내)
 * 오른쪽: 진행 막대(빨간 점 = 경로 주변 과거 사고다발지역)
 * 아래: 목적지 검색 동그라미 버튼 → 안내 정보 바(재탐색 · 목적지 · 도착 예정 시각 · 남은 거리 · 종료)
 */
@Composable
fun NavigationOverlay(
    state: NavUiState,
    proximityWarning: String?,
    onEnd: () -> Unit,
    onReroute: () -> Unit,
    onSearchDestination: (String) -> Unit,
    modifier: Modifier = Modifier,
    onRecenter: () -> Unit = {},
) {
    var confirmEnd by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(state.messageId) {
        val message = state.message
        if (message != null) {
            toast = message
            delay(2500)
            toast = null
        }
    }
    BackHandler {
        if (searchOpen) searchOpen = false else confirmEnd = true
    }

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(start = 12.dp, top = 10.dp, end = 72.dp)
        ) {
            val next = if (state.hasFix) state.nextManeuver else null
            TurnCard(state, attachedBelow = next != null)
            if (next != null) NextTurnTab(next, state.nextDistance)
            if (state.simulated) StatusBanner("주행 시뮬레이션 중 · 실제 GPS 아님", NavBlueDark)
            when {
                state.rerouting -> StatusBanner("경로를 다시 찾는 중…", NavAmber)
                state.offRoute -> StatusBanner("경로를 벗어났어요", NavAmber)
            }
            state.hazardAhead?.let { HazardAheadCard(it, state.hazardInside, state.hazardAccidents) }
            proximityWarning?.let { StatusBanner(it, NavRed, warningIcon = true) }
        }

        RouteProgressBar(
            progress = state.progress,
            hazardMarks = state.hazardMarks,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp)
                .width(10.dp)
                .height(300.dp),
        )

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            toast?.let {
                Text(
                    it,
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xE6202226))
                        .padding(horizontal = 22.dp, vertical = 12.dp),
                )
            }
            if (searchOpen) {
                NavigationSearchField(
                    onSearch = { query ->
                        searchOpen = false
                        onSearchDestination(query)
                    },
                    onClose = { searchOpen = false },
                )
                Spacer(Modifier.height(10.dp))
            } else {
                // 안내 정보 바 바로 위 오른쪽: [내 위치(지도를 움직였을 때만)] [목적지 검색] 동그라미 버튼
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End),
                ) {
                    if (!state.following) RecenterButton(onClick = onRecenter)
                    SearchCircleButton(onClick = { searchOpen = true })
                }
            }
            BottomInfoCard(state, onReroute = onReroute, onEnd = { confirmEnd = true })
        }
    }

    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("길 안내를 종료할까요?") },
            confirmButton = {
                TextButton(onClick = { confirmEnd = false; onEnd() }) { Text("종료") }
            },
            dismissButton = {
                TextButton(onClick = { confirmEnd = false }) { Text("계속 안내") }
            },
        )
    }
}

/** 안내 정보 바 위의 작은 동그라미 검색 버튼 */
@Composable
private fun SearchCircleButton(onClick: () -> Unit) {
    Box(
        Modifier
            .size(50.dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(Soft.Base)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "목적지 검색" },
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = NavBlue, modifier = Modifier.size(24.dp))
    }
}

/** 지도를 손으로 움직이면 나타나는 '내 위치로' 동그라미 버튼 */
@Composable
private fun RecenterButton(onClick: () -> Unit) {
    Box(
        Modifier
            .size(50.dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(Soft.Base)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "내 위치로 이동" },
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.MyLocation, contentDescription = null, tint = NavBlue, modifier = Modifier.size(24.dp))
    }
}

/** 동그라미를 누르면 펼쳐지는 목적지 검색창. 검색하면 종료 없이 새 경로 비교 화면으로 이동 */
@Composable
private fun NavigationSearchField(onSearch: (String) -> Unit, onClose: () -> Unit) {
    var destination by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    // 주행 중에는 말로 검색하는 게 안전: 인식되면 바로 검색
    val voice = rememberVoiceSearch("새 목적지를 말씀하세요") { spoken ->
        destination = spoken
        onSearch(spoken)
    }
    LaunchedEffect(Unit) {
        delay(120)
        runCatching { focusRequester.requestFocus() }
    }
    val pill = RoundedCornerShape(25.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .shadow(8.dp, pill)
            .clip(pill)
            .background(Soft.Base)
            .padding(start = 16.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = NavBlue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value = destination,
            onValueChange = { destination = it },
            singleLine = true,
            textStyle = TextStyle(color = Soft.Text, fontSize = 15.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                if (destination.isNotBlank()) onSearch(destination.trim())
            }),
            modifier = Modifier.weight(1f).focusRequester(focusRequester),
            decorationBox = { input ->
                Box {
                    if (destination.isEmpty())
                        Text("새 목적지 검색 (장소·주소)", color = Soft.TextHint, fontSize = 15.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    input()
                }
            },
        )
        if (destination.isBlank()) VoiceSearchButton(voice, tint = NavBlue)
        if (destination.isNotBlank())
            Text(
                "검색", color = NavBlue, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSearch(destination.trim()) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
            )
        Icon(
            Icons.Filled.Close, contentDescription = "검색 닫기", tint = Soft.TextSub,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(8.dp).size(18.dp),
        )
    }
}

/** 왼쪽 위 파란 카드: 큰 회전 화살표 + 남은 거리, 아래 줄에 안내 문구 */
@Composable
private fun TurnCard(state: NavUiState, attachedBelow: Boolean) {
    val shape = if (attachedBelow)
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 0.dp)
    else RoundedCornerShape(16.dp)
    Column(
        Modifier
            .widthIn(min = 170.dp, max = 290.dp)
            .shadow(10.dp, shape)
            .clip(shape)
            .background(NavBlue)
            .padding(start = 14.dp, end = 20.dp, top = 12.dp, bottom = 12.dp)
            .semantics { contentDescription = "다음 안내 ${state.maneuverLabel} ${state.distanceToNext}미터" },
    ) {
        if (!state.hasFix) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ManeuverArrow(state.maneuver, Color.White, 40.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("현재 위치 확인 중…", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("GPS 신호를 기다리고 있어요", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
        } else {
            val (n, u) = formatDistance(state.distanceToNext)
            Row(verticalAlignment = Alignment.CenterVertically) {
                ManeuverArrow(state.maneuver, Color.White, 46.dp)
                Spacer(Modifier.width(10.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(n, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Text(u, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
                }
            }
            val detail = state.instruction.ifBlank { state.maneuverLabel }
            if (detail.isNotBlank()) {
                Text(
                    detail, color = Color.White.copy(alpha = 0.92f), fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 56.dp),
                )
            }
        }
    }
}

/** 회전 카드 아래 짙은 파란 꼬리: 그다음 안내 화살표와 거리 */
@Composable
private fun NextTurnTab(maneuver: String, distance: Int) {
    val shape = RoundedCornerShape(bottomStart = 14.dp, bottomEnd = 14.dp)
    val (n, u) = formatDistance(distance)
    Row(
        Modifier
            .shadow(6.dp, shape)
            .clip(shape)
            .background(NavBlueDark)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ManeuverArrow(maneuver, Color.White, 22.dp)
        Spacer(Modifier.width(6.dp))
        Text("$n$u", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusBanner(text: String, color: Color, warningIcon: Boolean = false) {
    Row(
        Modifier
            .padding(top = 8.dp)
            .widthIn(max = 320.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (warningIcon) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** 앞쪽 사고 다발 구간 위젯: 300m 전부터 50m 단위 거리, 통과 중이면 진한 빨강 */
@Composable
private fun HazardAheadCard(text: String, inside: Boolean, accidents: Int) {
    Row(
        Modifier
            .padding(top = 8.dp)
            .widthIn(max = 320.dp)
            .shadow(8.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(if (inside) Color(0xFFB3261E) else NavRed)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            val sub = if (inside) "속도를 줄이고 주변을 살피세요" else "과거 자전거 사고 ${accidents}건 · 주의 구간"
            Text(sub, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
        }
    }
}

/** 아래 안내 정보 바: 재탐색 · (목적지 / 도착 예정 시각 · 남은 거리) · 종료 */
@Composable
private fun BottomInfoCard(state: NavUiState, onReroute: () -> Unit, onEnd: () -> Unit) {
    val arrival = remember(state.remainingSeconds) {
        SimpleDateFormat("a h:mm", Locale.KOREA).format(Date(System.currentTimeMillis() + state.remainingSeconds * 1000L))
    }
    val (n, u) = formatDistance(state.remainingMeters)
    val bar = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(14.dp, bar)
            .clip(bar)
            .background(Soft.Base)
            .padding(horizontal = 6.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Filled.Refresh, contentDescription = "경로 재탐색", tint = Soft.Text,
            modifier = Modifier.clip(CircleShape).clickable(enabled = !state.rerouting, onClick = onReroute)
                .padding(12.dp).size(24.dp),
        )
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = NavBlue, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(3.dp))
                Text(state.destination.ifEmpty { "목적지" }, color = Soft.TextSub, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(arrival, color = Soft.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(14.dp))
                Text(n, color = Soft.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(u, color = Soft.Text, fontSize = 15.sp, modifier = Modifier.padding(bottom = 3.dp))
            }
        }
        Icon(
            Icons.Filled.Close, contentDescription = "안내 종료", tint = Soft.Text,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onEnd).padding(12.dp).size(24.dp),
        )
    }
}

/**
 * 오른쪽 세로 진행 막대. 아래가 출발, 위가 도착.
 * 파란 부분은 남은 경로, 빨간 점은 경로 주변 과거 사고다발지역.
 */
@Composable
private fun RouteProgressBar(progress: Float, hazardMarks: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = progress.coerceIn(0f, 1f)
        fun y(f: Float) = h * (1f - f)
        drawRoundRect(Color(0xFFD5D8DE), size = Size(w, h), cornerRadius = CornerRadius(w / 2, w / 2))
        drawRoundRect(
            NavBlue,
            topLeft = Offset(0f, 0f),
            size = Size(w, y(p)),
            cornerRadius = CornerRadius(w / 2, w / 2),
        )
        hazardMarks.forEach { f ->
            if (f >= p) {
                drawCircle(Color.White, radius = w * 0.75f, center = Offset(w / 2, y(f)))
                drawCircle(NavRed, radius = w * 0.55f, center = Offset(w / 2, y(f)))
            }
        }
        drawCircle(NavBlue, radius = w * 1.05f, center = Offset(w / 2, y(p)))
        drawCircle(Color.White, radius = w * 0.6f, center = Offset(w / 2, y(p)))
    }
}

// ───────────────────────── 회전 화살표 ─────────────────────────

/** NavigationTracker.Maneuver 이름에 맞는 화살표를 그립니다 (아이콘 파일 없이 직접 그림). */
@Composable
fun ManeuverArrow(maneuver: String, color: Color, size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = Stroke(width = s * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun pt(x: Float, y: Float) = Offset(x * s, y * s)
        fun same(x: Float) = x
        fun mirror(x: Float) = 1f - x
        when (maneuver) {
            "LEFT", "RIGHT" -> {
                val m: (Float) -> Float = if (maneuver == "LEFT") ::same else ::mirror
                val path = Path().apply {
                    moveTo(m(0.62f) * s, 0.95f * s)
                    lineTo(m(0.62f) * s, 0.50f * s)
                    quadraticTo(m(0.62f) * s, 0.32f * s, m(0.44f) * s, 0.32f * s)
                    lineTo(m(0.32f) * s, 0.32f * s)
                }
                drawPath(path, color, style = stroke)
                arrowHead(pt(m(0.08f), 0.32f), if (maneuver == "LEFT") -1f else 1f, 0f, s * 0.24f, color)
            }
            "SLIGHT_LEFT", "SLIGHT_RIGHT" -> {
                val left = maneuver == "SLIGHT_LEFT"
                val m: (Float) -> Float = if (left) ::same else ::mirror
                val path = Path().apply {
                    moveTo(m(0.60f) * s, 0.95f * s)
                    lineTo(m(0.60f) * s, 0.60f * s)
                    lineTo(m(0.36f) * s, 0.33f * s)
                }
                drawPath(path, color, style = stroke)
                arrowHead(pt(m(0.20f), 0.15f), if (left) -0.4f else 0.4f, -0.45f, s * 0.24f, color)
            }
            "UTURN" -> {
                val path = Path().apply {
                    moveTo(0.68f * s, 0.95f * s)
                    lineTo(0.68f * s, 0.42f * s)
                    cubicTo(0.68f * s, 0.12f * s, 0.30f * s, 0.12f * s, 0.30f * s, 0.42f * s)
                    lineTo(0.30f * s, 0.55f * s)
                }
                drawPath(path, color, style = stroke)
                arrowHead(pt(0.30f, 0.80f), 0f, 1f, s * 0.24f, color)
            }
            "ARRIVE" -> {
                drawLine(color, pt(0.30f, 0.92f), pt(0.30f, 0.10f), strokeWidth = s * 0.11f, cap = StrokeCap.Round)
                val flag = Path().apply {
                    moveTo(0.30f * s, 0.12f * s)
                    lineTo(0.80f * s, 0.28f * s)
                    lineTo(0.30f * s, 0.46f * s)
                    close()
                }
                drawPath(flag, color)
            }
            else -> { // STRAIGHT, START
                drawLine(color, pt(0.5f, 0.95f), pt(0.5f, 0.30f), strokeWidth = s * 0.13f, cap = StrokeCap.Round)
                arrowHead(pt(0.5f, 0.06f), 0f, -1f, s * 0.24f, color)
            }
        }
    }
}

/** tip 위치에서 (dx, dy) 방향을 가리키는 채워진 삼각형 화살촉 */
private fun DrawScope.arrowHead(tip: Offset, dx: Float, dy: Float, length: Float, color: Color) {
    val len = hypot(dx, dy).takeIf { it > 0f } ?: 1f
    val ux = dx / len
    val uy = dy / len
    val base = Offset(tip.x - ux * length, tip.y - uy * length)
    val half = length * 0.78f
    val path = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(base.x - uy * half, base.y + ux * half)
        lineTo(base.x + uy * half, base.y - ux * half)
        close()
    }
    drawPath(path, color)
}

/** 거리 표시: 1km 미만은 m(100m 이상은 10m 단위), 이상은 km 소수 한 자리 */
private fun formatDistance(meters: Int): Pair<String, String> = when {
    meters >= 10_000 -> Pair("${(meters / 1000.0).roundToInt()}", "km")
    meters >= 1000 -> Pair(String.format(Locale.KOREA, "%.1f", meters / 1000.0), "km")
    meters >= 100 -> Pair("${(meters / 10.0).roundToInt() * 10}", "m")
    else -> Pair("${meters.coerceAtLeast(0)}", "m")
}
