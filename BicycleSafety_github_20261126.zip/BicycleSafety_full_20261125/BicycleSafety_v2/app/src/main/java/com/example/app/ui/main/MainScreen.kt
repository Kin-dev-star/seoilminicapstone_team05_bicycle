package com.example.app.ui.main

import android.content.Context

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.calculateTargetValue
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import androidx.compose.runtime.structuralEqualityPolicy
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.unit.em
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.foundation.text.BasicText
import com.example.app.ui.theme.FollowDeviceFontScale
import com.example.app.ui.theme.AppFontScale
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app.ui.theme.LocalSoftShadow
import com.example.app.ui.theme.Soft
import com.example.app.ui.NavUiState
import com.example.app.ui.RouteUiState
import com.example.app.ui.GpsOriginSelection
import com.example.app.ui.PlaceSearchUiState
import com.example.app.ui.RecentRouteUi
import com.example.app.ui.AccountUi
import com.example.app.ui.BikeUiBridge
import com.example.bicyclesafety.AppPrefs
import com.example.bicyclesafety.KakaoRouteRepository
import com.example.bicyclesafety.data.AppRepositories
import com.example.bicyclesafety.data.ResultCallback
import com.example.bicyclesafety.data.RideRecord
import com.example.bicyclesafety.data.RideSummary
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import com.example.app.ui.theme.SoftShadow
import com.example.app.ui.theme.softInset
import com.example.app.ui.theme.softPressable
import com.example.app.ui.theme.softPressedInset
import com.example.app.ui.theme.softRaised
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.roundToInt

// ── 오른쪽 아래 원통 메뉴 ──
private val BAR_H = 64.dp                // 막대 높이
private val PEEK = 16.dp                 // 뒤쪽 막대가 앞 막대 위로 보이는 높이
private val DROP = 24.dp                 // 앞 막대가 아래로 말려 들어갈 때 내려가는 거리
private val DRUM_STEP = 60.dp            // 한 칸 넘기는 데 필요한 드래그 거리
private const val VISIBLE_BACK = 2f      // 앞 막대 뒤로 보이는 막대 수
private const val BACK_SHRINK = 0.06f    // 뒤로 한 칸 갈 때마다 줄어드는 비율 (오른쪽 아래 기준)
private const val BACK_SHADE = 0.10f     // 뒤로 한 칸 갈 때마다 어두워지는 정도
private const val DRUM_WIDTH = 0.8f      // 막대 너비 (화면 너비 대비)
private val DRUM_H = BAR_H + PEEK * VISIBLE_BACK + 8.dp   // 원통 메뉴 영역 높이
private val LOC_BTN = 40.dp             // 현재 위치 버튼 크기
private val LIST_GAP = 12.dp            // 모아보기에서 막대 사이 간격
private const val OVERVIEW_STAGGER = 0.08f   // 모아보기로 펼칠 때 막대마다 늦게 출발하는 정도
/** 모아보기로 펼쳤을 때 막대 목록 전체 높이 */
private val LIST_H: Dp get() = BAR_H * NavItem.entries.size + LIST_GAP * (NavItem.entries.size - 1)
private const val DRUM_FRICTION = 2f     // 관성 마찰 (작을수록 멀리 돎)
private const val SNAP_SPEED = 4f        // 이 속도(초당 칸)보다 느려지면 가장 가까운 막대로 빠르게 맞춤
private const val MAX_SPIN = 8f          // 한 번 튕길 때 최대로 도는 칸 수 (두 바퀴)

// ── 경로 설정 창 ──
private val ROW = 44.dp                  // 출발/도착 한 줄 높이
private val DIVIDER = 2.dp               // 출발·도착 사이 구분선 (어두운 선 1dp + 밝은 선 1dp)
private val FIELD_H = ROW * 2 + DIVIDER
private val SHEET_MIN = 250.dp           // 화면이 작아도 1/3 창이 이보다 작아지지 않게
private val SHEET_CORNER = 28.dp

private val EDGE = 20.dp                 // 화면 가장자리 여백
private val CORNER = 18.dp
private val CardShape = RoundedCornerShape(CORNER)
private val FieldShape = RoundedCornerShape(16.dp)
private val WellShape = RoundedCornerShape(12.dp)
private val PillShape = RoundedCornerShape(percent = 50)
private val DividerDark: Color get() = Soft.Dark.copy(alpha = if (Soft.isBlack) 0.9f else 0.45f)

// 테마(밝은/블랙)에 따라 바뀌는 글자 스타일
private val FieldTextStyle: TextStyle get() = TextStyle(color = Soft.Text, fontSize = 14.sp)
private val CursorBrush: SolidColor get() = SolidColor(Soft.Accent)
private const val PRESS_MS = 110         // 눌림(볼록 → 오목) 전환 시간

/** 원통 메뉴에 차례대로 도는 항목 */
enum class NavItem(val title: String, val subtitle: String, val pageTitle: String, val icon: ImageVector) {
    Route("경로 설정", "출발지 · 도착지 설정", "경로 설정", Icons.Filled.LocationOn),
    Account("계정", "마이페이지", "마이페이지", Icons.Filled.Person),
    Report("제보하기", "위험 지점 제보", "제보하기", Icons.Filled.Place),
    Settings("설정", "앱 설정", "설정", Icons.Filled.Settings),
}

/**
 * 메인 화면 (v2): 전체가 지도 영역, 오른쪽 아래에 원통 모양 메뉴.
 * - 막대 하나에 메뉴 하나. 위아래로 밀면 원통이 돌듯 끝없이 넘어감
 * - 경로 설정: 화면 1/3 창이 열리고, 위로 끌어올리면 상세정보
 * - 나머지: 누른 막대가 커지며 화면을 채우고 해당 화면이 나옴
 */
@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    mapContent: @Composable (Modifier) -> Unit = { MapPlaceholder(it) },
    onAnalyzeRoute: (String, String, Int, KakaoRouteRepository.PlaceOption?, KakaoRouteRepository.PlaceOption?) -> Unit = { _,_,_,_,_ -> },
    onSelectRoute: (Int) -> Unit = {},
    onSearchPlaces: (Int, String, Boolean) -> Unit = { _,_,_ -> },
    onApplyGpsOrigin: () -> Unit = {},
    gpsOrigin: GpsOriginSelection? = null,
    placeSearchUi: PlaceSearchUiState = PlaceSearchUiState(),
    onMyLocation: () -> Unit = {},
    onRouteFormChanged: () -> Unit = {},
    routeUiState: RouteUiState = RouteUiState(),
    onStartGuidance: () -> Unit = {},
    proximityWarning: String? = null,
    navUiState: NavUiState = NavUiState(),
    onEndGuidance: () -> Unit = {},
    onReroute: () -> Unit = {},
    onSearchDestination: (String) -> Unit = {},
    onClearRoute: () -> Unit = {},
    recentRoutes: List<RecentRouteUi> = emptyList(),
    onRecentRoute: (Int) -> Unit = {},
    onRemoveRecentRoute: (Int) -> Unit = {},
    onGuideFromMyLocation: () -> Unit = {},
    onPreviewLayout: (Int) -> Unit = {},
    onRecenter: () -> Unit = {},
    onSimulateGuidance: () -> Unit = {},
    account: AccountUi = AccountUi(),
    onKakaoLogin: () -> Unit = {},
    onKakaoLogout: () -> Unit = {},
) {
    val density = LocalDensity.current
    val softShadow = remember(density) { SoftShadow(density, base = BAR_H, corner = CORNER) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    // 위치 계산용 참조 (상태가 아니므로 바뀌어도 재구성되지 않음)
    val rootCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    val statusTop = WindowInsets.statusBars.getTop(density)

    // 계정/제보하기/설정: 막대가 커지며 화면을 채움
    var openPage by remember { mutableStateOf<NavItem?>(null) }
    var pageFrom by remember { mutableStateOf(Rect.Zero) }
    val pageProgress = remember { Animatable(0f) }

    // 설정 값 (휴대폰에 저장, 앱을 다시 켜도 유지. MainActivity가 바뀐 값을 바로 반영)
    val appContext = LocalContext.current
    val settings = remember { AppSettings(appContext) }
    // 위치 버튼은 Java MainActivity의 실제 위치 권한/GPS 요청과 연결합니다.
    // Route form state is hoisted so text survives closing/reopening the menu.
    var routeStart by rememberSaveable { mutableStateOf("") }
    var routeDestination by rememberSaveable { mutableStateOf("") }
    var routeOption by rememberSaveable { mutableIntStateOf(2) }
    var selectedOrigin by remember { mutableStateOf<KakaoRouteRepository.PlaceOption?>(null) }
    var selectedDestination by remember { mutableStateOf<KakaoRouteRepository.PlaceOption?>(null) }
    var activeSearchField by remember { mutableIntStateOf(-1) }
    // 장소·주소 통합 검색으로 바뀌어 항상 false (Java에서 두 검색을 함께 실행)
    val addressOnly = false
    // 출발지: 기본은 현재 위치(GPS). 출발지 칸에 다른 장소를 입력하면 그곳에서의 경로·시간을 볼 수 있음
    var originFromGps by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(gpsOrigin?.version) {
        gpsOrigin?.let { fix ->
            if (originFromGps) {
                selectedOrigin = KakaoRouteRepository.PlaceOption("현재 위치", "GPS", fix.latitude, fix.longitude)
                routeStart = ""
                if (activeSearchField == 0) activeSearchField = -1
                onRouteFormChanged()
            }
        }
    }
    LaunchedEffect(activeSearchField, routeStart, routeDestination, addressOnly) {
        if (activeSearchField in 0..1) {
            delay(350)
            onSearchPlaces(activeSearchField, if (activeSearchField == 0) routeStart else routeDestination, addressOnly)
        }
    }

    // 메뉴 모아보기: 겹쳐진 막대들을 위로 펼쳐서 한 번에 보여줌
    var overview by remember { mutableStateOf(false) }
    val overviewAnim = animateFloatAsState(
        targetValue = if (overview) 1f else 0f,
        animationSpec = tween(if (overview) 420 else 320, easing = FastOutSlowInEasing),
        label = "overview",
    )
    val overviewShown by remember { derivedStateOf { overviewAnim.value > 0f } }
    val drum = remember { DrumHandle() }

    // 경로 설정: 화면 1/3 창, 위로 끌면 상세정보
    var routeOpen by remember { mutableStateOf(false) }
    var routeFrom by remember { mutableStateOf(Rect.Zero) }
    val routeReveal = remember { Animatable(0f) }   // 0 = 막대, 1 = 창
    // 드래그는 즉시 화면에 반영하고, 손을 놓았을 때만 스프링 애니메이션을 사용합니다.
    // Animatable.snapTo()를 매 드래그 이벤트마다 launch하면 위치 갱신이 늦게 적용될 수 있습니다.
    var sheetTop by remember { mutableFloatStateOf(0f) } // 창 윗변 위치(px)
    val sheetAnimation = remember { arrayOfNulls<Job>(1) }
    val screenH = rootSize.height.toFloat()
    val fullTop = statusTop + with(density) { 12.dp.toPx() }
    // 단순 목적지 검색·집/회사 즐겨찾기가 기본 창에서 보이도록 약 60% 높이로 엽니다.
    val thirdTop = (screenH - max(screenH * 0.60f, with(density) { 400.dp.toPx() }))
        .coerceAtLeast(fullTop + with(density) { 40.dp.toPx() })
    val lowestTop = screenH - with(density) { 96.dp.toPx() }

    val selectItem: (NavItem, LayoutCoordinates) -> Unit = { item, bar ->
        val root = rootCoords[0]
        if (root != null && bar.isAttached && openPage == null && !routeOpen) {
            focusManager.clearFocus()
            val rect = root.localBoundingBoxOf(bar)
            if (item == NavItem.Route) {
                routeFrom = rect
                routeOpen = true
                scope.launch {
                    sheetAnimation[0]?.cancel()
                    sheetTop = thirdTop
                    routeReveal.snapTo(0f)
                    routeReveal.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
                }
            } else {
                pageFrom = rect
                openPage = item
                scope.launch {
                    pageProgress.snapTo(0f)
                    pageProgress.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
                }
            }
        }
    }
    // 닫힐 때는 지금 앞에 있는 막대 자리로 줄어듦 (모아보기에서 골랐으면 그 막대가 앞에 와 있음)
    val frontRect: () -> Rect? = {
        val root = rootCoords[0]
        val bar = drum.frontCoords()
        if (root != null && bar != null && bar.isAttached) root.localBoundingBoxOf(bar) else null
    }
    val closePage: () -> Unit = {
        if (openPage != null) {
            frontRect()?.let { pageFrom = it }
            scope.launch {
                pageProgress.animateTo(0f, tween(380, easing = FastOutSlowInEasing))
                openPage = null
            }
        }
    }
    // 제보게시판 '지도에서 보기': 페이지를 닫아 지도가 보이게 함 (지도 이동은 MainActivity.showPlaceOnMap)
    val mapFocusId = BikeUiBridge.mapFocusRequest?.id
    LaunchedEffect(mapFocusId) {
        if (mapFocusId != null) closePage()
    }
    val closeRoute: () -> Unit = {
        if (routeOpen) {
            focusManager.clearFocus()
            frontRect()?.let { routeFrom = it }
            scope.launch {
                routeReveal.animateTo(0f, tween(360, easing = FastOutSlowInEasing))
                routeOpen = false
            }
        }
    }
    val moveSheet: (Float) -> Unit = { target ->
        sheetAnimation[0]?.cancel()
        sheetAnimation[0] = scope.launch {
            animate(
                initialValue = sheetTop,
                targetValue = target,
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 500f),
            ) { value, _ -> sheetTop = value }
        }
    }
    // 터치 중에는 동기적으로 위치를 바꿔서 끌어올리는 동작이 끊기지 않게 합니다.
    val dragSheet: (Float) -> Float = { delta ->
        sheetAnimation[0]?.cancel()
        val before = sheetTop
        sheetTop = (before + delta).coerceIn(fullTop, lowestTop)
        sheetTop - before
    }
    // 손을 뗐을 때: 많이 내리면 닫고, 아니면 1/3 또는 전체 중 가까운 쪽으로
    val settleSheet: (Float) -> Unit = { velocity ->
        val top = sheetTop
        val closeLine = thirdTop + (screenH - thirdTop) * 0.35f
        when {
            top > closeLine || (velocity > 1500f && top > thirdTop - 1f) -> closeRoute()
            velocity < -800f -> moveSheet(fullTop)
            velocity > 800f -> moveSheet(thirdTop)
            else -> moveSheet(if (top < (thirdTop + fullTop) / 2f) fullTop else thirdTop)
        }
    }

    // 모아보기에서 고르면: 고른 막대 자리에서 바로 열리고, 모아보기가 접힌 뒤 그 메뉴가 앞으로 옴
    val pickFromOverview: (NavItem, LayoutCoordinates) -> Unit = { item, bar ->
        selectItem(item, bar)
        overview = false
        drum.bringToFront(item)
    }

    // ── 경로 미리보기 · 길 안내 ──
    val routeReady = routeUiState.distanceMeters != null && !routeUiState.loading && !routeUiState.error
    val navActive = navUiState.active
    val previewCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    // 경로 분석이 끝나면 창을 닫고 지도 위 전체 경로 + 아래 요약 카드를 보여줌 (카카오맵 방식)
    LaunchedEffect(routeReady) {
        if (routeReady && routeOpen) closeRoute()
    }
    // 안내가 시작되면 열린 창·메뉴를 모두 닫고 내비게이션 화면만 남김
    LaunchedEffect(navActive) {
        if (navActive) {
            focusManager.clearFocus()
            overview = false
            routeOpen = false
            routeReveal.snapTo(0f)
            openPage = null
            pageProgress.snapTo(0f)
        }
    }
    // 미리보기 카드의 "경로 변경": 카드 자리에서 경로 설정 창이 열림
    val openRouteFromPreview: () -> Unit = {
        val root = rootCoords[0]
        val panel = previewCoords[0]
        if (root != null && panel != null && panel.isAttached && !routeOpen) {
            routeFrom = root.localBoundingBoxOf(panel)
            routeOpen = true
            scope.launch {
                sheetAnimation[0]?.cancel()
                sheetTop = thirdTop
                routeReveal.snapTo(0f)
                routeReveal.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
            }
        }
    }
    // 경로 입력창을 열면 GPS를 출발지로 자동 지정합니다.
    LaunchedEffect(routeOpen) {
        if (routeOpen && selectedOrigin == null && originFromGps) onApplyGpsOrigin()
    }
    val showPreview = routeReady && !routeOpen && openPage == null && !navActive

    BackHandler(enabled = !navActive && (openPage != null || routeOpen || overview)) {
        when {
            openPage != null -> closePage()
            routeOpen && sheetTop < thirdTop - 1f -> moveSheet(thirdTop)   // 상세정보 보는 중이면 1/3로
            routeOpen -> closeRoute()
            else -> overview = false
        }
    }

    CompositionLocalProvider(LocalSoftShadow provides softShadow) {
        Box(
            modifier
                .fillMaxSize()
                .onPlaced { rootCoords[0] = it }
                .onSizeChanged { rootSize = it }
        ) {
            // Real Kakao MapView from Java MainActivity: map touch/zoom/labels are preserved.
            mapContent(Modifier.fillMaxSize())
            // 모아보기 중에는 뒤를 살짝 어둡게, 빈 곳을 누르면 닫힘
            if (overviewShown) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = overviewAnim.value }
                        .background(Soft.Dark.copy(alpha = if (Soft.isBlack) 0.55f else 0.3f))
                        .pointerInput(Unit) { detectTapGestures { overview = false } }
                )
            }

            if (navActive) {
                // 길 안내 중: 지도 위에 내비게이션 화면만 표시
                // 안내 화면은 글자가 원래 크고 지도를 가리면 안 되므로 글꼴 확대를 1.15배까지만
                FollowDeviceFontScale(max = AppFontScale.NAV_MAX) {
                    NavigationOverlay(
                        state = navUiState,
                        proximityWarning = proximityWarning,
                        onEnd = onEndGuidance,
                        onReroute = onReroute,
                        onSearchDestination = onSearchDestination,
                        onRecenter = onRecenter,
                    )
                }
            } else {
                // GPS 접근 시 화면 경고. 서버 판별이 아닌 과거 사고 지점과의 근접 테스트입니다.
                proximityWarning?.let { warning ->
                    Text(
                        warning,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clip(CardShape)
                            .background(Color(0xFF502626))
                            .padding(12.dp),
                        color = Color.White,
                        fontSize = 13.sp,
                    )
                }

                // 원통 메뉴 오른쪽 위 작은 버튼들: 모아보기 · 현재 위치 (모아보기를 펼치면 목록 위로 같이 올라감)
                val lift = with(density) { (LIST_H - DRUM_H).toPx() }
                if (!showPreview) Row(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .navigationBarsPadding()
                        .padding(end = EDGE, bottom = EDGE + DRUM_H + 12.dp)
                        .graphicsLayer { translationY = -lift * overviewAnim.value },
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OverviewButton(open = overview, onClick = { overview = !overview })
                    MyLocationButton(active = false, onClick = onMyLocation)
                }

                if (!showPreview) NavDrum(
                    overview = { overviewAnim.value },
                    overviewOn = overview,
                    handle = drum,
                    onPick = pickFromOverview,
                    onSelect = selectItem,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .navigationBarsPadding()
                        .padding(end = EDGE, bottom = EDGE)
                        .fillMaxWidth(DRUM_WIDTH),
                )

                if (showPreview) {
                    RoutePreviewPanel(
                        state = routeUiState,
                        onSelectRoute = onSelectRoute,
                        onStartGuidance = onStartGuidance,
                        onGuideFromMyLocation = onGuideFromMyLocation,
                        onSimulateGuidance = onSimulateGuidance,
                        onEditRoute = openRouteFromPreview,
                        onClose = onClearRoute,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .onPlaced { previewCoords[0] = it }
                            // 카드 높이를 지도에 알려 전체 경로가 카드 위쪽에 보이도록 맞춤
                            .onSizeChanged { onPreviewLayout(it.height) },
                    )
                }

                if (routeOpen) {
                    RouteSheet(
                        from = routeFrom,
                        reveal = { routeReveal.value },
                        top = { sheetTop },
                        screenHeightPx = screenH,
                        expand = { ((thirdTop - sheetTop) / (thirdTop - fullTop)).coerceIn(0f, 1f) },
                        onDrag = dragSheet,
                        onDragStopped = settleSheet,
                        onExpand = { moveSheet(fullTop) },
                        onClose = closeRoute,
                        start = routeStart,
                        onStartChange = { text ->
                            routeStart = text
                            selectedOrigin = null
                            originFromGps = text.isBlank()
                            activeSearchField = 0
                            onRouteFormChanged()
                            if (text.isBlank()) onApplyGpsOrigin()
                        },
                        originFromGps = originFromGps,
                        onUseMyLocation = {
                            originFromGps = true
                            routeStart = ""
                            selectedOrigin = null
                            activeSearchField = -1
                            focusManager.clearFocus()
                            onRouteFormChanged()
                            onApplyGpsOrigin()
                        },
                        dest = routeDestination,
                        onDestChange = { routeDestination = it; selectedDestination = null; activeSearchField = 1; onRouteFormChanged() },
                        option = routeOption,
                        onOptionChange = { routeOption = it; onRouteFormChanged() },
                        onApplyGpsOrigin = onApplyGpsOrigin,
                        activeSearchField = activeSearchField,
                        onSearchFocus = { activeSearchField = it },
                        placeSearchUi = placeSearchUi,
                        addressOnly = addressOnly,
                        onAddressModeChange = { activeSearchField = 1 }, // 통합 검색이라 전환 기능 없음
                        onPlaceSelected = { field, place ->
                            if (field == 0) { selectedOrigin = place; routeStart = place.name; originFromGps = false }
                            else { selectedDestination = place; routeDestination = place.name }
                            activeSearchField = -1
                            onRouteFormChanged()
                        },
                        selectedOrigin = selectedOrigin,
                        selectedDestination = selectedDestination,
                        onAnalyzeRoute = onAnalyzeRoute,
                        routeUiState = routeUiState,
                        onStartGuidance = onStartGuidance,
                        recentRoutes = recentRoutes,
                        onRecentRoute = { index ->
                            recentRoutes.getOrNull(index)?.let { item ->
                                focusManager.clearFocus()
                                activeSearchField = -1
                                routeDestination = item.destinationName
                                selectedDestination = null
                                if (item.originIsGps) {
                                    originFromGps = true
                                    routeStart = ""
                                } else {
                                    originFromGps = false
                                    routeStart = item.originName
                                    selectedOrigin = null
                                }
                                onRecentRoute(index)
                            }
                        },
                        onRemoveRecentRoute = onRemoveRecentRoute,
                    )
                }

                openPage?.let { page ->
                    // 커지는 화면의 바깥 그림자: 화면 레이어는 모양대로 잘리므로 그 밖(뒤)에 따로 그림
                    Spacer(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer()
                            .drawBehind {
                                val p = pageProgress.value
                                if (p < 1f) {
                                    val rect = lerp(pageFrom, Rect(Offset.Zero, size), p)
                                    softShadow.drawRaised(this, rect, alpha = (p * 6f).coerceAtMost(1f) * (1f - p))
                                }
                            }
                    )
                    PageOverlay(
                        page = page,
                        settings = settings,
                        from = pageFrom,
                        progress = { pageProgress.value },
                        onBack = closePage,
                        account = account,
                        onKakaoLogin = onKakaoLogin,
                        onKakaoLogout = onKakaoLogout,
                    )
                }
            }
        }
    }
}

// ───────────────────────── 원통 메뉴 ─────────────────────────

private enum class BarRole { Front, Back, Hidden }

/** 원통 메뉴를 바깥(메인 화면)에서 다루기 위한 손잡이 */
private class DrumHandle {
    /** 지금 앞에 있는 막대의 위치 정보 */
    var frontCoords: () -> LayoutCoordinates? = { null }
    /** 고른 메뉴를 앞으로 가져오기 (모아보기가 다 접힌 뒤에) */
    var bringToFront: (NavItem) -> Unit = {}
}

/**
 * 오른쪽 아래 원통 메뉴. 앞 막대 하나에 메뉴 하나, 뒤쪽 막대들은 위로 살짝 겹쳐 보임.
 * 아래로 밀면 뒤(위)의 막대가 앞으로 내려오고, 위로 밀면 앞 막대가 뒤로 넘어감. 끝없이 반복.
 * 성능: 위치·크기·투명도는 레이어 속성으로만 바뀜 (드래그 중 재구성·재배치 없음).
 */
@Composable
private fun NavDrum(
    overview: () -> Float,
    overviewOn: Boolean,
    handle: DrumHandle,
    onPick: (NavItem, LayoutCoordinates) -> Unit,
    onSelect: (NavItem, LayoutCoordinates) -> Unit,
    modifier: Modifier = Modifier,
) {
    val items = NavItem.entries
    val n = items.size
    var savedFront by rememberSaveable { mutableIntStateOf(0) }
    val pos = remember { Animatable(savedFront.toFloat()) }   // 앞에 있는 항목 번호 (소수 = 도는 중)
    val scope = rememberCoroutineScope()
    val stepPx = with(LocalDensity.current) { DRUM_STEP.toPx() }
    val barCoords = remember { arrayOfNulls<LayoutCoordinates>(n) }
    // 손가락 상태 (상태가 아니므로 바뀌어도 재구성되지 않음): [0] 도는 중에 붙잡음, [1] 끄는 중
    val touch = remember { BooleanArray(2) }
    // 속도 1(칸/초)로 놓았을 때 관성으로 더 도는 거리
    val unitTravel = remember { exponentialDecay<Float>().calculateTargetValue(0f, 1f) }

    /** 막대에 딱 맞춰 멈추기 */
    val snapTo: suspend (Float, Float) -> Unit = { target, velocity ->
        pos.animateTo(target, spring(dampingRatio = 0.9f, stiffness = 700f), initialVelocity = velocity)
        savedFront = target.roundToInt()
    }
    /** 손을 놓은 뒤: 관성으로 돌다가 느려지면 가장 가까운 막대에 맞춰 멈춤 */
    val settle: suspend (Float) -> Unit = { speed ->
        val now = pos.value
        val natural = now + speed * unitTravel / DRUM_FRICTION
        val target = round(natural.coerceIn(now - MAX_SPIN, now + MAX_SPIN))
        val dist = target - now
        if (abs(speed) > SNAP_SPEED && dist * speed > 0f) {
            // 목표 막대에 정확히 닿도록 마찰을 맞춰 감속
            pos.animateDecay(
                speed,
                exponentialDecay(frictionMultiplier = speed * unitTravel / dist, absVelocityThreshold = SNAP_SPEED),
            )
        }
        snapTo(target, pos.velocity)
    }

    // 모아보기: 펼치기 전에 막대 위치를 정확히 맞춤
    val overviewShown by remember { derivedStateOf { overview() > 0f } }
    LaunchedEffect(overviewOn) { if (overviewOn) pos.snapTo(round(pos.value)) }
    handle.frontCoords = { barCoords[Math.floorMod(round(pos.value).toInt(), n)] }
    handle.bringToFront = { item ->
        scope.launch {
            snapshotFlow { overview() }.first { it <= 0f }
            val base = round(pos.value)
            var diff = Math.floorMod(item.ordinal - base.toInt(), n)
            if (diff > n / 2) diff -= n
            pos.snapTo(base + diff)
            savedFront = (base + diff).roundToInt()
        }
    }

    // 그리는 순서 (먼 막대부터, 앞 막대가 맨 위): 순서가 바뀔 때만 재구성
    val order by remember {
        derivedStateOf(structuralEqualityPolicy()) {
            if (overview() > 0f) (0 until n).sortedByDescending { drumSlot(it - pos.value, n) }
            else (0 until n).sortedByDescending { abs(drumRel(it - pos.value, n)) }
        }
    }

    Box(
        modifier
            // 모아보기 중에는 펼친 목록 높이만큼 (아래 기준이라 막대 위치는 그대로)
            .height(if (overviewShown) LIST_H else DRUM_H)
            // 도는 중에 손을 대면 가장 가까운 막대에 바로 맞춰 멈춤 (흐릿한 중간 상태로 서 있지 않게).
            // 이때 누른 막대는 열리지 않음
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    touch[0] = pos.isRunning
                    if (touch[0]) scope.launch { snapTo(round(pos.value), 0f) }
                }
            }
            .draggable(
                orientation = Orientation.Vertical,
                enabled = !overviewShown,
                state = rememberDraggableState { delta -> scope.launch { pos.snapTo(pos.value + delta / stepPx) } },
                onDragStarted = { touch[1] = true },
                onDragStopped = { velocity ->
                    touch[0] = false
                    touch[1] = false
                    settle(velocity / stepPx)
                },
            )
            .semantics { contentDescription = "메뉴. 위아래로 밀어서 바꾸기" }
    ) {
        for (k in order) {
            key(items[k]) {
                val role by remember { derivedStateOf { drumRole(drumRel(k - pos.value, n)) } }
                DrumBar(
                    item = items[k],
                    rel = { drumRel(k - pos.value, n) },
                    back = { drumBackRel(k - pos.value, n) },
                    slot = { drumSlot(k - pos.value, n) },
                    spread = { overviewStagger(overview(), drumSlot(k - pos.value, n)) },
                    interactive = overviewShown || role != BarRole.Hidden,
                    onClick = {
                        when {
                            overviewShown -> barCoords[k]?.let { onPick(items[k], it) }   // 모아보기에서 바로 고름
                            touch[0] -> touch[0] = false   // 도는 걸 멈추려고 누른 것: 열지 않음
                            role == BarRole.Front -> barCoords[k]?.let { onSelect(items[k], it) }
                            // 뒤쪽 막대를 누르면 그 막대가 앞으로 오도록 돌림
                            else -> scope.launch { snapTo(round(pos.value + drumRel(k - pos.value, n)), 0f) }
                        }
                    },
                    onPlaced = { barCoords[k] = it },
                    modifier = Modifier.align(Alignment.BottomEnd),
                )
            }
        }
    }
}

/** 막대가 앞 막대 기준 몇 칸 뒤(+, 위)/아래(-)에 있는지. (-1.5, n-1.5] 로 감싸서 끝없이 반복 */
private fun drumRel(x: Float, n: Int): Float {
    var v = (x + 1.5f) % n
    if (v <= 0f) v += n
    return v - 1.5f
}

/** 앞 막대 기준 뒤쪽으로만 센 거리 [0, n): 모아보기로 펼칠 때 출발 위치 계산용 */
private fun drumBackRel(x: Float, n: Int): Float {
    val v = x % n
    return if (v < 0f) v + n else v
}

/** 모아보기 목록에서의 자리 (0 = 맨 아래 앞 막대, 1, 2, 3 = 그 위로 차례로) */
private fun drumSlot(x: Float, n: Int): Int = Math.floorMod(round(x).toInt(), n)

/** 모아보기 진행도를 자리마다 조금씩 늦게 → 아래 막대부터 차례로 펼쳐지고, 접을 땐 위에서부터 */
private fun overviewStagger(progress: Float, slot: Int): Float {
    val span = 1f - OVERVIEW_STAGGER * 3f
    return ((progress - slot * OVERVIEW_STAGGER) / span).coerceIn(0f, 1f)
}

private fun drumRole(d: Float): BarRole = when {
    abs(d) < 0.5f -> BarRole.Front
    d >= 0.5f && d <= VISIBLE_BACK + 0.25f -> BarRole.Back
    else -> BarRole.Hidden
}

/** 뒤로 갈수록 작게(오른쪽 아래 기준), 아래로 말려 들어갈 땐 살짝 작게 */
private fun drumScale(d: Float): Float =
    if (d >= 0f) 1f - BACK_SHRINK * min(d, VISIBLE_BACK + 0.5f) else 1f - 0.05f * min(-d, 1f)

/** 뒤로 갈수록 위로 (앞 막대 위로 PEEK 만큼씩 보이게), 아래로 말려 들어갈 땐 아래로 */
private fun drumOffsetY(d: Float, scale: Float, barH: Float, peek: Float, drop: Float): Float =
    if (d >= 0f) -(peek * min(d, VISIBLE_BACK + 0.5f) + (1f - scale) * barH) else drop * min(-d, 1.5f)

/** 보이는 범위를 벗어나는 막대는 서서히 사라짐 (갑자기 튀지 않게) */
private fun drumAlpha(d: Float): Float = when {
    d > VISIBLE_BACK -> (1f - (d - VISIBLE_BACK) / 0.5f).coerceIn(0f, 1f)
    d >= 0f -> 1f
    else -> (1f + 2f * d).coerceIn(0f, 1f)
}

private fun drumShade(d: Float): Float = if (d > 0f) BACK_SHADE * min(d, VISIBLE_BACK) else 0f

/**
 * 막대 안 글자·아이콘: 앞 자리 근처에서는 바로 또렷하게, 뒤로 넘어가거나 아래로 말려 들어가면 금방 흐려짐
 * (중간에 두 글자가 겹치지 않게)
 */
private fun drumContentAlpha(d: Float): Float =
    if (d > 0f) (1f - (d - 0.1f) * 1.8f).coerceIn(0f, 1f) else (1f + (d + 0.05f) * 3.5f).coerceIn(0f, 1f)

@Composable
private fun DrumBar(
    item: NavItem,
    rel: () -> Float,
    back: () -> Float,
    slot: () -> Int,
    spread: () -> Float,
    interactive: Boolean,
    onClick: () -> Unit,
    onPlaced: (LayoutCoordinates) -> Unit,
    modifier: Modifier = Modifier,
) {
    val softShadow = LocalSoftShadow.current
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    // 원통 위 위치: 모아보기로 펼치는 중이면 뒤쪽 기준 거리로 (숨은 막대는 맨 뒤에서 나오게)
    val depth: () -> Float = { if (spread() > 0f) back() else rel() }
    Box(
        modifier
            .fillMaxWidth()
            .height(BAR_H)
            .graphicsLayer {
                val e = spread()                         // 0 = 원통, 1 = 모아보기 목록
                val d = depth()
                val s0 = drumScale(d)
                val s = mix(s0, 1f, e)
                scaleX = s
                scaleY = s
                translationY = mix(
                    drumOffsetY(d, s0, BAR_H.toPx(), PEEK.toPx(), DROP.toPx()),
                    -slot() * (BAR_H + LIST_GAP).toPx(),
                    e,
                )
                alpha = mix(drumAlpha(d), 1f, e)
                transformOrigin = TransformOrigin(1f, 1f)
                // 투명도를 그리기마다 적용해서 막대 밖으로 퍼진 그림자가 잘리지 않게
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
            .onPlaced(onPlaced)
            .drawBehind { softShadow.drawRaised(this, size.toRect(), alpha = 1f - press.value) }
            .clip(CardShape)
            .background(Soft.Base)
            .softPressedInset(CardShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, enabled = interactive, onClick = onClick),
    ) {
        // 뒤로 넘어가면 글자·아이콘은 흐려져서 깔끔한 띠만 보이게 (레이어 투명도만 바뀜)
        BarContent(item, Modifier.graphicsLayer { alpha = mix(drumContentAlpha(depth()), 1f, spread()) })
        // 뒤로 갈수록 살짝 어둡게 (레이어 투명도만 바뀜)
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer { alpha = drumShade(depth()) * (1f - spread()) }
                .background(Soft.Dark)
        )
    }
}

/** 막대 안쪽: 왼쪽에 이름, 오른쪽 끝 오목한 작은 네모 안에 아이콘 */
@Composable
private fun BarContent(item: NavItem, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxSize()
            .padding(start = 20.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Soft.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(item.subtitle, color = Soft.TextSub, fontSize = 12.sp, maxLines = 1)
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(22.dp))
        }
    }
}

/** 누름 상태(0 = 볼록, 1 = 눌림)를 짧게 애니메이션 */
@Composable
private fun rememberPress(interaction: MutableInteractionSource): State<Float> {
    val pressed by interaction.collectIsPressedAsState()
    return animateFloatAsState(if (pressed) 1f else 0f, tween(PRESS_MS), label = "press")
}

// ───────────────────────── 경로 설정 창 ─────────────────────────

/**
 * 경로 설정 창: 막대에서 커져서 화면 아래 1/3 을 채우고, 위로 끌어올리면 상세정보까지 보임.
 * 성능: 창 크기는 모양(보이는 영역)과 내용 이동으로만 바뀜 → 끄는 동안 재배치 없음.
 */
@Composable
private fun RouteSheet(
    from: Rect,
    reveal: () -> Float,
    top: () -> Float,
    screenHeightPx: Float,
    expand: () -> Float,
    onDrag: (Float) -> Float,
    onDragStopped: (Float) -> Unit,
    onExpand: () -> Unit,
    onClose: () -> Unit,
    start: String,
    onStartChange: (String) -> Unit,
    dest: String,
    onDestChange: (String) -> Unit,
    option: Int,
    onOptionChange: (Int) -> Unit,
    onAnalyzeRoute: (String, String, Int, KakaoRouteRepository.PlaceOption?, KakaoRouteRepository.PlaceOption?) -> Unit,
    onApplyGpsOrigin: () -> Unit,
    activeSearchField: Int,
    onSearchFocus: (Int) -> Unit,
    placeSearchUi: PlaceSearchUiState,
    addressOnly: Boolean,
    onAddressModeChange: (Boolean) -> Unit,
    onPlaceSelected: (Int, KakaoRouteRepository.PlaceOption) -> Unit,
    selectedOrigin: KakaoRouteRepository.PlaceOption?,
    selectedDestination: KakaoRouteRepository.PlaceOption?,
    routeUiState: RouteUiState,
    onStartGuidance: () -> Unit,
    originFromGps: Boolean,
    onUseMyLocation: () -> Unit,
    recentRoutes: List<RecentRouteUi>,
    onRecentRoute: (Int) -> Unit,
    onRemoveRecentRoute: (Int) -> Unit,
) {
    val softShadow = LocalSoftShadow.current
    val density = LocalDensity.current
    val sheetCorner = with(density) { SHEET_CORNER.toPx() }
    val barCorner = with(density) { CORNER.toPx() }
    val barW = with(density) { from.width.toDp() }
    val barH = with(density) { from.height.toDp() }
    // 지금 보이는 창 영역 (막대 → 창으로 커지는 중이면 그 사이). 아래쪽 모서리는 화면 밖으로
    fun visible(size: Size): Rect =
        lerp(from, Rect(0f, top(), size.width, size.height + sheetCorner), reveal())

    // 창 바깥 그림자 (창 레이어는 모양대로 잘리므로 그 밖(뒤)에 따로 그림)
    Spacer(
        Modifier
            .fillMaxSize()
            .graphicsLayer()
            .drawBehind { softShadow.drawLifted(this, visible(size)) }
    )
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                shape = RevealShape(visible(size), mix(barCorner, sheetCorner, reveal()))
                clip = true
            }
            .background(Soft.Base)
            .pointerInput(Unit) { detectTapGestures() } // 창 안의 터치가 뒤의 지도로 넘어가지 않게
            // 내부 스크롤과 바텀시트 열기/닫기는 SheetContent의 nestedScroll에서 조율합니다.
    ) {
        // 처음엔 누른 막대 모양 그대로 보이다가 빠르게 사라짐
        BarContent(
            NavItem.Route,
            Modifier
                .offset { IntOffset(from.left.roundToInt(), from.top.roundToInt()) }
                .size(barW, barH)
                .graphicsLayer { alpha = (1f - reveal() * 4f).coerceIn(0f, 1f) },
        )
        SheetContent(
            expand = expand,
            onExpand = onExpand,
            onDrag = onDrag,
            onDragStopped = onDragStopped,
            onClose = onClose,
            start = start,
            onStartChange = onStartChange,
            dest = dest,
            onDestChange = onDestChange,
            option = option,
            onOptionChange = onOptionChange,
            onAnalyzeRoute = onAnalyzeRoute,
            onApplyGpsOrigin = onApplyGpsOrigin,
            activeSearchField = activeSearchField,
            onSearchFocus = onSearchFocus,
            placeSearchUi = placeSearchUi,
            addressOnly = addressOnly,
            onAddressModeChange = onAddressModeChange,
            onPlaceSelected = onPlaceSelected,
            selectedOrigin = selectedOrigin,
            selectedDestination = selectedDestination,
            routeUiState = routeUiState,
            onStartGuidance = onStartGuidance,
            originFromGps = originFromGps,
            onUseMyLocation = onUseMyLocation,
            recentRoutes = recentRoutes,
            onRecentRoute = onRecentRoute,
            onRemoveRecentRoute = onRemoveRecentRoute,
            modifier = Modifier
                // 실제로 보이는 창의 높이만 사용: 아래 즐겨찾기까지 스크롤이 가능해야 합니다.
                .offset { IntOffset(0, mix(from.top, top(), reveal()).roundToInt()) }
                .height(with(density) {
                    (screenHeightPx - mix(from.top, top(), reveal())).coerceAtLeast(0f).toDp()
                })
                .graphicsLayer {
                    val p = reveal()
                    alpha = ((p - 0.45f) / 0.55f).coerceIn(0f, 1f)
                },
        )
    }
}

@Composable
private fun SheetContent(
    expand: () -> Float,
    onExpand: () -> Unit,
    onDrag: (Float) -> Float,
    onDragStopped: (Float) -> Unit,
    onClose: () -> Unit,
    start: String,
    onStartChange: (String) -> Unit,
    dest: String,
    onDestChange: (String) -> Unit,
    option: Int,
    onOptionChange: (Int) -> Unit,
    onAnalyzeRoute: (String, String, Int, KakaoRouteRepository.PlaceOption?, KakaoRouteRepository.PlaceOption?) -> Unit,
    onApplyGpsOrigin: () -> Unit,
    activeSearchField: Int,
    onSearchFocus: (Int) -> Unit,
    placeSearchUi: PlaceSearchUiState,
    addressOnly: Boolean,
    onAddressModeChange: (Boolean) -> Unit,
    onPlaceSelected: (Int, KakaoRouteRepository.PlaceOption) -> Unit,
    selectedOrigin: KakaoRouteRepository.PlaceOption?,
    selectedDestination: KakaoRouteRepository.PlaceOption?,
    routeUiState: RouteUiState,
    onStartGuidance: () -> Unit,
    originFromGps: Boolean,
    onUseMyLocation: () -> Unit,
    recentRoutes: List<RecentRouteUi>,
    onRecentRoute: (Int) -> Unit,
    onRemoveRecentRoute: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    val dragCallback = rememberUpdatedState(onDrag)
    val stopCallback = rememberUpdatedState(onDragStopped)
    val expandCallback = rememberUpdatedState(expand)
    val sheetWasDragged = remember { booleanArrayOf(false) }
    val sheetScrollConnection = remember {
        object : NestedScrollConnection {
            // 창이 접혀 있을 때 위로 스와이프하면 내부 목록보다 창을 먼저 펼칩니다.
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput || available.y >= 0f || expandCallback.value() >= 0.999f)
                    return Offset.Zero
                val moved = dragCallback.value(available.y)
                if (moved != 0f) sheetWasDragged[0] = true
                return Offset(0f, moved)
            }

            // 상세 내용을 맨 위로 올린 뒤 아래로 스와이프하면 창을 접습니다.
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput || available.y <= 0f) return Offset.Zero
                val moved = dragCallback.value(available.y)
                if (moved != 0f) sheetWasDragged[0] = true
                return Offset(0f, moved)
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!sheetWasDragged[0]) return Velocity.Zero
                sheetWasDragged[0] = false
                stopCallback.value(available.y)
                return Velocity(0f, available.y)
            }
        }
    }
    // 접힌 창에서는 다음 진입 때 출발지/도착지부터 보이게 스크롤을 복귀시킵니다.
    LaunchedEffect(expand() <= 0.001f) {
        if (expand() <= 0.001f) scrollState.scrollTo(0)
    }
    Column(
        modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .nestedScroll(sheetScrollConnection)
            .verticalScroll(scrollState)
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        // 손잡이 드래그 + 본문 스와이프(중첩 스크롤) 모두 창을 움직입니다.
        Box(
            Modifier
                .fillMaxWidth()
                .height(34.dp)
                .draggable(
                    orientation = Orientation.Vertical,
                    state = rememberDraggableState { onDrag(it) },
                    onDragStopped = { onDragStopped(it) },
                )
                .padding(top = 10.dp, bottom = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(40.dp, 5.dp)
                    .clip(PillShape)
                    .background(Soft.Base)
                    .softInset(PillShape, offset = 1.dp, blur = 2.dp)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("경로 설정", color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            SoftIconButton(onClick = onClose, size = 40.dp) {
                Icon(Icons.Filled.Close, contentDescription = "닫기", tint = Soft.TextSub, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(12.dp))

        // ── 출발: 기본은 현재 위치. 다른 출발지를 입력하면 그곳에서의 경로·소요 시간을 확인 ──
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("출발", color = Soft.TextSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(
                if (originFromGps) "✓ 내 위치" else "내 위치로",
                color = Soft.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(PillShape)
                    .clickable(onClick = onUseMyLocation)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
        Column(
            Modifier.fillMaxWidth().height(54.dp).clip(FieldShape)
                .background(Soft.Base).softInset(FieldShape),
            verticalArrangement = Arrangement.Center,
        ) {
            val originHint = when {
                !originFromGps -> "출발지 검색 (장소·주소)"
                selectedOrigin == null -> "현재 위치 확인 중…"
                else -> "현재 위치 (GPS) · 다른 출발지 입력 가능"
            }
            val voiceOrigin = rememberVoiceSearch("출발지를 말씀하세요") { spoken ->
                onExpand(); onSearchFocus(0); onStartChange(spoken)
            }
            RouteField(start, onStartChange, originHint, onFocus = { onExpand(); onSearchFocus(0) },
                trailing = { VoiceSearchButton(voiceOrigin, tint = Soft.TextSub) }) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(Soft.Accent))
            }
        }
        if (activeSearchField == 0) PlaceSuggestions(0, start, placeSearchUi, onPlaceSelected)
        Spacer(Modifier.height(12.dp))
        Text("도착", color = Soft.TextSub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
        Column(
            Modifier.fillMaxWidth().height(54.dp).clip(FieldShape)
                .background(Soft.Base).softInset(FieldShape),
            verticalArrangement = Arrangement.Center,
        ) {
            val voiceDest = rememberVoiceSearch("목적지를 말씀하세요") { spoken ->
                onExpand(); onSearchFocus(1); onDestChange(spoken)
            }
            RouteField(dest, onDestChange, "목적지를 검색하세요", onFocus = { onExpand(); onSearchFocus(1) },
                trailing = { VoiceSearchButton(voiceDest, tint = Soft.Accent) }) {
                Icon(Icons.Filled.LocationOn, contentDescription = null,
                    tint = Soft.Accent, modifier = Modifier.size(18.dp))
            }
        }
        if (activeSearchField == 1) PlaceSuggestions(1, dest, placeSearchUi, onPlaceSelected)
        Text("장소 이름과 주소를 함께 검색해요 · 마이크를 누르면 말로 검색", color = Soft.TextHint, fontSize = 11.sp,
            modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        val originReady = selectedOrigin != null || (!originFromGps && start.isNotBlank())
        Box(
            Modifier.fillMaxWidth().height(52.dp)
                .softRaised(CardShape).clip(CardShape).background(Soft.Base)
                .clickable(enabled = !routeUiState.loading && dest.isNotBlank() && originReady) {
                    // 분석 결과는 별도의 3가지 경로 비교 카드에서 선택합니다.
                    onAnalyzeRoute(start.ifBlank { "현재 위치" }, dest, 2, selectedOrigin, selectedDestination)
                },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                when {
                    routeUiState.loading -> "3가지 경로 검색 중…"
                    !originReady -> if (originFromGps) "GPS 확인 중…" else "출발지를 입력하세요"
                    else -> "경로 찾기"
                },
                fontSize = 16.sp, color = Soft.Accent, fontWeight = FontWeight.SemiBold,
            )
        }
        if (originFromGps && selectedOrigin == null)
            Text("현재 위치를 확인 중입니다. 출발지 칸에 다른 장소를 입력해도 경로를 볼 수 있어요.",
                color = Soft.TextHint, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        if (routeUiState.error)
            Text(routeUiState.message, color = Color(0xFFDC534A), fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp))
        SectionTitle("즐겨찾기")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FavoriteTile(Icons.Filled.Home, "집")
            FavoriteTile(Icons.Filled.Place, "회사")
        }
        SectionTitle("최근 경로")
        if (recentRoutes.isEmpty()) {
            Text("경로를 찾으면 최근 경로가 여기에 저장돼요. (최대 5개)",
                color = Soft.TextHint, fontSize = 12.sp)
        } else {
            recentRoutes.forEachIndexed { index, item ->
                RecentRouteRow(
                    item = item,
                    onClick = { onRecentRoute(index) },
                    onRemove = { onRemoveRecentRoute(index) },
                )
            }
        }
    }
}

/** 출발지/도착지 자동완성 목록 (장소·주소 통합 결과) */
@Composable
private fun PlaceSuggestions(
    field: Int,
    query: String,
    ui: PlaceSearchUiState,
    onPick: (Int, KakaoRouteRepository.PlaceOption) -> Unit,
) {
    if (ui.field != field || ui.query != query.trim()) return
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        ui.items.take(6).forEach { place ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { onPick(field, place) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Text(place.name, color = Soft.Accent, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (place.address.isNotBlank() && place.address != place.name)
                    Text(place.address, color = Soft.TextSub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (ui.status.isNotEmpty())
            Text(ui.status, color = Soft.TextHint, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp))
    }
}

/** 최근 경로 한 줄: 누르면 다시 검색, ✕로 삭제 */
@Composable
private fun RecentRouteRow(item: RecentRouteUi, onClick: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .height(58.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(item.destinationName, color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text((if (item.originIsGps) "현재 위치" else item.originName) + "에서 출발",
                color = Soft.TextSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            Icons.Filled.Close, contentDescription = "최근 경로 삭제", tint = Soft.TextHint,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onRemove).padding(10.dp).size(16.dp),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = Soft.Text,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp,
        modifier = Modifier.padding(top = 26.dp, bottom = 12.dp),
    )
}

/** 선택하면 오목하게 들어가는 옵션 */
@Composable
private fun RowScope.OptionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val press by animateFloatAsState(if (selected) 1f else 0f, tween(160), label = "chip")
    Box(
        Modifier
            .weight(1f)
            .height(40.dp)
            .softPressable(PillShape) { press }
            .clickable(interactionSource = null, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) Soft.Accent else Soft.TextSub,
            fontSize = 12.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
        )
    }
}

@Composable
private fun RowScope.MetricTile(label: String, value: String) {
    Column(
        Modifier
            .weight(1f)
            .height(76.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Soft.TextSub, fontSize = 12.sp)
        Text(value, color = Soft.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RowScope.FavoriteTile(icon: ImageVector, title: String) {
    Row(
        Modifier
            .weight(1f)
            .height(64.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text("등록하기", color = Soft.TextSub, fontSize = 12.sp, maxLines = 1)
        }
    }
}

/** 구분선: 어두운 선 아래 밝은 선을 겹쳐 살짝 파인 홈처럼 보이게 */
@Composable
private fun GrooveDivider(inset: Dp = 16.dp) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = inset)
    ) {
        Spacer(Modifier.fillMaxWidth().height(DIVIDER / 2).background(DividerDark))
        Spacer(Modifier.fillMaxWidth().height(DIVIDER / 2).background(Soft.Light))
    }
}

/** 합친 입력칸 안의 한 줄 (출발 또는 도착). 누르면 창을 끝까지 펼쳐 키보드에 가리지 않게 함 */
@Composable
private fun RouteField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onFocus: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
    leading: @Composable () -> Unit,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = FieldTextStyle,
        cursorBrush = CursorBrush,
        modifier = Modifier
            .fillMaxWidth()
            .height(ROW)
            .onFocusChanged { if (it.isFocused) onFocus() },
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(start = 16.dp, end = if (trailing != null) 6.dp else 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // 아이콘 폭이 달라도 두 줄의 글자 시작 위치가 맞도록 같은 폭 칸 가운데에 둠
                Box(Modifier.width(20.dp), contentAlignment = Alignment.Center) { leading() }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = Soft.TextHint, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    inner()
                }
                if (trailing != null) trailing()
            }
        },
    )
}

// ───────────────────────── 화면 채우기 (계정/임시화면1/설정) ─────────────────────────

/** 누른 막대가 커지면서 화면 전체를 채우고, 그 안에 해당 화면이 나타남 */
@Composable
private fun PageOverlay(
    page: NavItem,
    settings: AppSettings,
    from: Rect,
    progress: () -> Float,
    onBack: () -> Unit,
    account: AccountUi,
    onKakaoLogin: () -> Unit,
    onKakaoLogout: () -> Unit,
) {
    val density = LocalDensity.current
    val barW = with(density) { from.width.toDp() }
    val barH = with(density) { from.height.toDp() }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = progress()
                shape = RevealShape(
                    lerp(from, Rect(0f, 0f, size.width, size.height), p),
                    CORNER.toPx() * (1f - p),
                )
                clip = true
            }
            .background(Soft.Base)
            .pointerInput(Unit) { detectTapGestures() } // 뒤의 지도/메뉴로 터치가 넘어가지 않게
    ) {
        // 처음엔 누른 막대 모양 그대로 보이다가 빠르게 사라짐
        BarContent(
            page,
            Modifier
                .offset { IntOffset(from.left.roundToInt(), from.top.roundToInt()) }
                .size(barW, barH)
                .graphicsLayer { alpha = (1f - progress() * 4f).coerceIn(0f, 1f) },
        )
        PageContent(
            page = page,
            settings = settings,
            onBack = onBack,
            account = account,
            onKakaoLogin = onKakaoLogin,
            onKakaoLogout = onKakaoLogout,
            modifier = Modifier.graphicsLayer { alpha = ((progress() - 0.3f) / 0.7f).coerceIn(0f, 1f) },
        )
    }
}

/** 레이어 안의 [rect] 영역만 보이게 하는 둥근 사각형 모양 */
private class RevealShape(private val rect: Rect, private val radius: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Rounded(RoundRect(rect, CornerRadius(radius)))
}

private fun mix(start: Float, stop: Float, fraction: Float) = start + (stop - start) * fraction

/** 계정(마이페이지)/임시화면1/설정 화면 */
@Composable
private fun PageContent(
    page: NavItem,
    settings: AppSettings,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    account: AccountUi = AccountUi(),
    onKakaoLogin: () -> Unit = {},
    onKakaoLogout: () -> Unit = {},
) {
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = EDGE, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SoftIconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "뒤로", tint = Soft.Text)
            }
            Spacer(Modifier.width(18.dp))
            Text(page.pageTitle, color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        when (page) {
            NavItem.Account -> MyPageBody(account, onKakaoLogin, onKakaoLogout)
            NavItem.Settings -> SettingsBody(settings)
            NavItem.Report -> ReportScreen()   // 제보게시판 (ReportScreen.kt, 김지우)
            else -> PlaceholderBody(page)
        }
    }
}

/** 아직 내용이 없는 화면 */
@Composable
private fun PlaceholderBody(page: NavItem) {
    Column(
        Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(120.dp)
                .softRaised(CircleShape, offset = 8.dp, blur = 16.dp)
                .clip(CircleShape)
                .background(Soft.Base),
            contentAlignment = Alignment.Center,
        ) {
            Icon(page.icon, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(32.dp))
        Text(page.pageTitle, color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            if (page == NavItem.Report) "제보 기능은 준비 중입니다. 현재는 메뉴 화면만 제공됩니다."
            else "${page.pageTitle} 내용이 들어갈 자리예요",
            color = Soft.TextSub,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
    }
}

/** 마이페이지 (임시 내용) */
@Composable
private fun MyPageBody(account: AccountUi, onKakaoLogin: () -> Unit, onKakaoLogout: () -> Unit) {
    PageBody {
        // 프로필 카드: 카카오 로그인 상태 (아래 기록·내 정보 영역은 UI/UX 담당이 data 패키지 저장소로 연결)
        SoftCard {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Soft.Base)
                        .softInset(CircleShape, offset = 3.dp, blur = 5.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (account.loggedIn) account.nickname.ifBlank { "카카오 사용자" } else "로그인이 필요해요",
                        color = Soft.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        when {
                            account.busy -> "카카오 로그인 중…"
                            !account.loggedIn -> "카카오 계정으로 로그인하면 기록이 저장돼요"
                            account.verified -> "카카오 로그인 · 서버 인증됨"
                            else -> "카카오 로그인 · 서버 검증 전"
                        },
                        color = if (account.loggedIn && account.verified) Soft.Accent else Soft.TextSub,
                        fontSize = 13.sp,
                    )
                }
                if (!account.busy) {
                    if (account.loggedIn) SoftTextButton("로그아웃", onKakaoLogout)
                    else SoftTextButton("카카오 로그인", onKakaoLogin)
                }
            }
            if (account.message.isNotBlank()) {
                Text(
                    account.message, color = Soft.TextHint, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                )
            }
        }
        RideRecordsSection()
        SectionHeader("내 정보")
        SoftCard {
            MenuRow("즐겨찾는 장소", "집 · 회사")
            GrooveDivider()
            MenuRow("알림", "켜짐")
        }
    }
}

/**
 * 주행 기록: 길 안내를 마치면 자동 저장되는 실제 기록(AppRepositories.rides)으로 계산.
 * 주간/월간 전환 · 달린 거리 + 지난 기간 같은 시점 대비 · 날짜별 막대 · 횟수/시간/평균 속도 ·
 * 최장/탄 날/CO₂ 절감 · 안전 우선 경로 이용 · 최근 주행 5건
 */
@Composable
private fun RideRecordsSection() {
    val context = LocalContext.current
    var rides by remember { mutableStateOf<List<RideRecord>?>(null) }
    LaunchedEffect(Unit) {
        AppRepositories.rides(context).recent(200, object : ResultCallback<List<RideRecord>> {
            override fun onSuccess(result: List<RideRecord>) { rides = result }
            override fun onError(message: String) { rides = emptyList() }
        })
    }
    var periodIndex by rememberSaveable { mutableIntStateOf(1) } // 0 주간, 1 월간
    val week = periodIndex == 0
    val summary = remember(rides, periodIndex) {
        RideSummary.of(rides ?: emptyList(),
            if (week) RideSummary.Period.WEEK else RideSummary.Period.MONTH, System.currentTimeMillis())
    }
    val prevLabel = if (week) "지난주" else "지난달"

    Row(verticalAlignment = Alignment.Bottom) {
        SectionHeader("주행 기록")
        Spacer(Modifier.weight(1f))
        Box(Modifier.padding(bottom = 8.dp)) {
            SoftSegmented(listOf("주간", "월간"), periodIndex) { periodIndex = it }
        }
    }
    SoftCard {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text(if (week) "이번 주 달린 거리" else "이번 달 달린 거리", color = Soft.TextSub, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(km1(summary.distanceMeters), color = Soft.Text, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(4.dp))
                Text("km", color = Soft.TextSub, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            val change = summary.distanceChangeMeters()
            val (compare, up) = when {
                rides == null -> "기록을 불러오는 중…" to false
                summary.count == 0 && summary.previousDistanceMeters == 0 ->
                    "아직 기록이 없어요 · 경로 안내를 마치면 자동으로 쌓여요" to false
                summary.previousDistanceMeters == 0 -> "$prevLabel 이맘때는 기록이 없었어요" to true
                change >= 0 -> "$prevLabel 이맘때보다 +${km1(change)} km" to true
                else -> "$prevLabel 이맘때보다 -${km1(-change)} km" to false
            }
            Text(compare, color = if (up) Soft.Accent else Soft.TextSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(14.dp))
            DailyBars(summary.dailyKm, summary.todayIndex)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                if (week) {
                    listOf("월", "화", "수", "목", "금", "토", "일").forEachIndexed { i, d ->
                        Text(d, color = if (i == summary.todayIndex) Soft.Accent else Soft.TextHint, fontSize = 11.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                } else {
                    Text("1일", color = Soft.TextHint, fontSize = 11.sp)
                    Spacer(Modifier.weight(1f))
                    Text("15일", color = Soft.TextHint, fontSize = 11.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${summary.dailyKm.size}일", color = Soft.TextHint, fontSize = 11.sp)
                }
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatTile("주행", "${summary.count}", "회")
        val minutes = summary.durationSeconds / 60
        if (minutes >= 60) StatTile("시간", "${minutes / 60}", "시간 ${minutes % 60}분")
        else StatTile("시간", "$minutes", "분")
        val avg = summary.averageSpeedKmh()
        StatTile("평균 속도", if (avg > 0) String.format(Locale.KOREA, "%.1f", avg) else "-", "km/h")
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatTile("최장 거리", km1(summary.longestMeters), "km")
        StatTile("탄 날", "${summary.activeDays}", "일")
        StatTile("CO₂ 절감", String.format(Locale.KOREA, "%.1f", summary.co2SavedKg()), "kg")
    }
    if (summary.count > 0) {
        Spacer(Modifier.height(12.dp))
        SoftCard {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        (if (summary.hazardZonesPassed > 0) "사고 다발 구간 ${summary.hazardZonesPassed}곳 주의 통과 · " else "") +
                            "안전 우선 ${summary.safeRouteCount}회",
                        color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("목적지 도착 ${summary.arrivedCount} / ${summary.count}회 · CO₂는 승용차 대신 탔다고 가정한 추정",
                        color = Soft.TextSub, fontSize = 11.sp)
                }
            }
        }
    }

    SectionHeader("최근 주행")
    SoftCard {
        val recent = rides.orEmpty().take(5)
        if (recent.isEmpty()) {
            Text(
                if (rides == null) "불러오는 중…" else "아직 주행 기록이 없어요. 경로 안내를 마치면 자동으로 저장돼요.",
                color = Soft.TextSub, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
            )
        }
        recent.forEachIndexed { i, r ->
            if (i > 0) GrooveDivider()
            val title = when {
                r.originName.isBlank() -> r.destinationName.ifBlank { "자유 주행" }
                r.destinationName.isBlank() -> r.originName
                else -> "${r.originName} → ${r.destinationName}"
            }
            val min = r.durationSeconds / 60
            val time = if (min >= 60) "${min / 60}시간 ${min % 60}분" else "${min}분"
            val speed = if (r.durationSeconds >= 60) r.distanceMeters / 1000.0 / (r.durationSeconds / 3600.0) else 0.0
            val detail = buildString {
                append(km1(r.distanceMeters)).append(" km · ").append(time)
                if (speed > 0) append(" · ").append(String.format(Locale.KOREA, "%.1f", speed)).append(" km/h")
                if (r.routeMode == 0) append(" · 안전 우선")
                if (!r.arrived) append(" · 중간 종료")
            }
            RideRow(title, detail, SimpleDateFormat("M.d", Locale.KOREA).format(Date(r.startedAt)))
        }
    }
}

private fun km1(meters: Int): String = String.format(Locale.KOREA, "%.1f", meters / 1000.0)

/** 날짜별 거리 막대 (오늘 진하게, 지난 날 연하게, 앞으로 올 날은 점선 높이) */
@Composable
private fun DailyBars(dailyKm: FloatArray, todayIndex: Int) {
    val accent = Soft.Accent
    val hint = Soft.TextHint
    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
        val n = dailyKm.size.coerceAtLeast(1)
        val max = (dailyKm.maxOrNull() ?: 0f).coerceAtLeast(1f)
        val slot = size.width / n
        val barW = (slot * 0.6f).coerceAtMost(18.dp.toPx())
        val minH = 3.dp.toPx()
        for (i in 0 until n) {
            val v = dailyKm[i]
            val h = if (v > 0f) (v / max * size.height).coerceAtLeast(minH) else minH
            val color = when {
                i == todayIndex -> accent
                i > todayIndex -> hint.copy(alpha = 0.2f)
                v > 0f -> accent.copy(alpha = 0.55f)
                else -> hint.copy(alpha = 0.35f)
            }
            drawRoundRect(
                color = color,
                topLeft = Offset(i * slot + (slot - barW) / 2f, size.height - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}

/** 설정 (임시 내용: 값은 화면에서만 바뀜) */
@Composable
private fun SettingsBody(s: AppSettings) {
    PageBody {
        SectionHeader("주행")
        SoftCard {
            SwitchRow("음성 안내", "회전 방향과 사고 다발 구간을 음성으로 알려 줘요", s.voiceGuide) { s.voiceGuide = it }
            GrooveDivider()
            SwitchRow("화면 꺼짐 방지", "길 안내 중 화면을 켜 둬요 · 꺼도 잠금화면 알림과 음성은 계속돼요", s.keepScreenOn) { s.keepScreenOn = it }
        }
        SectionHeader("지도")
        SoftCard {
            SwitchRow("자전거도로 표시", "지도 위에 자전거도로 선을 보여 줘요", s.bikeLanes) { s.bikeLanes = it }
        }
        SectionHeader("일반")
        SoftCard {
            SwitchRow("블랙 테마", "어두운 화면으로 바꿔요", Soft.isBlack) { Soft.isBlack = it }
            GrooveDivider()
            SettingRow("라이딩 모드") { Text("추후 디자인 적용", color = Soft.TextSub, fontSize = 12.sp) }
            GrooveDivider()
            SettingRow("앱 버전") { Text("0.1", color = Soft.TextSub, fontSize = 14.sp) }
        }
    }
}

/** 설정 화면 값: AppPrefs(SharedPreferences)에 저장, MainActivity가 변경을 받아 바로 반영 */
@Stable
class AppSettings(private val context: Context) {
    private var voiceState by mutableStateOf(AppPrefs.voiceGuide(context))
    private var keepScreenState by mutableStateOf(AppPrefs.keepScreenOn(context))
    private var bikeLanesState by mutableStateOf(AppPrefs.bikeLanes(context))

    var voiceGuide: Boolean
        get() = voiceState
        set(value) { voiceState = value; AppPrefs.set(context, AppPrefs.VOICE_GUIDE, value) }
    var keepScreenOn: Boolean
        get() = keepScreenState
        set(value) { keepScreenState = value; AppPrefs.set(context, AppPrefs.KEEP_SCREEN_ON, value) }
    var bikeLanes: Boolean
        get() = bikeLanesState
        set(value) { bikeLanesState = value; AppPrefs.set(context, AppPrefs.BIKE_LANES, value) }
}

/** 페이지 본문: 세로 스크롤 */
@Composable
private fun PageBody(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = EDGE)
            .padding(top = 12.dp, bottom = 32.dp),
        content = content,
    )
}

/** 볼록한 카드 */
@Composable
private fun SoftCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(vertical = 4.dp),
        content = content,
    )
}

@Composable
private fun SectionHeader(text: String, tag: String? = null) {
    Row(
        Modifier.padding(start = 4.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
        if (tag != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                tag,
                color = Soft.TextHint,
                fontSize = 11.sp,
                modifier = Modifier
                    .border(1.dp, Soft.TextHint.copy(alpha = 0.6f), PillShape)
                    .padding(horizontal = 8.dp, vertical = 1.dp),
            )
        }
    }
}

@Composable
private fun RowScope.StatTile(label: String, value: String, unit: String) {
    Column(
        Modifier
            .weight(1f)
            .heightIn(min = 80.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Soft.TextSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        // 값+단위를 한 줄로: 칸이 좁거나 기기 글꼴이 크면 글자를 자동으로 줄여 칸 안에 맞춤
        BasicText(
            text = buildAnnotatedString {
                append(value)
                if (unit.isNotEmpty()) {
                    withStyle(SpanStyle(fontSize = 0.6.em, color = Soft.TextSub, fontWeight = FontWeight.Normal)) {
                        append(" $unit")
                    }
                }
            },
            style = TextStyle(color = Soft.Text, fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            autoSize = TextAutoSize.StepBased(minFontSize = 11.sp, maxFontSize = 20.sp),
        )
    }
}

@Composable
private fun RideRow(title: String, detail: String, date: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Place, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Soft.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Soft.TextSub, fontSize = 12.sp)
        }
        Text(date, color = Soft.TextHint, fontSize = 12.sp)
    }
}

@Composable
private fun MenuRow(title: String, value: String?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(interactionSource = null, indication = null) {}
            .padding(horizontal = 18.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Soft.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = Soft.TextSub, fontSize = 13.sp)
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = Soft.TextHint,
            modifier = Modifier.size(20.dp),
        )
    }
}

/** 줄 전체를 눌러도 켜고 끌 수 있는 스위치 줄 */
@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                interactionSource = null,
                indication = null,
                role = Role.Switch,
                onValueChange = onChange,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Soft.Text, fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, color = Soft.TextSub, fontSize = 12.sp)
        }
        SoftSwitch(checked)
    }
}

@Composable
private fun SettingRow(title: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Soft.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        trailing()
    }
}

/** 소프트 UI 스위치: 오목한 길 위로 볼록한 손잡이. 켜지면 길이 파란색 */
@Composable
private fun SoftSwitch(checked: Boolean) {
    val t by animateFloatAsState(if (checked) 1f else 0f, tween(180), label = "switch")
    Box(
        Modifier
            .size(50.dp, 28.dp)
            .clip(PillShape)
            .drawBehind { drawRect(lerpColor(Soft.Base, Soft.Accent, t)) }
            .softInset(PillShape, offset = 2.dp, blur = 3.dp)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .offset { IntOffset((22.dp.toPx() * t).roundToInt(), 0) }
                .size(20.dp)
                .softRaised(CircleShape, offset = 1.5.dp, blur = 3.dp)
                .clip(CircleShape)
                .drawBehind { drawRect(lerpColor(Soft.Base, Color.White, t)) }
        )
    }
}

/** 소프트 UI 선택 버튼 묶음: 고른 쪽이 볼록하게 */
@Composable
private fun SoftSegmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .height(34.dp)
            .clip(PillShape)
            .background(Soft.Base)
            .softInset(PillShape, offset = 2.dp, blur = 3.dp)
            .padding(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(48.dp)
                    .then(if (sel) Modifier.softRaised(PillShape, offset = 1.5.dp, blur = 3.dp).clip(PillShape).background(Soft.Base) else Modifier)
                    .clickable(interactionSource = null, indication = null) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (sel) Soft.Accent else Soft.TextSub,
                    fontSize = 13.sp,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

/** 작은 글자 버튼 (누르면 오목하게) */
@Composable
private fun SoftTextButton(text: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        Modifier
            .height(36.dp)
            .softPressable(PillShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Soft.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ───────────────────────── 현재 위치 ─────────────────────────

/** 메뉴 모아보기 버튼: 겹쳐진 막대들을 한 번에 펼쳐서 보여줌. 펼친 동안은 닫기(X) */
@Composable
private fun OverviewButton(open: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val color = if (open) Soft.Accent else Soft.TextSub
    Box(
        modifier
            .size(LOC_BTN)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics { contentDescription = if (open) "모아보기 닫기" else "메뉴 모아보기" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(22.dp)) {
            val sw = 2.dp.toPx()
            if (open) {
                val m = 6.dp.toPx()
                drawLine(color, Offset(m, m), Offset(size.width - m, size.height - m), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(size.width - m, m), Offset(m, size.height - m), sw, cap = StrokeCap.Round)
            } else {
                // 겹쳐진 막대 3개 (오른쪽 정렬, 위로 갈수록 짧게 = 원통 메뉴 모양)
                val right = size.width - 3.dp.toPx()
                drawLine(color, Offset(right - 15.dp.toPx(), 16.dp.toPx()), Offset(right, 16.dp.toPx()), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(right - 12.dp.toPx(), 11.dp.toPx()), Offset(right, 11.dp.toPx()), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(right - 9.dp.toPx(), 6.dp.toPx()), Offset(right, 6.dp.toPx()), sw, cap = StrokeCap.Round)
            }
        }
    }
}

/** 현재 위치 버튼 (작은 볼록 동그라미). 내 위치를 보여주는 중이면 아이콘이 파란색 */
@Composable
private fun MyLocationButton(active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val color = if (active) Soft.Accent else Soft.TextSub
    Box(
        modifier
            .size(LOC_BTN)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics { contentDescription = "현재 위치" },
        contentAlignment = Alignment.Center,
    ) {
        // 조준선 모양 아이콘
        Canvas(Modifier.size(22.dp)) {
            val c = center
            val sw = 2.dp.toPx()
            drawCircle(color, radius = 6.dp.toPx(), center = c, style = Stroke(sw))
            drawCircle(color, radius = 2.5.dp.toPx(), center = c)
            val r1 = 8.dp.toPx()
            val r2 = 10.dp.toPx()
            drawLine(color, Offset(c.x, c.y - r2), Offset(c.x, c.y - r1), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x, c.y + r1), Offset(c.x, c.y + r2), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x - r2, c.y), Offset(c.x - r1, c.y), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x + r1, c.y), Offset(c.x + r2, c.y), sw, cap = StrokeCap.Round)
        }
    }
}

/** 지도 위 내 위치 점 (지도 붙이기 전 임시: 화면 가운데). 버튼을 누를 때마다 고리가 퍼짐 */
@Composable
private fun MyLocationMarker(pulse: () -> Float, modifier: Modifier = Modifier) {
    Canvas(modifier.graphicsLayer()) {
        val c = Offset(size.width * 0.5f, size.height * 0.42f)
        val p = pulse()
        drawCircle(Soft.Accent.copy(alpha = 0.10f), radius = 34.dp.toPx(), center = c)
        if (p < 1f) {
            drawCircle(Soft.Accent.copy(alpha = 0.30f * (1f - p)), radius = 12.dp.toPx() + 46.dp.toPx() * p, center = c)
        }
        drawCircle(Soft.Dark.copy(alpha = 0.35f), radius = 11.dp.toPx(), center = c + Offset(1.dp.toPx(), 2.dp.toPx()))
        drawCircle(Color.White, radius = 10.dp.toPx(), center = c)
        drawCircle(Soft.Accent, radius = 7.dp.toPx(), center = c)
    }
}

/** 소프트 UI 동그란 아이콘 버튼 (누르면 오목하게 들어감) */
@Composable
private fun SoftIconButton(onClick: () -> Unit, size: Dp = 44.dp, content: @Composable () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        Modifier
            .size(size)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

// ───────────────────────── 지도 자리 ─────────────────────────

/** 지도 표시 영역 (실제 지도 SDK 붙이기 전 임시 배경) */
@Composable
private fun MapPlaceholder(modifier: Modifier = Modifier) {
    Box(modifier) {
        // 별도 레이어에 한 번만 그려 둠 → 메뉴 애니메이션 중에도 지도는 다시 그리지 않음
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer()
        ) {
            val w = size.width
            val h = size.height
            drawRect(Soft.Base)
            val step = 44.dp.toPx()
            val thin = 1.dp.toPx()
            var x = step
            while (x < w) {
                drawLine(Soft.MapGrid, Offset(x, 0f), Offset(x, h), thin)
                x += step
            }
            var y = step
            while (y < h) {
                drawLine(Soft.MapGrid, Offset(0f, y), Offset(w, y), thin)
                y += step
            }
            drawRoundRect(
                Soft.MapPark,
                topLeft = Offset(w * 0.56f, h * 0.36f),
                size = Size(w * 0.30f, h * 0.13f),
                cornerRadius = CornerRadius(18.dp.toPx()),
            )
            val road = 9.dp.toPx()
            drawLine(Soft.MapRoad, Offset(-road, h * 0.30f), Offset(w + road, h * 0.23f), road)
            drawLine(Soft.MapRoad, Offset(w * 0.40f, -road), Offset(w * 0.50f, h + road), road)
            drawLine(Soft.MapRoad, Offset(-road, h * 0.64f), Offset(w + road, h * 0.52f), road * 0.7f)
        }
        Text(
            "지도 표시 영역 (임시)",
            color = Soft.TextHint,
            fontSize = 13.sp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 20.dp),
        )
    }
}
