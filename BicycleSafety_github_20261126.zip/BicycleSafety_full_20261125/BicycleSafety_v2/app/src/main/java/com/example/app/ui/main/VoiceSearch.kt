package com.example.app.ui.main

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * 음성 검색 (2026-11-26)
 *
 * 휴대폰의 음성 인식 화면(RecognizerIntent)을 띄워 말한 내용을 글자로 받아 검색창에 넣습니다.
 * - 마이크 권한(RECORD_AUDIO)은 음성 인식 앱이 직접 처리하므로 우리 앱 권한 추가 없음
 * - 음성 인식 앱이 없는 기기는 안내 문구만 띄움
 *
 * 쓰는 곳: 경로 설정의 출발·도착 칸, 안내 중 목적지 검색창, 제보 위치 검색칸
 */

/** 음성 인식을 시작하는 함수를 돌려줍니다. 인식된 문장이 있으면 onResult(문장) */
@Composable
fun rememberVoiceSearch(prompt: String, onResult: (String) -> Unit): () -> Unit {
    val context = LocalContext.current
    val latest by rememberUpdatedState(onResult)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val text = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
        if (!text.isNullOrBlank()) latest(text)
    }
    return remember(launcher, prompt) {
        {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            try {
                launcher.launch(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, "이 기기에서는 음성 검색을 쓸 수 없어요 (음성 인식 앱 필요)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/** 검색칸 오른쪽에 넣는 마이크 버튼 (기본 터치 영역 40dp, 칸이 낮으면 boxSize로 줄임) */
@Composable
fun VoiceSearchButton(
    onClick: () -> Unit,
    tint: Color,
    modifier: Modifier = Modifier,
    iconSize: Dp = 20.dp,
    boxSize: Dp = 40.dp,
) {
    Box(
        modifier
            .size(boxSize)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Mic, contentDescription = "음성으로 검색", tint = tint, modifier = Modifier.size(iconSize))
    }
}
