# 팀 통합 가이드: 마이페이지 · 제보게시판 · 서버 API (2026-11-25)

마이페이지(UI/UX 담당)와 제보게시판(자료조사·발표 담당) 화면은 **`com.example.bicyclesafety.data` 패키지의 저장소(Repository)만 사용**하면 됩니다.
저장소가 휴대폰 저장(로컬)과 서버 저장을 알아서 바꿔 주므로, 화면 코드는 서버가 준비되든 안 되든 똑같이 동작합니다.

## 1. 파일 구조

```text
app/src/main/java/com/example/bicyclesafety/data/
  ResultCallback.java          결과 콜백 (onSuccess / onError, 항상 메인 스레드)
  UserSession.java             로그인 사용자 (카카오 회원번호, 닉네임, 서버 세션, 서버 검증 여부)
  SessionStore.java            로그인 세션 저장/불러오기
  FavoritePlace.java           즐겨찾기 (HOME / WORK / OTHER)
  RideRecord.java, RideStats.java   주행 기록, 이번 주·이번 달 통계
  HazardReport.java            제보 글
  FavoriteRepository.java      ┐
  RideRecordRepository.java    ├ 화면이 쓰는 인터페이스
  ReportRepository.java        ┘
  Local*Repository.java        휴대폰 저장 구현 (지금 기본값)
  Server*Repository.java       서버 API 구현 (아래 4장 규격)
  ApiClient.java               서버 HTTP JSON 호출 (TEAM_API_BASE_URL + Bearer 세션)
  AppRepositories.java         ★ 저장소를 얻는 유일한 입구
  JsonCodec.java               모델 ↔ JSON 변환 (로컬·서버 같은 필드 이름)
```

## 2. 화면에서 쓰는 방법 (복사해서 쓰면 됨)

Kotlin(Compose) 화면에서:

```kotlin
val context = LocalContext.current
var favorites by remember { mutableStateOf<List<FavoritePlace>>(emptyList()) }
LaunchedEffect(Unit) {
    AppRepositories.favorites(context).list(object : ResultCallback<List<FavoritePlace>> {
        override fun onSuccess(result: List<FavoritePlace>) { favorites = result }
        override fun onError(message: String) { /* 안내 문구 표시 */ }
    })
}
```

| 화면 | 쓸 메서드 |
|---|---|
| 마이페이지 즐겨찾기 등록·수정 | `AppRepositories.favorites(context).save(FavoritePlace("", FavoritePlace.TYPE_HOME, "집", 장소명, 주소, 위도, 경도), callback)` (HOME/WORK는 하나만 유지) |
| 즐겨찾기 삭제 | `.delete(id, callback)` |
| 최근 주행 기록 | `AppRepositories.rides(context).recent(10, callback)` |
| 이번 주·이번 달 통계 | (마이페이지에 이미 연결됨: `RideSummary.of(기록목록, Period.WEEK/MONTH, 지금)`) / 단순 합계는 `.statsSince(RideStats.startOfThisWeek(), callback)` |
| 제보 목록 | `AppRepositories.reports(context).list(page, 20, callback)` |
| 제보 상세 | `.get(id, callback)` |
| 제보 글쓰기 | `.create(HazardReport("", 제목, 내용, 장소명, 위도, 경도, "", 0), callback)` |
| 로그인 사용자 | `SessionStore.load(context)` (null이면 로그인 안 함) |

- **주행 기록은 앱이 자동 저장**합니다. 길 안내가 끝나면 `MainActivity.finishRide()`가 실제 이동 거리·시간·출발/도착지·지나간 사고 다발 구간 수를 저장하고 주행 요약 카드를 띄움 (1분 미만이면서 100m 미만은 저장 안 함). 마이페이지는 조회만 하면 됩니다.
- 장소 검색(제보 위치·즐겨찾기 주소)은 `KakaoRouteRepository.searchPlacesCombined(BuildConfig.KAKAO_REST_API_KEY, 검색어)` 를 **백그라운드 스레드에서** 호출하면 장소·주소 통합 결과를 받습니다.
- 화면 위치: 마이페이지는 `MainScreen.kt`의 `MyPageBody()`. 위쪽 로그인 카드와 `RideRecordsSection()`(주간/월간 주행 기록·최근 주행)은 **연결 완료**, '내 정보'의 즐겨찾는 장소 줄이 아직 빈 자리입니다 (즐겨찾기 화면은 새 파일 `FavoriteScreen.kt` 권장). 제보게시판은 `ReportScreen.kt`·`ReportSupport.kt`(김지우)로 **연결 완료** (2026-11-26).

## 3. 통합 규칙
0. 검색칸을 새로 만들면 `VoiceSearch.kt`의 `rememberVoiceSearch()` + `VoiceSearchButton()`으로 음성 검색을 붙여 주세요. 글자 크기는 sp를 쓰고, 좁은 칸은 `maxLines = 1` + 말줄임을 넣어 주세요 (앱은 기기 글꼴 1.3배까지 반영).
1. **`data` 패키지 인터페이스와 모델 필드 이름은 바꾸지 마세요.** 필요한 필드가 있으면 단톡방에 먼저 공유 → 서버 규격도 같이 수정.
2. 새 화면은 새 파일(`ReportScreen.kt`, `MyPageScreen.kt` 등)에 만들고, `MainScreen.kt`에는 연결 한 줄만 추가.
3. `MainActivity.java`, `BikeUiBridge.kt`는 내비게이션·지도 공통 코드라 수정 전에 공유.
4. `local.properties`(키), 서버 `server.properties`(DB 비밀번호·앱 ID)는 공유 금지.

## 4. 서버 API 규격 (백엔드 담당)

모든 응답은 JSON, 성공 `{"ok":true,...}`, 실패 `{"ok":false,"error":"설명"}`.
로그인이 필요한 API는 헤더 `Authorization: Bearer {sessionToken}` 로 사용자 구분 (서버 `auth.requireUser(request)`).

### 이미 구현됨 (MainServer, `README_SERVER_KAKAO_AUTH.md`)
| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| POST | `/api/auth/kakao` | `{"accessToken":"..."}` | `{"ok":true,"kakaoId":123,"nickname":"홍길동","sessionToken":"64자리","expiresAt":1767225600000}` |
| GET | `/api/me` | Bearer | `{"ok":true,"kakaoId":123,"nickname":"홍길동"}` |
| POST | `/api/auth/logout` | Bearer | `{"ok":true}` |
| GET | `/api/hazards` | - | `{"ok":true,"count":2079,"items":[{"id":"161307","name":"...","latitude":37.57,"longitude":126.98,"accidentCount":4,"casualtyCount":4}]}` |

### 백엔드 담당이 만들 API (앱 `Server*Repository`가 이 형식으로 호출)
| 메서드 | 경로 | 요청 본문 | 응답 |
|---|---|---|---|
| GET | `/api/favorites` | - (Bearer) | `{"ok":true,"items":[즐겨찾기]}` |
| POST | `/api/favorites` | 즐겨찾기 (id가 ""이면 새로 추가, HOME/WORK는 사용자당 1개로 덮어쓰기) | `{"ok":true,"item":즐겨찾기}` |
| DELETE | `/api/favorites/{id}` | - (Bearer) | `{"ok":true}` |
| GET | `/api/rides?limit=10` | - (Bearer) | `{"ok":true,"items":[주행기록 최신순]}` |
| POST | `/api/rides` | 주행기록 | `{"ok":true,"item":주행기록}` |
| GET | `/api/reports?page=0&size=20` | - (로그인 불필요) | `{"ok":true,"items":[제보 최신순]}` |
| GET | `/api/reports/{id}` | - | `{"ok":true,"item":제보}` |
| POST | `/api/reports` | 제보 (authorNickname·createdAt은 서버가 채움) | `{"ok":true,"item":제보}` |

JSON 필드 (앱 `JsonCodec.java`와 동일):
- 즐겨찾기: `id, type(HOME|WORK|OTHER), label, placeName, address, latitude, longitude`
- 주행기록: `id, startedAt(ms), endedAt(ms), distanceMeters, durationSeconds, originName, destinationName, routeMode(0 안전/1 최단/2 자전거도로), arrived, hazardZonesPassed(지나간 사고 다발 구간 수, 없으면 0)`
- 제보: `id, title, content, placeName, latitude, longitude, authorNickname, createdAt(ms)`

서버 API가 준비되면 앱 `AppRepositories.java` 의 `USE_SERVER_FOR_FAVORITES / RIDES / REPORTS` 를 `true` 로 바꾸면 됩니다.
그 전까지는 로그인해도 휴대폰 저장소를 사용합니다 (제보는 내 휴대폰에서 쓴 글만 보임).
