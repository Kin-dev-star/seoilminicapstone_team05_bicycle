"""2026-11-26: 음성 검색 · 기기 글꼴 · 화면 회전 · 제보게시판 통합 정적 검사."""
import pathlib
root = pathlib.Path(__file__).resolve().parents[1]
ui = root / 'app/src/main/java/com/example/app/ui'
main = (ui / 'main/MainScreen.kt').read_text(encoding='utf-8')
nav = (ui / 'main/NavigationScreen.kt').read_text(encoding='utf-8')
voice = (ui / 'main/VoiceSearch.kt').read_text(encoding='utf-8')
report = (ui / 'main/ReportScreen.kt').read_text(encoding='utf-8')
support = (ui / 'main/ReportSupport.kt').read_text(encoding='utf-8')
bridge = (ui / 'BikeUiBridge.kt').read_text(encoding='utf-8')
font = (ui / 'theme/AppFontScale.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
checks = {
    '음성 인식 인텐트': 'RecognizerIntent.ACTION_RECOGNIZE_SPEECH' in voice and '"ko-KR"' in voice,
    '음성 인식 앱 없을 때 처리': 'ActivityNotFoundException' in voice,
    '경로 설정 출발·도착 음성': main.count('rememberVoiceSearch(') == 2 and 'trailing = { VoiceSearchButton(voiceDest' in main,
    '안내 중 검색 음성(바로 검색)': 'rememberVoiceSearch("새 목적지를 말씀하세요")' in nav and 'onSearch(spoken)' in nav,
    '제보 위치 음성': 'rememberVoiceSearch("제보할 장소를 말씀하세요")' in report,
    '글꼴 범위 제한': 'const val MAX = 1.3f' in font and 'const val NAV_MAX = 1.15f' in font,
    '앱 전체 적용(대화상자 포함)': 'FollowDeviceFontScale {' in bridge and '} // FollowDeviceFontScale' in bridge,
    '안내 화면 1.15배': 'FollowDeviceFontScale(max = AppFontScale.NAV_MAX)' in main,
    '통계 칸 자동 축소': 'TextAutoSize.StepBased(minFontSize = 11.sp, maxFontSize = 20.sp)' in main,
    '세로 고정': 'android:screenOrientation="portrait"' in manifest,
    '회전·글꼴 변경 시 재생성 안 함': 'orientation|screenSize' in manifest and 'fontScale' in manifest,
    '제보게시판 연결': 'NavItem.Report -> ReportScreen()' in main,
    '제보 파일': 'fun ReportScreen()' in report and 'fun reverseGeocode(' in support,
}
for name, ok in checks.items():
    if not ok:
        raise AssertionError('FAIL: ' + name)
print(f'PASS: {len(checks)} voice/font/rotation/report checks')
