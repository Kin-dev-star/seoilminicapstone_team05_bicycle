"""제보 '지도에서 보기' → 우리 앱 지도 표시 정적 검사."""
import pathlib
root = pathlib.Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/bicyclesafety/MainActivity.java').read_text(encoding='utf-8')
bridge = (root / 'app/src/main/java/com/example/app/ui/BikeUiBridge.kt').read_text(encoding='utf-8')
screen = (root / 'app/src/main/java/com/example/app/ui/main/MainScreen.kt').read_text(encoding='utf-8')
report = (root / 'app/src/main/java/com/example/app/ui/main/ReportScreen.kt').read_text(encoding='utf-8')
checks = {
    '제보 화면 버튼 연결': 'BikeUiBridge.showOnMap(r.placeName' in report,
    '요청 상태': 'var mapFocusRequest by mutableStateOf<MapFocusRequest?>(null)' in bridge,
    '지도 이동 호출': 'activity.showPlaceOnMap(focus.name, focus.latitude, focus.longitude)' in bridge,
    '페이지 닫기': 'if (mapFocusId != null) closePage()' in screen,
    '전용 마커층(사고 마커 갱신에 안 지워짐)': 'LabelLayerOptions.from(PLACE_FOCUS_LAYER)' in main,
    '실패 시 카카오맵 링크': 'https://map.kakao.com/link/map/' in main and 'if (!shown)' in main,
    '첫 GPS 위치로 되돌아가지 않음': 'centerOnNextLocation = false; // 첫 GPS 위치로' in main,
    '새 경로 시 마커 지움': 'clearPlaceFocus();' in main,
}
for name, ok in checks.items():
    if not ok:
        raise AssertionError('FAIL: ' + name)
print(f'PASS: {len(checks)} report-on-map checks')
