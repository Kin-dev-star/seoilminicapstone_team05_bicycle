package com.example.bicyclesafety;

import java.util.ArrayList;
import java.util.List;

/** 검색 결과 순서(서울 우선·이름 일치·지하철역) 테스트. 네트워크 없이 정렬 함수만 검사 */
public class TestSearchRanking {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else { fail++; System.out.println("FAIL " + n); } }
    static KakaoRouteRepository.Candidate c(String name, String addr, String cat, int order) {
        return new KakaoRouteRepository.Candidate(new KakaoRouteRepository.PlaceOption(name, addr, 37.6, 127.0), cat, order);
    }
    static List<String> names(List<KakaoRouteRepository.PlaceOption> list) {
        List<String> out = new ArrayList<>();
        for (KakaoRouteRepository.PlaceOption p : list) out.add(p.name);
        return out;
    }

    public static void main(String[] a) {
        // "노원": 카카오가 다른 지역/구청을 먼저 줘도 노원역이 맨 위, 서울이 아닌 곳은 뒤로
        List<KakaoRouteRepository.Candidate> nowon = new ArrayList<>();
        nowon.add(c("노원구청", "서울 노원구 노해로 437", "PO3", 0));
        nowon.add(c("노원식당", "경기 의정부시 어딘가 1", "FD6", 1));
        nowon.add(c("노원역 4호선", "서울 노원구 상계로 지하 1", "SW8", 2));
        nowon.add(c("롯데백화점 노원점", "서울 노원구 동일로 1414", "MT1", 3));
        nowon.add(c("노원역 7호선", "서울 노원구 동일로 지하 1400", "SW8", 4));
        List<String> r = names(KakaoRouteRepository.rankForSeoul(nowon, "노원"));
        check("station first", r.get(0).equals("노원역 4호선") && r.get(1).equals("노원역 7호선"));
        check("then prefix in Seoul", r.get(2).equals("노원구청"));
        check("then other Seoul", r.get(3).equals("롯데백화점 노원점"));
        check("non-Seoul last", r.get(4).equals("노원식당"));
        check("nothing dropped", r.size() == 5);

        // 같은 점수면 카카오 순서 유지
        List<KakaoRouteRepository.Candidate> tie = new ArrayList<>();
        tie.add(c("스타벅스 A점", "서울 중구 1", "CE7", 0));
        tie.add(c("스타벅스 B점", "서울 종로구 2", "CE7", 1));
        tie.add(c("스타벅스 C점", "서울 마포구 3", "CE7", 2));
        r = names(KakaoRouteRepository.rankForSeoul(tie, "스타벅스"));
        check("stable kakao order", r.get(0).endsWith("A점") && r.get(1).endsWith("B점") && r.get(2).endsWith("C점"));

        // 서울: 서울역 맨 위, 서울이 아닌 '서울대공원'(과천)은 뒤
        List<KakaoRouteRepository.Candidate> seoul = new ArrayList<>();
        seoul.add(c("서울대공원", "경기 과천시 대공원광장로 102", "AT4", 0));
        seoul.add(c("서울숲", "서울 성동구 뚝섬로 273", "AT4", 1));
        seoul.add(c("서울역 1호선", "서울 중구 세종대로 지하 2", "SW8", 2));
        r = names(KakaoRouteRepository.rankForSeoul(seoul, "서울"));
        check("seoul station first", r.get(0).equals("서울역 1호선"));
        check("gwacheon last", r.get(2).equals("서울대공원"));

        // 띄어쓰기 무시, 정확히 같은 이름 우선
        List<KakaoRouteRepository.Candidate> exact = new ArrayList<>();
        exact.add(c("롯데월드 어드벤처", "서울 송파구 올림픽로 240", "AT4", 0));
        exact.add(c("롯데 월드", "서울 송파구 올림픽로 300", "AT4", 1));
        r = names(KakaoRouteRepository.rankForSeoul(exact, "롯데월드"));
        check("exact ignoring spaces", r.get(0).equals("롯데 월드"));

        // 주소 결과(분류 없음)도 서울 우선
        List<KakaoRouteRepository.Candidate> addr = new ArrayList<>();
        addr.add(c("부산 해운대구 동백로 1", "부산 해운대구 동백로 1", "", 0));
        addr.add(c("서울 노원구 동일로 1414", "서울 노원구 동일로 1414", "", 1));
        r = names(KakaoRouteRepository.rankForSeoul(addr, "동일로"));
        check("address Seoul first", r.get(0).startsWith("서울"));

        check("empty safe", KakaoRouteRepository.rankForSeoul(new ArrayList<>(), "노원").isEmpty());
        check("null query safe", KakaoRouteRepository.rankForSeoul(seoul, null).size() == 3);

        // 주소 먼저 보여 줄 입력
        check("addr: number+road", KakaoRouteRepository.looksLikeAddress("동일로 1414"));
        check("addr: gu", KakaoRouteRepository.looksLikeAddress("노원구"));
        check("addr: dong", KakaoRouteRepository.looksLikeAddress("상계동"));
        check("addr: gu dong", KakaoRouteRepository.looksLikeAddress("노원구 상계동"));
        check("addr: seoul gu", KakaoRouteRepository.looksLikeAddress("서울 노원구"));
        check("place: 노원", !KakaoRouteRepository.looksLikeAddress("노원"));
        check("place: 서울", !KakaoRouteRepository.looksLikeAddress("서울"));
        check("place: 노원롯데백화점", !KakaoRouteRepository.looksLikeAddress("노원롯데백화점"));
        check("place: 서울역", !KakaoRouteRepository.looksLikeAddress("서울역"));
        check("place: 한강공원", !KakaoRouteRepository.looksLikeAddress("여의도 한강공원"));
        check("null", !KakaoRouteRepository.looksLikeAddress(null));

        System.out.println("PASS: " + pass + " search ranking checks" + (fail > 0 ? ", FAIL " + fail : ""));
        if (fail > 0) System.exit(1);
    }
}
