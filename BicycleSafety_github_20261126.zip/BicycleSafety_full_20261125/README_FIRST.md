# BicycleSafety 전체 수정본 (2026-11-26, 제보게시판 통합·지도 표시·음성 검색·기기 글꼴·화면 회전·검색 순서)

| 폴더 | 내용 |
|---|---|
| `BicycleSafety_v2/` | Android 앱 (Android Studio로 열기). 변경: `CHANGES_20261125_background_safety_login.md`, `CHANGES_20261125_lockscreen_simulation.md`, **`CHANGES_20261125_hazard_ahead_safe_route.md` (이번 변경)** |
| `eclipse-project/` | 팀 서버 (MainServer). Eclipse 없이 `MainServer/run_server.bat` 더블클릭으로 실행 가능. 변경: `MainServer/README_SERVER_KAKAO_AUTH.md` |

- 팀원 통합 방법(마이페이지·제보게시판 데이터, 서버 API 규격): `BicycleSafety_v2/docs/TEAM_INTEGRATION_GUIDE.md`
- 서버 `bin/` 폴더(이전 컴파일 결과)는 뺐습니다. Eclipse가 자동으로 다시 만듭니다.
- 비밀 값은 각자 파일에만: 앱 `local.properties`(카카오 키·서버 주소), 서버 `server.properties`(DB 비밀번호·카카오 앱 ID)

## 기존에 쓰던 폴더에 덮어쓸 때
- 앱: `local.properties`(키·`TEAM_API_BASE_URL`)는 새 폴더에 다시 복사
- 서버: `server.properties`는 새 `MainServer` 폴더에 다시 복사
