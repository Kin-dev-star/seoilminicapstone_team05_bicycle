# 자전거 앱 화면 — 다른 프로젝트에 넣기

## 들어 있는 것
| 파일 | 내용 |
|---|---|
| `ui/AppState.kt` | 화면에 보이는 값과 연결 지점을 한곳에 모은 것 (아래 '화면 값 넣기') |
| `ui/BikeApp.kt` | 로딩화면 → 메인 화면 전체 흐름, 테마 · 설정 저장 |
| `ui/loading/BikeLoadingScreen.kt` | 자전거 로딩 애니메이션 |
| `ui/main/MainScreen.kt` | 지도 영역, 원통 메뉴, 모아보기, 현재 위치 버튼, 경로 설정 창, 마이페이지, 설정 |
| `ui/main/AppSettings.kt` | 설정 값 (저장 · 불러오기) |
| `ui/data/ProfileState.kt` | 마이페이지 값: 이번 달 기록, 최근 주행, 즐겨찾는 장소, 주행 목표 |
| `ui/data/Units.kt` | 거리 단위 (km / mi) 와 거리 · 시간 글자 |
| `ui/data/DemoData.kt` | 마이페이지 데모 값 |
| `ui/account/AccountState.kt` | 로그인 상태: 사용자 정보, 카카오 로그인 · 로그아웃 연결 |
| `ui/account/LoginScreen.kt` | 로그인 화면 (마이페이지 '로그인' 버튼으로 열림, 카카오 로그인 버튼) |
| `ui/guide/GuideState.kt` | 길안내 화면 값: 내 위치(핀), 다음·그다음 안내, 남은 거리 · 시간, 경로선, 알림, 읽을 문장, 방향 종류 |
| `ui/guide/Navigation.kt` | 길안내 모듈 연결 (`GuideNavigator`: 안내 시작 · GPS 위치 · 재탐색 · 종료 → 화면 값, 경로 → 모듈 경로) |
| `ui/guide/RouteGuide.kt` | 경로 모양에서 꺾이는 곳 찾기 (모듈에 줄 안내 지점), 모듈 없이 쓸 때 다음 안내 계산 |
| `ui/guide/RouteSearch.kt` | 경로 검색 결과 · 옵션 · 안내 지점, 지도 위 대여소 · 사고다발지역 |
| `ui/guide/GuideViews.kt` | 내 위치 핀, 위쪽 길안내 배너, 오른쪽 위 작은 칸, 알림 한 줄 |
| `ui/guide/VoiceGuide.kt` | 음성 안내 (폰 기본 음성) |
| `ui/guide/NavIcons.kt` | 핀 · 좌회전 · 우회전 · 직진 · 유턴 아이콘 |
| `ui/guide/TempMap.kt` | 임시 지도 그림 (경로선 · 대여소 · 사고다발지역) · 좌표 변환 · 데모 경로 · 데모 대여소 · 데모 사고다발지역 · 데모 주행 (지도 SDK · GPS 붙이기 전) |
| `com/example/bicyclesafety/navigation/` | 길안내 모듈 (bike-navigation-core 그대로. `KakaoRouteAdapter.java` 는 BicycleSafety 의 `KakaoRouteRepository` 가 있어야 해서 뺌) |
| `ui/theme/Soft.kt` | 소프트 UI 색·그림자 (밝은 테마 / 블랙 테마) |
| `res/values/bike_colors.xml` | (선택) 앱 켤 때 깜빡임 방지용 파란색 |

## 1. 파일 복사
이 폴더의 `app` 폴더를 프로젝트 폴더에 그대로 덮어 넣으면 같은 경로로 들어가요.
패키지 이름(`com.example.app.ui`)은 그대로 둬도 동작해요.
길안내 모듈(`com/example/bicyclesafety/navigation`)이 이미 들어 있는 프로젝트면 그 폴더는 덮어써도 같은 파일이에요 (받은 그대로).
바꾸고 싶으면 Android Studio에서 `ui` 패키지를 우클릭 → **Refactor → Move** 로 옮기면 import 까지 같이 바뀌어요.

## 2. `app/build.gradle.kts`
```kotlin
plugins {
    id("org.jetbrains.kotlin.plugin.compose")   // Kotlin 2.0 이상 (루트 build.gradle.kts 에도 같은 버전으로 등록)
}

android {
    defaultConfig { minSdk = 23 }               // 23 이상
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.12.01"))   // 2025.08 이상 필요 (그림자 기능)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.10.1")           // 1.10 이상 필요
}
```

## 3. Activity 에서 쓰기
```kotlin
class MainActivity : ComponentActivity() {
    // 화면에 보이는 값과 연결 지점: 여기 값만 바꾸면 화면이 따라 바뀜
    private val app = AppState(
        account = AccountState(kakaoLogin = ::loginWithKakao, logout = ::logoutKakao),
        searchRoute = ::searchRoute,
        searchPlaces = ::searchPlaces,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // (임시) 데모 값. 실제 데이터를 넣기 시작하면 지우기
        TempMap.fillDemo(app.guide)
        DemoData.fillProfile(app.profile)
        app.map.rentalStations = TempMap.demoStations()
        app.map.hazards = TempMap.demoHazards()                       // 사고다발지역
        TempMap.demoDrive(lifecycleScope, app.navigator, app.guide)   // 데모 주행 ('안내 시작'하면 내 위치가 경로를 따라 움직임)
        setContent { BikeApp(app) }
    }

    override fun onDestroy() {
        app.navigator.stop()
        super.onDestroy()
    }

    // GPS 위치가 올 때마다 (위치 콜백에서, 1초 간격 권장). GPS 를 붙이면 위의 fillDemo · demoDrive 는 지우기
    private fun onGps(location: Location) = app.navigator.onLocation(
        location.latitude, location.longitude,
        if (location.hasAccuracy()) location.accuracy else -1f,
        if (location.hasSpeed()) location.speed else -1f,
        location.time,
    )

    // 장소 검색 API 로 찾아서 돌려주기 (경로 설정 자동완성). 지금은 서울 주요 장소 데모
    private suspend fun searchPlaces(query: String): List<Place> = DemoData.searchPlaces(query)

    // 경로 API 로 찾아서 돌려주기 (from 이 null 이면 내 위치에서. 길안내 중 재탐색에도 불림). 지금은 데모 경로
    private suspend fun searchRoute(from: String?, to: String, option: RouteOption): RoutePlan =
        TempMap.demoSearch(from, to, option, here = app.guide.myLocation)

    // 카카오 SDK 로 로그인하고 사용자 정보를 돌려주기 (실패·취소면 예외 → 로그인 화면에 메시지)
    private suspend fun loginWithKakao(): UserProfile = throw IllegalStateException("카카오 로그인 연결 전이에요")
    private suspend fun logoutKakao() {}    // 카카오 SDK 로그아웃
}
```

### 화면 값 넣기
| 화면 | 넣는 곳 |
|---|---|
| 길안내 (위쪽 배너 · 작은 칸 · 경로선 · 알림 · 음성) | 길안내 모듈이 계산 (아래 '길안내 모듈'). '안내 시작'은 경로 설정 창에서, GPS 위치는 `app.navigator.onLocation(위도, 경도, 오차, 속도, 시각)` |
| 내 위치 핀 | `app.navigator.onLocation(...)` 하면 그 자리로 부드럽게 이동 |
| 마이페이지 | `app.profile.monthly` · `recentRides` · `favorites` · `weeklyGoalKm`, 알림은 `app.settings.notifications` |
| 로그인 | `loginWithKakao()` · `logoutKakao()`, 편집 버튼은 `AccountState(editProfile = …)` |
| 경로 설정 장소 후보 | `searchPlaces()` → `Place(이름, 주소, 위치)` 목록. 입력칸 아래에 후보로 나옴 (최근 장소는 `app.profile.recentPlaces`) |
| 경로 설정 창 | `searchRoute()` → `RoutePlan(경로 좌표, 거리, 시간, 안내 지점)`. 도착지를 정하면 불림, '안내 시작'을 누르면 그 경로로 길안내 시작, 길안내 중 경로를 벗어나면 재탐색에도 불림 |
| 지도 위 대여소 · 사고다발지역 | `app.map.rentalStations`, `app.map.hazards` |
| 설정 | `app.settings` (바꾸면 자동 저장. 음성 안내 · 화면 꺼짐 방지 · 자전거도로 · 대여소 · 거리 단위는 바로 적용, 자동 일시정지 · 알림은 값만 저장) |

- 실제 로딩 작업 넣기: `BikeApp(app, loadInitialData = { /* 지도 초기화 등 */ })`
- 메인 화면만 쓰기: `setContent { MaterialTheme { MainScreen(state = app) } }`
- 블랙 테마: `Soft.isBlack = true` (설정 화면의 블랙 테마 스위치와 같고, 바꾸면 자동 저장)
- 실제 지도를 붙일 때: `MainScreen.kt` 의 `TempMapView` 자리에 지도 화면을 넣고, `MyLocationPin` 의 `toScreen` 을
  지도 SDK 의 좌표 변환으로 바꾸기 (예: 네이버 `naverMap.projection.toScreenLocation`).
  경로선(`app.guide.routeLine`)은 SDK 의 선(polyline), 대여소 · 사고다발지역은 SDK 마커로
- 모듈 없이 화면 값만 직접 넣기: `app.guide.startRoute(경로 좌표)`, `app.guide.next = Maneuver(Turn.Left, 150)`

## 길안내 모듈 (bike-navigation-core)
`ui/guide/Navigation.kt` 의 `GuideNavigator` (`app.navigator`) 가 모듈(`NavigationSession`)을 화면에 연결해요.
1. 경로 설정 창 '안내 시작' → `app.navigator.start(경로, 도착지, 옵션)` → 모듈 `start`
2. GPS 위치 → `app.navigator.onLocation(...)` → 다음 안내 · 그다음 안내 · 남은 거리 · 시간이 배너 (또는 작은 칸) 에
3. 경로 이탈 (40m 넘게 3번 연속) → 알림 + `searchRoute(null, 같은 도착지, 같은 옵션)` 로 재탐색 → 새 경로선
4. 사고다발지역 (`app.map.hazards`) 150m 안 → 빨간 알림 + 음성
5. 목적지 25m 안 → "목적지에 도착했어요" 알림 뒤 끝. 경로 설정 창 위쪽 '길안내 중' 카드에서 '다시 찾기' · '안내 종료'

- 방향: `LEFT` · `SLIGHT_LEFT` → 좌회전, `RIGHT` · `SLIGHT_RIGHT` → 우회전, `UTURN` → 유턴, 나머지 → 직진 화살표
- 음성: 모듈 문장을 폰 기본 음성으로 (설정 → 음성 안내로 켜고 끔). 알림은 `app.guide.notice`, 진행률 · 속도 등은 `app.navigator.state`
- 안내 지점: `RoutePlan.steps` 에 카카오 길찾기 step 의 `guidance` · 좌표를 넣으면 그 문구로 안내 (비우면 경로 모양에서 꺾이는 곳을 찾음).
  모듈의 `KakaoBicycleRouteClient.route(...)` 결과는 `.toRoutePlan()` 으로 `searchRoute()` 에서 돌려주면 됨 (REST 키는 `local.properties` → `BuildConfig`)
- 기준 값: `AppState(navOptions = NavigationSession.Options().apply { offRouteMeters = 50.0 })`

## 카카오 로그인
마이페이지 '로그인' → 로그인 화면 → '카카오 로그인' 버튼이 `account.kakaoLogin` (위의 `loginWithKakao`) 을 불러요.
1. [카카오 개발자](https://developers.kakao.com) → 내 애플리케이션 → 앱 추가 → **네이티브 앱 키** 확인
2. 앱 설정 → 플랫폼 → Android 에 패키지명(내 앱의 applicationId)과 **키 해시** 등록 (키 해시는 SDK 의 `Utility.getKeyHash(this)` 로 확인),
   카카오 로그인 활성화, 동의항목(닉네임·이메일) 설정
3. `settings.gradle.kts` 의 repositories 에 `maven("https://devrepo.kakao.com/nexus/content/groups/public/")`
4. `app/build.gradle.kts` 에 `implementation("com.kakao.sdk:v2-user:<최신 버전>")` (버전은 카카오 개발자 문서 참고)
5. 앱 시작할 때 `KakaoSdk.init(this, "네이티브 앱 키")` (Application 또는 MainActivity 의 onCreate)
6. `AndroidManifest.xml` 의 `<application>` 안에 카카오계정 로그인용 화면 추가
   ```xml
   <activity android:name="com.kakao.sdk.auth.AuthCodeHandlerActivity" android:exported="true">
       <intent-filter>
           <action android:name="android.intent.action.VIEW" />
           <category android:name="android.intent.category.DEFAULT" />
           <category android:name="android.intent.category.BROWSABLE" />
           <data android:host="oauth" android:scheme="kakao네이티브앱키" />
       </intent-filter>
   </activity>
   ```
7. `loginWithKakao()` 안에서 `UserApiClient.instance.loginWithKakaoTalk` (카카오톡 없으면 `loginWithKakaoAccount`) 로 로그인한 뒤
   `UserApiClient.instance.me` 로 받은 닉네임·이메일을 `UserProfile(이름, 이메일)` 로 돌려주기, `logoutKakao()` 는 `UserApiClient.instance.logout`

## 4. (선택) 켤 때 흰 화면 깜빡임 막기
앱 테마(`res/values/themes.xml`)에 한 줄 추가:
```xml
<item name="android:windowBackground">@color/bike_blue</item>
```

## 참고
- 지금 들어 있는 경로 · 위치 · 기록 · 대여소 · 사고다발지역 · 경로 검색 결과 · 주행은 데모 값이에요 (지도 SDK · GPS · 서버 연결 전).
- 확인한 환경: AGP 8.13.2 · Kotlin 2.3.21 · Compose BOM 2025.12.01 · activity-compose 1.10.1 · compileSdk 36
