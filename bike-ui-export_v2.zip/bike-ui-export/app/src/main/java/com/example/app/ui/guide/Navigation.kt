package com.example.app.ui.guide

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.app.ui.data.DistanceUnit
import com.example.app.ui.data.formatDistance
import com.example.bicyclesafety.navigation.NavRoute
import com.example.bicyclesafety.navigation.NavigationSession
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlinx.coroutines.runBlocking
import com.example.bicyclesafety.navigation.Maneuver as NavManeuver

// 길안내 모듈 (bike-navigation-core, 패키지 com.example.bicyclesafety.navigation) 을 이 화면에 연결하는 곳.
// 모듈 코드는 그대로 두고, 여기서 경로를 모듈 모양으로 바꾸고 모듈이 알려 주는 안내를 GuideState 에 넣음.

private const val FLASH_MS = 3_500L      // 잠깐 보여 주는 알림 (새 경로, 재탐색 실패)
private const val ARRIVED_MS = 5_000L    // 도착 알림

/** 길안내 모듈 방향 → 화살표 (왼쪽 · 오른쪽 방향은 좌회전 · 우회전 화살표, 출발 · 도착은 직진) */
fun NavManeuver.toTurn(): Turn = when (this) {
    NavManeuver.LEFT, NavManeuver.SLIGHT_LEFT -> Turn.Left
    NavManeuver.RIGHT, NavManeuver.SLIGHT_RIGHT -> Turn.Right
    NavManeuver.UTURN -> Turn.UTurn
    else -> Turn.Straight
}

/**
 * 경로 검색 결과 → 길안내 모듈 경로.
 * 안내 지점([RoutePlan.steps])이 없으면 경로 모양에서 꺾이는 곳을 찾아 만듦 ([stepsFromShape]).
 * @param destination 도착지 이름 (재탐색할 때 같은 도착지로)
 * @param bicycleFirst 자전거도로 우선이면 true (재탐색할 때 같은 옵션으로)
 */
fun RoutePlan.toNavRoute(destination: String, bicycleFirst: Boolean): NavRoute {
    val end = points.last()
    return NavRoute(
        points.map { NavRoute.Point(it.latitude, it.longitude) },
        steps.ifEmpty { stepsFromShape(points) }.map { NavRoute.Step(it.guidance, it.location.latitude, it.location.longitude) },
        distanceMeters,
        minutes * 60,
        destination,
        end.latitude,
        end.longitude,
        bicycleFirst,
    )
}

/** 경로 모양으로 안내 지점 만들기: 출발지 → 꺾이는 곳마다 "좌회전" · "우회전" · "유턴" → 목적지 */
fun stepsFromShape(points: List<GeoPoint>): List<RouteStep> {
    val shape = RouteGuide(points)
    return buildList {
        add(RouteStep("출발지", points.first()))
        shape.turns.forEach { add(RouteStep(it.turn.label, shape.pointAt(it.at))) }
        add(RouteStep("목적지", points.last()))
    }
}

/** 길안내 모듈 경로의 좌표 (지도에 그릴 경로선) */
fun NavRoute.geoPoints(): List<GeoPoint> = points.map { GeoPoint(it.latitude, it.longitude) }

/**
 * 길안내 모듈 경로 → 경로 검색 결과.
 * 예: MainActivity 의 searchRoute() 에서 KakaoBicycleRouteClient.route(...) 결과를 `.toRoutePlan()` 으로 돌려주기
 */
fun NavRoute.toRoutePlan(): RoutePlan = RoutePlan(
    points = geoPoints(),
    distanceMeters = distanceMeters,
    minutes = ceil(durationSeconds / 60.0).toInt(),
    steps = steps.map { RouteStep(it.guidance, GeoPoint(it.latitude, it.longitude)) },
)

/**
 * 길안내: 길안내 모듈([NavigationSession])을 화면에 연결.
 * '안내 시작'([start]) → GPS 위치([onLocation]) 반복 → 목적지 25m 안에 들어오면 저절로 끝 (또는 '안내 종료' [stop]).
 * 모듈이 계산한 다음 안내 · 남은 거리 · 시간 · 경로 이탈 · 재탐색 · 사고다발지역 · 도착을 [guide] 에 넣어서
 * 배너 · 작은 칸 · 경로선 · 알림 · 음성 안내가 그대로 보여 줌.
 *
 * [start] · [onLocation] · [reroute] · [stop] 은 메인 스레드에서 부르기.
 *
 * @param hazards 사고다발지역 목록 (안내 중 150m 안에 들어오면 알림)
 * @param reroute 경로를 벗어났을 때 · '다시 찾기'를 눌렀을 때 쓰는 경로 검색. 출발지 null (= 내 위치) 로 같은 도착지 · 옵션을 다시 찾음.
 *   null 이면 재탐색 없이 이탈만 알림
 * @param unit 알림 글자의 거리 단위
 * @param options 길안내 모듈 기준 값 (이탈 거리, 알림 반경, 음성 문장 등). null 이면 기본값
 * @param callback 재탐색 결과를 받을 스레드 (기본: 메인 스레드)
 * @param worker 재탐색 경로 검색을 할 스레드 (기본: 백그라운드 스레드 하나)
 */
@Stable
class GuideNavigator(
    private val guide: GuideState,
    private val hazards: () -> List<HazardSpot> = { emptyList() },
    private val reroute: RouteSearch? = null,
    private val unit: () -> DistanceUnit = { DistanceUnit.Km },
    options: NavigationSession.Options? = null,
    callback: Executor = MainThreadExecutor,
    worker: Executor = rerouteWorker,
) {
    /** 안내 중인지 */
    var active: Boolean by mutableStateOf(false)
        private set

    /** 안내 중인 도착지 이름 */
    var destination: String by mutableStateOf("")
        private set

    /** 안내 중인 경로 (재탐색하면 새 경로). 안내 중이 아니면 null */
    var route: NavRoute? by mutableStateOf(null)
        private set

    /** 모듈이 마지막으로 알려 준 안내 상태 (진행률 progress · 속도 speedKmh 등을 더 보여 주고 싶을 때). 안내 중이 아니면 null */
    var state: NavigationSession.State? by mutableStateOf(null)
        private set

    /** 재탐색할 수 있는지 ('다시 찾기' 버튼) */
    val canReroute: Boolean get() = reroute != null

    @Volatile private var option = RouteOption.Fast
    private var arrived = false
    private var alert: GuideNotice? = null            // 이어지는 상황 알림 (위치 확인 중 · 사고다발지역 · 이탈 · 재탐색 중)
    private var syncedHazards: List<HazardSpot>? = null

    private val listener = object : NavigationSession.Listener {
        override fun onUpdate(state: NavigationSession.State) {
            this@GuideNavigator.state = state
            if (state.hasFix) {
                guide.next = Maneuver(state.maneuver.toTurn(), state.distanceToNext)
                guide.following = state.nextManeuver?.let { Maneuver(it.toTurn(), state.nextDistance) }
            } else {
                guide.next = null
                guide.following = null
            }
            guide.remainingMeters = state.remainingMeters
            guide.remainingSeconds = state.remainingSeconds
            showAlert(alertOf(state))
        }

        override fun onSpeak(text: String) = guide.say(text)

        // 알림은 onUpdate 의 nearbyHazard 로 보여 줌 (가까워지는 동안 거리도 바뀜). 음성은 모듈이 onSpeak 로 줌
        override fun onHazardApproach(hazard: NavigationSession.Hazard, distanceMeters: Double) {}

        override fun onRerouteStarted(automatic: Boolean) = showAlert(REROUTING)

        override fun onRouteChanged(newRoute: NavRoute) {
            showRoute(newRoute)
            guide.notice = GuideNotice("새 경로로 안내해요", newRoute.destinationName.ifBlank { null }?.let { "${it}까지" }, hideAfterMs = FLASH_MS)
        }

        override fun onRerouteFailed(message: String) {
            guide.notice = GuideNotice("경로를 다시 찾지 못했어요", message, NoticeLevel.Caution, FLASH_MS)
        }

        override fun onArrived() {
            arrived = true
        }

        override fun onEnded() {
            val name = destination
            active = false
            route = null
            state = null
            destination = ""
            alert = null
            guide.stopRoute()                        // 배너 · 작은 칸 사라짐
            guide.routeLine = emptyList()
            guide.voiceScripted = false
            guide.notice = if (arrived) GuideNotice("목적지에 도착했어요", name.ifBlank { null }, hideAfterMs = ARRIVED_MS) else null
        }
    }

    private val session = NavigationSession(
        listener,
        reroute?.let { search -> NavigationSession.Rerouter { _, _, previous -> searchAgain(search, previous) } },
        callback,
        worker,
        options,
    )

    /**
     * '안내 시작': 경로 설정 창에서 찾은 경로로 안내 시작.
     * @param destination 도착지 이름 (경로 설정 창에 넣은 글자. 재탐색 때 같은 도착지로 다시 찾음)
     * @param option 경로 옵션 (재탐색 때 같은 옵션으로)
     */
    fun start(plan: RoutePlan, destination: String, option: RouteOption = RouteOption.Fast) =
        begin(plan.toNavRoute(destination, bicycleFirst = option == RouteOption.BikeLane), option)

    /** 길안내 모듈 경로로 바로 시작 (예: [com.example.bicyclesafety.navigation.KakaoBicycleRouteClient] 로 받은 경로) */
    fun start(route: NavRoute) = begin(route, if (route.bicycleFirst) RouteOption.BikeLane else RouteOption.Fast)

    /**
     * GPS 위치가 올 때마다 부르기 (1초 간격 권장). 내 위치 핀은 늘 옮겨 가고, 안내 중이면 모듈이 안내를 다시 계산.
     * @param accuracyMeters 위치 오차 (m). 모르면 음수 → 경로 이탈 · 사고다발지역 판단을 하지 않음
     * @param speedMps 속도 (m/s). 모르면 음수 → 앞 위치와의 거리로 계산
     * @param timeMillis 위치 시각 (System.currentTimeMillis 와 같은 기준)
     */
    fun onLocation(
        latitude: Double,
        longitude: Double,
        accuracyMeters: Float = -1f,
        speedMps: Float = -1f,
        timeMillis: Long = System.currentTimeMillis(),
    ) {
        guide.updateLocation(latitude, longitude)
        if (!active) return
        syncHazards()
        session.onLocation(latitude, longitude, accuracyMeters, speedMps, timeMillis)
    }

    /** '다시 찾기': 지금 위치에서 같은 도착지로 경로 다시 찾기 */
    fun reroute() = session.reroute()

    /** '안내 종료' (종료 문장은 읽지 않음) */
    fun stop() = session.stop()

    private fun begin(newRoute: NavRoute, routeOption: RouteOption) {
        option = routeOption
        guide.stopRoute()                // 화면이 스스로 계산하는 안내(RouteGuide)는 끄고, 모듈이 계산한 값만 씀
        guide.voiceScripted = true       // 음성은 모듈 문장으로
        guide.notice = null
        alert = null
        arrived = false
        syncHazards()
        active = true
        showRoute(newRoute)
        session.start(newRoute)
        // 내 위치를 이미 알면 바로 안내 (다음 GPS 위치를 기다리지 않음)
        guide.myLocation?.let { session.onLocation(it.latitude, it.longitude, -1f, -1f, System.currentTimeMillis()) }
    }

    private fun showRoute(newRoute: NavRoute) {
        route = newRoute
        destination = newRoute.destinationName
        guide.routeLine = newRoute.geoPoints()
    }

    /** 지금 위치(출발지 null = 내 위치)에서 같은 도착지 · 옵션으로 다시 찾기. 재탐색 스레드에서 불림 */
    private fun searchAgain(search: RouteSearch, previous: NavRoute): NavRoute {
        val plan = runBlocking { search(null, previous.destinationName, option) }
        return plan.toNavRoute(previous.destinationName, previous.bicycleFirst)
    }

    private fun syncHazards() {
        val list = hazards()
        if (list === syncedHazards) return
        syncedHazards = list
        session.setHazards(list.map { NavigationSession.Hazard(it.id, it.name, it.location.latitude, it.location.longitude) })
    }

    /** 지금 상황에 맞는 알림 (위험한 것부터) */
    private fun alertOf(s: NavigationSession.State): GuideNotice? {
        val hazard = s.nearbyHazard
        return when {
            !s.hasFix -> LOCATING
            hazard != null -> GuideNotice(
                "사고다발지역 근처예요 · 주의하세요",
                listOfNotNull(hazard.name.ifBlank { null }, formatDistance(s.hazardDistance.roundToInt(), unit())).joinToString(" · "),
                NoticeLevel.Danger,
            )
            s.rerouting -> REROUTING
            s.offRoute -> GuideNotice(
                "경로를 벗어났어요",
                if (canReroute) "잠시 후 경로를 다시 찾아요" else "경로로 돌아가 주세요",
                NoticeLevel.Caution,
            )
            else -> null
        }
    }

    /**
     * 이어지는 상황 알림 바꾸기: 새 상황이면 보여 주고, 상황이 끝나면 그 알림만 지움.
     * 잠깐 보여 주는 알림(새 경로 등)이 떠 있으면 같은 상황이 이어지는 동안은 그대로 두고, 그 알림이 사라지면 다시 보여 줌
     */
    private fun showAlert(next: GuideNotice?) {
        val shown = guide.notice
        if (next != null) {
            if (next != alert || shown == null) guide.notice = next
        } else if (alert != null && shown == alert) {
            guide.notice = null
        }
        alert = next
    }

    private companion object {
        val LOCATING = GuideNotice("현재 위치를 확인하고 있어요", "GPS 신호를 기다리는 중이에요")
        val REROUTING = GuideNotice("경로를 다시 찾는 중이에요", level = NoticeLevel.Caution)
    }
}

/** 안드로이드 메인 스레드에서 실행 */
private object MainThreadExecutor : Executor {
    private val handler by lazy { Handler(Looper.getMainLooper()) }

    override fun execute(command: Runnable) {
        handler.post(command)
    }
}

/** 재탐색 경로 검색용 백그라운드 스레드 하나 (앱이 꺼질 때 붙잡지 않게 데몬 스레드) */
private val rerouteWorker: Executor by lazy {
    Executors.newSingleThreadExecutor { r -> Thread(r, "route-reroute").apply { isDaemon = true } }
}
