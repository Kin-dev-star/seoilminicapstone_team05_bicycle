package com.example.app.ui.guide

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app.ui.theme.Soft
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 임시 지도 (실제 지도 SDK 붙이기 전).
 * 화면 비율(0~1) 좌표로 길을 그리고, 위도·경도와 화면 위치를 서로 바꿔 줌.
 * 실제 지도를 붙이면 [toScreen] 대신 지도 SDK 의 변환을 쓰면 됨 (예: 네이버 `naverMap.projection.toScreenLocation`).
 */
object TempMap {
    // 화면 왼쪽 위가 (NORTH, WEST) 이고, 화면 가로가 WIDTH_M, 세로가 HEIGHT_M 인 것으로 침
    private const val NORTH = 37.5320
    private const val WEST = 126.9170
    private const val WIDTH_M = 600.0
    private const val HEIGHT_M = 1330.0
    private val latSpan = HEIGHT_M / METERS_PER_DEGREE
    private val lngSpan = WIDTH_M / (METERS_PER_DEGREE * cos(Math.toRadians(NORTH)))

    /** 위도·경도 → 지도 영역 안 화면 위치 (px) */
    fun toScreen(point: GeoPoint, mapSize: Size): Offset = Offset(
        ((point.longitude - WEST) / lngSpan * mapSize.width).toFloat(),
        ((NORTH - point.latitude) / latSpan * mapSize.height).toFloat(),
    )

    /** 화면 비율 위치 (0~1) → 위도·경도 */
    fun toGeo(fraction: Offset): GeoPoint = GeoPoint(NORTH - fraction.y * latSpan, WEST + fraction.x * lngSpan)

    // ── 길 모양 (화면 비율 좌표, 점들을 부드럽게 잇는 곡선) ──
    /** 큰길: 왼쪽 위에서 오른쪽으로 휘었다가 갈림길(5번 점)을 지나 아래로 */
    internal val MainRoad = listOf(
        Offset(-0.08f, 0.125f), Offset(0.2f, 0.13f), Offset(0.42f, 0.185f), Offset(0.545f, 0.29f), Offset(0.52f, 0.4f),
        Offset(0.3f, 0.51f), Offset(0.2f, 0.61f), Offset(0.27f, 0.72f), Offset(0.44f, 0.82f), Offset(0.4f, 0.93f), Offset(0.26f, 1.06f),
    )
    /** 갈림길에서 오른쪽으로 가는 길 (3번 점에서 오른쪽 골목과 만남) */
    internal val Branch = listOf(Offset(0.3f, 0.51f), Offset(0.42f, 0.565f), Offset(0.62f, 0.595f), Offset(0.845f, 0.605f), Offset(1.08f, 0.61f))
    internal val Streets = listOf(
        listOf(Offset(0.86f, -0.05f), Offset(0.85f, 0.25f), Offset(0.83f, 0.45f), Offset(0.845f, 0.605f), Offset(0.88f, 0.8f), Offset(0.9f, 1.05f)),
        listOf(Offset(-0.05f, 0.335f), Offset(0.2f, 0.345f), Offset(0.36f, 0.39f), Offset(0.52f, 0.4f)),   // 큰길 가운데에서 끝남
        listOf(Offset(-0.05f, 0.8f), Offset(0.18f, 0.79f), Offset(0.42f, 0.815f), Offset(0.62f, 0.8f), Offset(0.84f, 0.785f), Offset(1.05f, 0.77f)),
    )
    internal val Parks = listOf(Rect(0.62f, 0.25f, 0.78f, 0.41f), Rect(-0.06f, 0.655f, 0.15f, 0.765f))

    /**
     * 데모 값 채우기 (지도·GPS 붙이기 전 임시).
     * 경로: 아래쪽 큰길 → 갈림길에서 우회전 → 오른쪽 골목에서 좌회전. 내 위치: 갈림길 80m 전
     */
    fun fillDemo(guide: GuideState) {
        guide.startRoute(demoRoute())
        val route = guide.route ?: return
        val firstTurn = route.turns.firstOrNull()?.at ?: return
        guide.updateLocation(route.pointAt(firstTurn - 80.0))
    }

    /** 데모 경로 좌표: 아래쪽 큰길 → 갈림길에서 우회전 → 오른쪽 골목에서 좌회전 → 골목 위쪽에서 도착 (그린 길을 그대로 따라감) */
    fun demoRoute(): List<GeoPoint> =
        (sampleCurve(MainRoad, from = 5, to = 10).reversed() +
            sampleCurve(Branch, from = 0, to = 3) +
            sampleCurve(Streets[0], from = 1, to = 3).reversed()).map(::toGeo)

    /**
     * 데모 경로 검색: 어디를 넣어도 임시 지도 위 데모 경로를 돌려줌 (경로 API 붙이기 전 임시).
     * 출발지가 비어 있으면 (내 위치에서 출발) [here] 에서 출발하는 경로로 (재탐색도 이걸로 함)
     */
    suspend fun demoSearch(from: String?, to: String, option: RouteOption, here: GeoPoint? = null): RoutePlan {
        delay(400)                                         // 검색하는 척
        val points = demoRouteFrom(if (from == null) here else null)
        val meters = RouteGuide(points).length
        return RoutePlan(points, meters.roundToInt(), ceil(meters / 250.0).toInt())
    }

    /** 데모 경로를 [here] 에서 출발하게 자르기: 경로에서 가장 가까운 곳부터 (떨어져 있으면 그곳까지 곧게 이어서) */
    fun demoRouteFrom(here: GeoPoint?): List<GeoPoint> {
        val full = demoRoute()
        if (here == null) return full
        val shape = RouteGuide(full)
        val at = shape.progressOf(here)
        if (shape.length - at < 50.0) return full            // 거의 도착점이면 처음부터
        val join = shape.pointAt(at)
        val rest = ArrayList<GeoPoint>()
        var along = 0.0
        for (i in 1 until full.size) {
            along += distanceMeters(full[i - 1], full[i])
            if (along > at + 1.0) rest += full[i]
        }
        val head = if (distanceMeters(here, join) > 5.0) listOf(here, join) else listOf(join)
        return head + rest
    }

    /** 데모 사고다발지역: 오른쪽 골목으로 꺾는 교차로 */
    fun demoHazards(): List<HazardSpot> = listOf(HazardSpot("demo-1", "골목 교차로", toGeo(Branch[3])))

    /**
     * 데모 주행 (GPS 붙이기 전 임시): 길안내를 시작하면 내 위치가 경로를 따라 [speedMps] 로 움직이며 1초마다 위치를 넣어 줌.
     * 재탐색으로 경로가 바뀌면 지금 자리에서 새 경로를 따라가고, 안내가 끝나면 멈춤.
     * 실제 GPS 를 붙이면 이 줄을 지우고 GPS 콜백에서 navigator.onLocation(...) 부르기
     */
    fun demoDrive(scope: CoroutineScope, navigator: GuideNavigator, guide: GuideState, speedMps: Double = 6.0): Job = scope.launch {
        snapshotFlow { navigator.route }.collectLatest { route ->
            route ?: return@collectLatest
            val path = RouteGuide(route.geoPoints())
            var at = guide.myLocation?.let(path::progressOf) ?: 0.0
            while (at < path.length) {
                delay(1000)
                at = min(at + speedMps, path.length)
                val p = path.pointAt(at)
                navigator.onLocation(p.latitude, p.longitude, accuracyMeters = 5f, speedMps = speedMps.toFloat())
            }
        }
    }

    /** 데모 공공자전거 대여소 3곳 */
    fun demoStations(): List<Station> = listOf(
        Station("갈림길 대여소", toGeo(Offset(0.6f, 0.627f))),
        Station("공원 대여소", toGeo(Offset(0.07f, 0.71f))),
        Station("골목 대여소", toGeo(Offset(0.79f, 0.33f))),
    )
}

/**
 * 임시 지도 그림: 큰길, 갈림길, 골목, 공원.
 * [bikeLanes] 면 자전거도로(큰길 · 갈림길)를 초록 선으로, [stations] 는 대여소 표시, [hazards] 는 사고다발지역 표시,
 * [route] 는 안내 중인 경로선 (그리기 단계에서만 읽음 → 경로가 바뀌어도 지도만 다시 그림).
 * 실제 지도 SDK 를 붙이면 경로선은 SDK 의 선(polyline), 대여소 · 사고다발지역은 SDK 마커로.
 */
@Composable
fun TempMapView(
    modifier: Modifier = Modifier,
    bikeLanes: Boolean = false,
    stations: List<Station> = emptyList(),
    hazards: List<HazardSpot> = emptyList(),
    route: () -> List<GeoPoint> = { emptyList() },
) {
    Box(modifier) {
        // 별도 레이어에 그려 둠 → 메뉴 애니메이션 중에도 지도는 다시 그리지 않음. 길 모양은 크기가 바뀔 때만 계산
        Spacer(
            Modifier
                .fillMaxSize()
                .graphicsLayer()
                .drawWithCache {
                    val w = size.width
                    val h = size.height
                    fun px(points: List<Offset>) = smoothPath(points.map { Offset(it.x * w, it.y * h) })
                    val parks = TempMap.Parks.map { Rect(it.left * w, it.top * h, it.right * w, it.bottom * h) }
                    val parkCorner = CornerRadius(22.dp.toPx())
                    val edge = 1.5.dp.toPx()          // 길 테두리 (바탕과 길 사이 옅은 선)
                    val roads = listOf(px(TempMap.MainRoad) to 20.dp.toPx(), px(TempMap.Branch) to 15.dp.toPx()) +
                        TempMap.Streets.map { px(it) to 7.dp.toPx() }
                    fun stroke(width: Float) = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    val edges = roads.map { (path, width) -> path to stroke(width + edge * 2) }
                    val fills = roads.map { (path, width) -> path to stroke(width) }
                    val lanes = listOf(roads[0].first, roads[1].first)          // 자전거도로: 큰길 · 갈림길
                    val laneStroke = stroke(5.dp.toPx())
                    val routeCasing = stroke(11.dp.toPx())
                    val routeStroke = stroke(6.dp.toPx())
                    val stationR = 12.dp.toPx()
                    val hazardR = 11.dp.toPx()
                    val hazardHalo = 26.dp.toPx()
                    onDrawBehind {
                        drawRect(Soft.Base)
                        parks.forEach { drawRoundRect(Soft.MapPark, it.topLeft, it.size, parkCorner) }
                        // 테두리를 먼저 다 그리고 길을 덮어야 길끼리 만나는 곳이 자연스럽게 이어짐
                        edges.forEach { (path, s) -> drawPath(path, Soft.MapGrid, style = s) }
                        fills.forEach { (path, s) -> drawPath(path, Soft.MapRoad, style = s) }
                        if (bikeLanes) lanes.forEach { drawPath(it, Soft.MapBikeLane.copy(alpha = 0.8f), style = laneStroke) }
                        val line = route()
                        if (line.size >= 2) {
                            val path = Path()
                            line.forEachIndexed { i, g ->
                                val o = TempMap.toScreen(g, size)
                                if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
                            }
                            drawPath(path, Soft.Base.copy(alpha = 0.9f), style = routeCasing)
                            drawPath(path, Soft.Accent.copy(alpha = 0.85f), style = routeStroke)
                        }
                        stations.forEach { st ->
                            val c = TempMap.toScreen(st.location, size)
                            drawCircle(Soft.Dark.copy(alpha = if (Soft.isBlack) 0.8f else 0.35f), stationR, c + Offset(0f, 2.dp.toPx()))
                            drawCircle(Color.White, stationR, c)
                            drawCircle(Soft.MapBikeLane, stationR - 2.dp.toPx(), c)
                            drawBikeGlyph(c, stationR * 1.25f, Color.White)
                        }
                        hazards.forEach { h ->
                            val c = TempMap.toScreen(h.location, size)
                            drawCircle(Soft.Danger.copy(alpha = 0.16f), hazardHalo, c)
                            drawCircle(Soft.Dark.copy(alpha = if (Soft.isBlack) 0.8f else 0.35f), hazardR, c + Offset(0f, 2.dp.toPx()))
                            drawCircle(Color.White, hazardR, c)
                            drawCircle(Soft.Danger, hazardR - 2.dp.toPx(), c)
                            drawExclamation(c, hazardR, Color.White)
                        }
                    }
                }
        )
        Text(
            "임시 지도",
            color = Soft.TextHint,
            fontSize = 13.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(start = 20.dp, top = 16.dp),
        )
    }
}

/** 느낌표 (사고다발지역 표시 안) */
private fun DrawScope.drawExclamation(center: Offset, radius: Float, color: Color) {
    val w = radius * 0.24f
    drawLine(color, center + Offset(0f, -radius * 0.48f), center + Offset(0f, radius * 0.1f), strokeWidth = w, cap = StrokeCap.Round)
    drawCircle(color, w * 0.62f, center + Offset(0f, radius * 0.45f))
}

/** 작은 자전거 모양 (대여소 표시 안) */
private fun DrawScope.drawBikeGlyph(center: Offset, size: Float, color: Color) {
    val u = size / 16f
    fun p(x: Float, y: Float) = Offset(center.x + x * u, center.y + y * u)
    val line = Stroke(1.6f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawCircle(color, 3.4f * u, p(-4.4f, 2.2f), style = line)
    drawCircle(color, 3.4f * u, p(4.4f, 2.2f), style = line)
    val frame = Path().apply {
        listOf(
            listOf(p(-4.4f, 2.2f), p(-1.2f, -3.4f), p(2.6f, -3.4f), p(4.4f, 2.2f)),
            listOf(p(-4.4f, 2.2f), p(0.4f, 2.2f), p(-1.2f, -3.4f)),
            listOf(p(0.4f, 2.2f), p(2.6f, -3.4f)),
        ).forEach { pts ->
            moveTo(pts[0].x, pts[0].y)
            pts.drop(1).forEach { lineTo(it.x, it.y) }
        }
    }
    drawPath(frame, color, style = line)
}

/** 점 i → i+1 사이 곡선의 베지어 조절점 (캣멀-롬 곡선: 모든 점을 부드럽게 지남) */
private fun controls(points: List<Offset>, i: Int): Pair<Offset, Offset> {
    val p0 = points[maxOf(i - 1, 0)]
    val p1 = points[i]
    val p2 = points[i + 1]
    val p3 = points[minOf(i + 2, points.size - 1)]
    return (p1 + (p2 - p0) / 6f) to (p2 - (p3 - p1) / 6f)
}

private fun smoothPath(points: List<Offset>): Path = Path().apply {
    moveTo(points[0].x, points[0].y)
    for (i in 0 until points.size - 1) {
        val (c1, c2) = controls(points, i)
        cubicTo(c1.x, c1.y, c2.x, c2.y, points[i + 1].x, points[i + 1].y)
    }
}

/** 곡선 위 점들 (점 [from] ~ [to] 구간, 구간마다 [steps] 개) — 그린 길과 똑같은 곡선을 따라감 */
private fun sampleCurve(points: List<Offset>, from: Int, to: Int, steps: Int = 16): List<Offset> {
    val out = ArrayList<Offset>()
    for (i in from until to) {
        val p1 = points[i]
        val p2 = points[i + 1]
        val (c1, c2) = controls(points, i)
        for (k in 0 until steps) {
            val t = k / steps.toFloat()
            val u = 1f - t
            out += p1 * (u * u * u) + c1 * (3f * u * u * t) + c2 * (3f * u * t * t) + p2 * (t * t * t)
        }
    }
    out += points[to]
    return out
}
