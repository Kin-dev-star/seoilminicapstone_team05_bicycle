package com.example.app.ui.guide

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.app.ui.data.DistanceUnit
import com.example.app.ui.data.formatDistance
import kotlin.math.abs
import kotlin.math.ceil
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/** 위도·경도 (지도 SDK 의 LatLng 과 같은 뜻. 이름이 겹치지 않게 따로 둠) */
data class GeoPoint(val latitude: Double, val longitude: Double)

/** 길안내 방향 = 화살표 아이콘 */
enum class Turn(val label: String) {
    Straight("직진"),
    Left("좌회전"),
    Right("우회전"),
    UTurn("유턴");

    val icon: ImageVector
        get() = when (this) {
            Straight -> NavIcons.Straight
            Left -> NavIcons.TurnLeft
            Right -> NavIcons.TurnRight
            UTurn -> NavIcons.UTurn
        }

    companion object {
        /**
         * 꺾는 각도로 방향 정하기 (오른쪽으로 꺾으면 +, 왼쪽이면 −, 단위 도).
         * [straightBelow] 보다 덜 꺾이면 직진, 150° 이상이면 유턴.
         */
        fun fromAngle(degrees: Double, straightBelow: Double = 30.0): Turn = when {
            abs(degrees) < straightBelow -> Straight
            abs(degrees) >= 150.0 -> UTurn
            degrees > 0 -> Right
            else -> Left
        }
    }
}

/** 안내 하나: [distanceMeters] m 뒤에 [turn]. [road] 는 들어갈 길 이름 (경로 API 가 알려주면) */
data class Maneuver(val turn: Turn, val distanceMeters: Int, val road: String? = null) {
    /** 남은 거리 글자 (예: 80m, 1.2km, 0.3mi) */
    fun distanceText(unit: DistanceUnit = DistanceUnit.Km): String = formatDistance(distanceMeters, unit)

    /** "80m 후 우회전", 직진은 "300m 직진" */
    fun text(unit: DistanceUnit = DistanceUnit.Km): String =
        if (turn == Turn.Straight) "${distanceText(unit)} 직진" else "${distanceText(unit)} 후 ${turn.label}"
}

/** 알림 종류 (색): 알림 (파랑) · 주의 (주황) · 위험 (빨강) */
enum class NoticeLevel { Info, Caution, Danger }

/**
 * 길안내 알림 한 줄 (배너 아래 · 작은 칸 옆). 예: 경로 이탈, 재탐색, 사고다발지역 접근, 도착.
 * [hideAfterMs] 가 0 보다 크면 그만큼 뒤 저절로 사라짐 (0 이면 [GuideState.notice] 를 null 로 바꿀 때까지 보임)
 */
data class GuideNotice(
    val title: String,
    val detail: String? = null,
    val level: NoticeLevel = NoticeLevel.Info,
    val hideAfterMs: Long = 0,
)

/**
 * 길안내 화면에 보이는 값. 여기 값만 바꾸면 핀과 화살표(칸 또는 위쪽 배너)가 알아서 바뀜.
 * 앱의 길안내는 길안내 모듈([GuideNavigator])이 계산해서 여기에 넣음 ('안내 시작' → GPS 위치 → 도착).
 *
 * 모듈 없이 직접 넣을 때:
 * - 경로를 받으면: `startRoute(경로 좌표 목록)` (화면이 꺾이는 곳을 찾아 안내)
 * - GPS 위치가 올 때마다: `updateLocation(위도, 경도)` → 핀이 그 자리로 부드럽게 이동하고,
 *   경로가 있으면 다음 안내 · 그다음 안내 · 남은 거리를 다시 계산
 * - 안내 끝: `stopRoute()` → 화살표 사라짐
 * - 경로 API 가 방향을 직접 알려주면 계산 없이 `next = Maneuver(Turn.Left, 150, road = "여의서로")` 처럼 넣어도 됨
 */
@Stable
class GuideState {
    /** 내 위치. null 이면 핀을 숨김 */
    var myLocation: GeoPoint? by mutableStateOf(null)

    /** 다음 안내. null 이면 화살표를 숨김 */
    var next: Maneuver? by mutableStateOf(null)

    /** 그다음 안내 (거리는 다음 안내 지점에서부터). 없으면 null */
    var following: Maneuver? by mutableStateOf(null)

    /** 도착까지 남은 거리 (m). 모르면 null */
    var remainingMeters: Int? by mutableStateOf(null)

    /** 도착까지 남은 시간 (초). 길안내 모듈이나 경로 API 가 알려 주면 넣기. 모르면 null → 평균 속도로 어림 */
    var remainingSeconds: Int? by mutableStateOf(null)

    /** 남은 시간을 어림할 때 쓰는 평균 속도 (km/h) */
    var speedKmh: Double by mutableStateOf(15.0)

    /** 도착까지 남은 시간 (분) */
    val remainingMinutes: Int?
        get() {
            remainingSeconds?.let { return ceil(it / 60.0).toInt().coerceAtLeast(1) }
            return remainingMeters?.let { ceil(it / (speedKmh * 1000.0 / 60.0)).toInt().coerceAtLeast(1) }
        }

    /** 지도에 그릴 경로선 (안내 중인 경로). 비어 있으면 안 그림 */
    var routeLine: List<GeoPoint> by mutableStateOf(emptyList())

    /** 길안내 알림 (경로 이탈 · 재탐색 · 사고다발지역 접근 · 도착 등). null 이면 숨김 */
    var notice: GuideNotice? by mutableStateOf(null)

    /**
     * 길안내 모듈처럼 읽을 문장을 직접 주는 쪽이 안내하는 동안 true.
     * 그동안 음성 안내는 [say] 로 들어온 문장만 읽고, 다음 안내를 보고 문장을 만들지 않음
     */
    var voiceScripted: Boolean by mutableStateOf(false)

    private val sentences = MutableSharedFlow<String>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** 음성으로 읽을 문장 (음성 안내가 켜져 있을 때만 읽고, 꺼져 있으면 버려짐) */
    val speech: SharedFlow<String> = sentences.asSharedFlow()

    /** 음성으로 읽을 문장 넣기 (예: 길안내 모듈의 "150미터 앞에서 좌회전") */
    fun say(text: String) {
        sentences.tryEmit(text)
    }

    /** 지금 따라가는 경로 (없으면 null) */
    var route: RouteGuide? = null
        private set

    fun startRoute(points: List<GeoPoint>) {
        val guide = RouteGuide(points)
        route = guide
        val here = myLocation
        if (here != null) show(guide.guidance(here)) else show(Guidance(null, null, null))
    }

    fun stopRoute() {
        route = null
        show(Guidance(null, null, null))
    }

    fun updateLocation(latitude: Double, longitude: Double) = updateLocation(GeoPoint(latitude, longitude))

    fun updateLocation(point: GeoPoint) {
        myLocation = point
        route?.let { show(it.guidance(point)) }
    }

    private fun show(g: Guidance) {
        next = g.next
        following = g.following
        remainingMeters = g.remainingMeters
        remainingSeconds = null
    }
}
