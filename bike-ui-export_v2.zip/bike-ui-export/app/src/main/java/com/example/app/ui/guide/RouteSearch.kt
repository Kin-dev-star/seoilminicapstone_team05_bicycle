package com.example.app.ui.guide

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.app.ui.data.Place

/** 경로 옵션 (경로 설정 창의 칩) */
enum class RouteOption(val label: String) { Fast("빠른 길"), BikeLane("자전거길 우선"), Flat("평지 위주") }

/**
 * 경로 위 안내 지점: 이 위치에서 [guidance] 로 안내.
 * 카카오 자전거 길찾기의 step 마다 있는 guidance (예: "좌회전", "2시 방향", "목적지") 와 x · y 를 그대로 넣으면 됨
 */
data class RouteStep(val guidance: String, val location: GeoPoint)

/**
 * 경로 검색 결과: 경로 좌표, 예상 거리 · 시간 (경로 설정 창의 예상 정보), 안내 지점.
 * [steps] 가 비어 있으면 길안내를 시작할 때 경로 모양에서 꺾이는 곳을 찾아 안내 지점을 만듦
 */
data class RoutePlan(
    val points: List<GeoPoint>,
    val distanceMeters: Int,
    val minutes: Int,
    val steps: List<RouteStep> = emptyList(),
)

/**
 * 경로 검색 함수: 경로 설정 창에 도착지를 넣으면 불림.
 * [from] 이 null 이면 내 위치에서 출발. 경로를 못 찾으면 예외를 던지면 그 메시지가 창에 나옴.
 */
typealias RouteSearch = suspend (from: String?, to: String, option: RouteOption) -> RoutePlan

/**
 * 장소 검색 (자동완성): 경로 설정의 출발지 · 도착지에 글자를 넣으면 불림. 입력한 글자로 찾은 장소 후보를 돌려주기.
 * 장소 검색 API (예: 카카오 로컬 키워드 검색, 네이버 검색) 를 붙이면 여기서 부르면 됨. 못 찾으면 빈 목록.
 */
typealias PlaceSearch = suspend (query: String) -> List<Place>

/** 공공자전거 대여소 */
data class Station(val name: String, val location: GeoPoint)

/** 과거 자전거 사고다발지역 */
data class HazardSpot(val id: String, val name: String, val location: GeoPoint)

/** 지도 위에 더 보여 줄 것. 실제 지도 SDK 를 붙이면 SDK 마커로 그리면 됨 */
@Stable
class MapData {
    /** 공공자전거 대여소 (설정에서 '공공자전거 대여소 표시'를 켜면 지도에 보임) */
    var rentalStations: List<Station> by mutableStateOf(emptyList())

    /** 과거 사고다발지역: 지도에 표시하고, 길안내 중 150m 안에 들어오면 알림 · 음성으로 알려 줌 */
    var hazards: List<HazardSpot> by mutableStateOf(emptyList())
}
