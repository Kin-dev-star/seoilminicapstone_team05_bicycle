package com.example.app.ui

import com.example.app.ui.account.AccountState
import com.example.app.ui.data.ProfileState
import com.example.app.ui.guide.GuideNavigator
import com.example.app.ui.guide.GuideState
import com.example.app.ui.guide.MapData
import com.example.app.ui.guide.PlaceSearch
import com.example.app.ui.guide.RouteSearch
import com.example.app.ui.main.AppSettings
import com.example.bicyclesafety.navigation.NavigationSession

/**
 * 앱 화면에 보이는 값과 연결 지점을 한곳에 모은 것. 여기 값만 바꾸면 화면이 따라 바뀜.
 *
 * @param guide 길안내 화면 값: 내 위치(핀), 다음 안내(배너 · 작은 칸), 경로선, 알림
 * @param account 로그인: 사용자 정보, 카카오 로그인 · 로그아웃
 * @param profile 마이페이지: 이번 달 기록, 최근 주행, 즐겨찾는 장소, 주행 목표
 * @param map 지도 위 표시: 공공자전거 대여소, 사고다발지역
 * @param settings 설정 (자동 저장)
 * @param searchRoute 경로 검색: 경로 설정 창에서 도착지를 정하면 불림. 길안내 중 경로를 벗어나면 재탐색에도 씀 (출발지 null = 내 위치)
 * @param searchPlaces 장소 검색 (자동완성): 출발지 · 도착지에 글자를 넣으면 불림
 * @param navOptions 길안내 모듈 기준 값 (이탈 거리 · 사고다발지역 알림 반경 · 음성 문장 등). null 이면 모듈 기본값
 */
class AppState(
    val guide: GuideState = GuideState(),
    val account: AccountState = AccountState(),
    val profile: ProfileState = ProfileState(),
    val map: MapData = MapData(),
    val settings: AppSettings = AppSettings(),
    val searchRoute: RouteSearch = { _, _, _ -> throw IllegalStateException("경로 검색 연결 전이에요") },
    val searchPlaces: PlaceSearch = { emptyList() },
    navOptions: NavigationSession.Options? = null,
) {
    /**
     * 길안내 (길안내 모듈 NavigationSession 연결). 경로 설정 창의 '안내 시작'이 여기로 옴.
     * GPS 위치가 올 때마다 `navigator.onLocation(위도, 경도, 오차, 속도, 시각)`,
     * 경로를 벗어나면 [searchRoute] 로 재탐색, 사고다발지역은 [map] 의 hazards 를 씀
     */
    val navigator: GuideNavigator = GuideNavigator(
        guide,
        hazards = { map.hazards },
        reroute = searchRoute,
        unit = { settings.unit },
        options = navOptions,
    )
}
