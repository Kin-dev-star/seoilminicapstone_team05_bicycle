# 자전거 앱 화면 — 다른 프로젝트에 넣기

## 들어 있는 것
| 파일 | 내용 |
|---|---|
| `ui/BikeApp.kt` | 로딩화면 → 메인 화면 전체 흐름 |
| `ui/loading/BikeLoadingScreen.kt` | 자전거 로딩 애니메이션 |
| `ui/main/MainScreen.kt` | 지도 영역, 원통 메뉴, 모아보기, 현재 위치 버튼, 경로 설정 창, 마이페이지, 설정 |
| `ui/theme/Soft.kt` | 소프트 UI 색·그림자 (밝은 테마 / 블랙 테마) |
| `res/values/bike_colors.xml` | (선택) 앱 켤 때 깜빡임 방지용 파란색 |

## 1. 파일 복사
이 폴더의 `app` 폴더를 프로젝트 폴더에 그대로 덮어 넣으면 같은 경로로 들어가요.
패키지 이름(`com.example.app.ui`)은 그대로 둬도 동작해요.
바꾸고 싶으면 Android Studio에서 `ui` 패키지를 우클릭 → **Refactor → Move** 로 옮기면 import 까지 같이 바뀌어요.

## 2. `app/build.gradle.kts`
```kotlin
plugins {
    id("org.jetbrains.kotlin.plugin.compose")   // Kotlin 2.0 이상 (루트 build.gradle.kts 에도 같은 버전으로 등록)
}

android {
    defaultConfig { minSdk = 23 }               // 23 이상
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.12.01"))   // 2025.08 이상 필요 (그림자 기능)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.10.1")           // 1.10 이상 필요
}
```

## 3. Activity 에서 쓰기
```kotlin
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BikeApp() }
    }
}
```
- 실제 로딩 작업 넣기: `BikeApp(loadInitialData = { /* 지도 초기화 등 */ })`
- 메인 화면만 쓰기: `setContent { MaterialTheme { MainScreen() } }`
- 블랙 테마: `Soft.isBlack = true` (설정 화면의 블랙 테마 스위치와 같고, 바꾸면 자동 저장)

## 4. (선택) 켤 때 흰 화면 깜빡임 막기
앱 테마(`res/values/themes.xml`)에 한 줄 추가:
```xml
<item name="android:windowBackground">@color/bike_blue</item>
```

## 참고
- 지도, 현재 위치, 검색, 기록 숫자, 설정 값은 아직 임시예요 (지도 SDK 연결 전).
- 확인한 환경: AGP 8.13.2 · Kotlin 2.3.21 · Compose BOM 2025.12.01 · activity-compose 1.10.1 · compileSdk 36
