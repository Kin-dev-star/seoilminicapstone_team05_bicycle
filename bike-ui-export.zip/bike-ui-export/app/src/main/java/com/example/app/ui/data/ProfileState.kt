package com.example.app.ui.data

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.app.ui.guide.GeoPoint

/** 주행 기록 하나. [dateMillis] 는 주행한 날 (System.currentTimeMillis() 같은 값) */
data class RideRecord(val title: String, val distanceMeters: Int, val minutes: Int, val dateMillis: Long)

/** 기간 합계: 거리, 주행 횟수, 시간 */
data class RideSummary(val distanceMeters: Int, val rides: Int, val minutes: Int) {
    companion object {
        /** 기록 목록으로 합계 내기 (예: 이번 달 기록만 골라서 넣기) */
        fun of(records: List<RideRecord>) = RideSummary(records.sumOf { it.distanceMeters }, records.size, records.sumOf { it.minutes })
    }
}

/**
 * 장소: 이름과 주소, 알면 위치 (경로 설정의 장소 후보 · 즐겨찾기 · 최근 장소).
 * 즐겨찾기는 이름이 '집' · '회사' 같은 별명이고, 누르면 주소가 입력칸에 들어감.
 */
data class Place(val name: String, val address: String, val location: GeoPoint? = null)

/**
 * 마이페이지 값. 여기 값만 바꾸면 마이페이지가 따라 바뀜 (서버·DB 에서 받아 넣기).
 * 즐겨찾는 장소는 경로 설정 창의 즐겨찾기에도 같이 쓰임.
 */
@Stable
class ProfileState {
    /** 이번 달 기록 (위쪽 숫자 칸 3개). null 이면 0 */
    var monthly: RideSummary? by mutableStateOf(null)

    /** 최근 주행 (최근 것부터, 마이페이지엔 앞에서 3개) */
    var recentRides: List<RideRecord> by mutableStateOf(emptyList())

    /** 즐겨찾는 장소 */
    var favorites: List<Place> by mutableStateOf(emptyList())

    /** 최근에 고른 장소 (경로 설정에서 후보를 고르면 앞에 쌓임, 최근 것부터) */
    var recentPlaces: List<Place> by mutableStateOf(emptyList())

    /** 주행 목표 (일주일, km). null 이면 '없음' */
    var weeklyGoalKm: Int? by mutableStateOf(null)
}
