package com.example.app.ui.guide

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.app.ui.data.Place

/** 경로 옵션 (경로 설정 창의 칩) */
enum class RouteOption(val label: String) { Fast("빠른 길"), BikeLane("자전거길 우선"), Flat("평지 위주") }

/** 경로 검색 결과: 경로 좌표와 예상 거리 · 시간 (경로 설정 창의 예상 정보) */
data class RoutePlan(val points: List<GeoPoint>, val distanceMeters: Int, val minutes: Int)

/**
 * 경로 검색 함수: 경로 설정 창에 도착지를 넣으면 불림.
 * [from] 이 null 이면 내 위치에서 출발. 경로를 못 찾으면 예외를 던지면 그 메시지가 창에 나옴.
 */
typealias RouteSearch = suspend (from: String?, to: String, option: RouteOption) -> RoutePlan

/**
 * 장소 검색 (자동완성): 경로 설정의 출발지 · 도착지에 글자를 넣으면 불림. 입력한 글자로 찾은 장소 후보를 돌려주기.
 * 장소 검색 API (예: 카카오 로컬 키워드 검색, 네이버 검색) 를 붙이면 여기서 부르면 됨. 못 찾으면 빈 목록.
 */
typealias PlaceSearch = suspend (query: String) -> List<Place>

/** 공공자전거 대여소 */
data class Station(val name: String, val location: GeoPoint)

/** 지도 위에 더 보여 줄 것. 실제 지도 SDK 를 붙이면 SDK 마커로 그리면 됨 */
@Stable
class MapData {
    /** 공공자전거 대여소 (설정에서 '공공자전거 대여소 표시'를 켜면 지도에 보임) */
    var rentalStations: List<Station> by mutableStateOf(emptyList())
}
