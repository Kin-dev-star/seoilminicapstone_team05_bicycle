package com.example.app.ui.account

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** 로그인한 사용자 (카카오에서 받은 이름 · 이메일) */
data class UserProfile(val name: String, val email: String? = null)

/**
 * 로그인 상태. 마이페이지와 로그인 화면이 이 값을 따라 바뀜.
 *
 * @param kakaoLogin 로그인 화면의 '카카오 로그인' 버튼을 누르면 불림.
 *   카카오 SDK 로 로그인하고 사용자 정보를 돌려주기. 실패하거나 취소하면 예외를 던지면 그 메시지가 화면에 나옴
 * @param logout 마이페이지 '로그아웃'을 누르면 불림 (카카오 SDK 로그아웃 등)
 * @param editProfile 로그인한 뒤 마이페이지 '편집'을 누르면 불림 (프로필 편집 화면 열기 등)
 */
@Stable
class AccountState(
    val kakaoLogin: suspend () -> UserProfile = { throw IllegalStateException("카카오 로그인 연결 전이에요") },
    val logout: suspend () -> Unit = {},
    val editProfile: () -> Unit = {},
) {
    /** 로그인한 사용자. null 이면 로그인 안 함 */
    var user: UserProfile? by mutableStateOf(null)
}
