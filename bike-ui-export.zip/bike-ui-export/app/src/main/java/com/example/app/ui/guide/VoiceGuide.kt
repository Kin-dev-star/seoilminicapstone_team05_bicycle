package com.example.app.ui.guide

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.LocalContext
import com.example.app.ui.data.DistanceUnit
import com.example.app.ui.data.LocalDistanceUnit
import com.example.app.ui.data.spokenDistance
import java.util.Locale

/**
 * 음성 안내 (설정 → 음성 안내). 다음 안내가 바뀌면 소리로 알려 줌.
 * [speak] 를 주면 그걸로 말하고, 없으면 안드로이드 기본 음성(TTS)으로 말함.
 */
@Composable
fun VoiceGuide(guide: GuideState, enabled: Boolean, speak: ((String) -> Unit)? = null) {
    if (!enabled) return
    val tts = if (speak == null) rememberTts() else null
    val say by rememberUpdatedState(speak ?: { text: String -> tts?.speak(text) })
    val unit by rememberUpdatedState(LocalDistanceUnit.current)
    LaunchedEffect(guide) {
        val announcer = VoiceAnnouncer()
        snapshotFlow { guide.next }.collect { next -> announcer.next(next, unit)?.let { say(it) } }
    }
}

/**
 * 말할 문장 고르기. 새 안내가 나오면 바로 한 번, 같은 안내는 300m · 100m 를 지날 때와 30m 안에 들어올 때 한 번씩.
 * (직진은 새로 나올 때만)
 */
class VoiceAnnouncer {
    private var current: Maneuver? = null
    private val said = HashSet<Int>()

    fun next(m: Maneuver?, unit: DistanceUnit): String? {
        val prev = current
        current = m
        if (m == null) {
            said.clear()
            return null
        }
        val isNew = prev == null || prev.turn != m.turn || m.distanceMeters > prev.distanceMeters + 50
        if (isNew) {
            said.clear()
            markPassed(m.distanceMeters)
            return sentence(m, unit)
        }
        if (m.turn == Turn.Straight) return null
        val hit = MARKS.firstOrNull { m.distanceMeters <= it && it !in said } ?: return null
        markPassed(m.distanceMeters)
        return sentence(m, unit)
    }

    private fun markPassed(distance: Int) = MARKS.filter { it >= distance }.forEach { said += it }

    private fun sentence(m: Maneuver, unit: DistanceUnit): String = when {
        m.turn == Turn.Straight -> "${spokenDistance(m.distanceMeters, unit)} 직진하세요"
        m.distanceMeters <= SOON_M -> "잠시 후 ${m.turn.label}하세요"
        else -> "${spokenDistance(m.distanceMeters, unit)} 앞에서 ${m.turn.label}하세요"
    }

    private companion object {
        val MARKS = listOf(300, 100, 30)
        const val SOON_M = 30
    }
}

/** 안드로이드 기본 음성: 처음 말할 때 준비하고, 화면에서 빠지면 정리 */
@Composable
private fun rememberTts(): Tts {
    val context = LocalContext.current
    val tts = remember { Tts(context.applicationContext) }
    DisposableEffect(tts) { onDispose { tts.shutdown() } }
    return tts
}

private class Tts(private val context: Context) {
    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun speak(text: String) {
        if (ready) {
            engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "guide")
            return
        }
        pending = text
        if (engine == null) {
            engine = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    engine?.language = Locale.KOREAN
                    ready = true
                    pending?.let { speak(it) }
                    pending = null
                }
            }
        }
    }

    fun shutdown() {
        engine?.shutdown()
        engine = null
        ready = false
    }
}
