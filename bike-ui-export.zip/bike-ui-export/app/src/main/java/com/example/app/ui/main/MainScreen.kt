package com.example.app.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.calculateTargetValue
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.structuralEqualityPolicy
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app.ui.AppState
import com.example.app.ui.account.LoginBody
import com.example.app.ui.data.DistanceUnit
import com.example.app.ui.data.LocalDistanceUnit
import com.example.app.ui.data.Place
import com.example.app.ui.data.RideSummary
import com.example.app.ui.data.distanceParts
import com.example.app.ui.data.formatDistance
import com.example.app.ui.data.formatMinutes
import com.example.app.ui.guide.GeoPoint
import com.example.app.ui.guide.GuideBanner
import com.example.app.ui.guide.GuideStyle
import com.example.app.ui.guide.MyLocationPin
import com.example.app.ui.guide.RouteOption
import com.example.app.ui.guide.RoutePlan
import com.example.app.ui.guide.TempMap
import com.example.app.ui.guide.TempMapView
import com.example.app.ui.guide.TurnBox
import com.example.app.ui.guide.VoiceGuide
import com.example.app.ui.guide.distanceMeters
import com.example.app.ui.theme.LocalSoftShadow
import com.example.app.ui.theme.Soft
import com.example.app.ui.theme.SoftShadow
import com.example.app.ui.theme.softInset
import com.example.app.ui.theme.softPressable
import com.example.app.ui.theme.softPressedInset
import com.example.app.ui.theme.softRaised
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// ── 오른쪽 아래 원통 메뉴 ──
private val BAR_H = 64.dp                // 막대 높이
private val PEEK = 16.dp                 // 뒤쪽 막대가 앞 막대 위로 보이는 높이
private val DROP = 24.dp                 // 앞 막대가 아래로 말려 들어갈 때 내려가는 거리
private val DRUM_STEP = 60.dp            // 한 칸 넘기는 데 필요한 드래그 거리
private const val VISIBLE_BACK = 2f      // 앞 막대 뒤로 보이는 막대 수
private const val BACK_SHRINK = 0.06f    // 뒤로 한 칸 갈 때마다 줄어드는 비율 (오른쪽 아래 기준)
private const val BACK_SHADE = 0.10f     // 뒤로 한 칸 갈 때마다 어두워지는 정도
private const val DRUM_WIDTH = 0.8f      // 막대 너비 (화면 너비 대비)
private val DRUM_H = BAR_H + PEEK * VISIBLE_BACK + 8.dp   // 원통 메뉴 영역 높이
private val LOC_BTN = 40.dp             // 현재 위치 버튼 크기
private val LIST_GAP = 12.dp            // 모아보기에서 막대 사이 간격
private const val OVERVIEW_STAGGER = 0.08f   // 모아보기로 펼칠 때 막대마다 늦게 출발하는 정도
/** 모아보기로 펼쳤을 때 막대 목록 전체 높이 */
private val LIST_H: Dp get() = BAR_H * NavItem.entries.size + LIST_GAP * (NavItem.entries.size - 1)
private const val DRUM_FRICTION = 2f     // 관성 마찰 (작을수록 멀리 돎)
private const val SNAP_SPEED = 4f        // 이 속도(초당 칸)보다 느려지면 가장 가까운 막대로 빠르게 맞춤
private const val MAX_SPIN = 8f          // 한 번 튕길 때 최대로 도는 칸 수 (두 바퀴)

// ── 경로 설정 창 ──
private val ROW = 44.dp                  // 출발/도착 한 줄 높이
private val DIVIDER = 2.dp               // 출발·도착 사이 구분선 (어두운 선 1dp + 밝은 선 1dp)
private val FIELD_H = ROW * 2 + DIVIDER
private val SHEET_MIN = 250.dp           // 화면이 작아도 1/3 창이 이보다 작아지지 않게
private val SHEET_CORNER = 28.dp

private val EDGE = 20.dp                 // 화면 가장자리 여백
private val CORNER = 18.dp
private val CardShape = RoundedCornerShape(CORNER)
private val FieldShape = RoundedCornerShape(16.dp)
private val WellShape = RoundedCornerShape(12.dp)
private val PillShape = RoundedCornerShape(percent = 50)
private val DividerDark: Color get() = Soft.Dark.copy(alpha = if (Soft.isBlack) 0.9f else 0.45f)

// 테마(밝은/블랙)에 따라 바뀌는 글자 스타일
private val FieldTextStyle: TextStyle get() = TextStyle(color = Soft.Text, fontSize = 14.sp)
private val CursorBrush: SolidColor get() = SolidColor(Soft.Accent)
private const val PRESS_MS = 110         // 눌림(볼록 → 오목) 전환 시간
private const val SUGGEST_DELAY_MS = 150L // 입력이 멈추고 이만큼 지나면 장소 후보 검색
private const val MAX_SUGGESTIONS = 6     // 장소 후보 최대 개수 (키보드에 가리지 않을 만큼)
private const val RECENT_MAX = 5          // 최근 장소 최대 개수

/** 원통 메뉴에 차례대로 도는 항목 */
enum class NavItem(val title: String, val subtitle: String, val pageTitle: String, val icon: ImageVector) {
    Route("경로 설정", "출발지 · 도착지 설정", "경로 설정", Icons.Filled.LocationOn),
    Account("계정", "마이페이지", "마이페이지", Icons.Filled.Person),
    Settings("설정", "앱 설정", "설정", Icons.Filled.Settings),
}

/**
 * 메인 화면 (v2): 전체가 지도 영역, 오른쪽 아래에 원통 모양 메뉴.
 * - 막대 하나에 메뉴 하나. 위아래로 밀면 원통이 돌듯 끝없이 넘어감
 * - 경로 설정: 화면 1/3 창이 열리고, 위로 끌어올리면 상세정보
 * - 나머지: 누른 막대가 커지며 화면을 채우고 해당 화면이 나옴
 * - 지도 위: 내 위치 핀, 길안내 (위쪽 배너 또는 오른쪽 위 작은 칸, 설정에서 고름)
 * 화면에 보이는 값은 모두 [state] 에서 옴 (길안내 · 로그인 · 마이페이지 · 지도 · 설정 · 경로 검색)
 */
@Composable
fun MainScreen(modifier: Modifier = Modifier, state: AppState = remember { AppState() }) {
    val guide = state.guide
    val settings = state.settings
    val density = LocalDensity.current
    val softShadow = remember(density) { SoftShadow(density, base = BAR_H, corner = CORNER) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    // 위치 계산용 참조 (상태가 아니므로 바뀌어도 재구성되지 않음)
    val rootCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    val statusTop = WindowInsets.statusBars.getTop(density)

    // 계정/설정: 막대가 커지며 화면을 채움
    var openPage by remember { mutableStateOf<NavItem?>(null) }
    var pageFrom by remember { mutableStateOf(Rect.Zero) }
    val pageProgress = remember { Animatable(0f) }

    // 현재 위치: 핀은 guide.myLocation 을 따라 늘 표시. 현재 위치 버튼을 누르면 핀 아래에서 고리가 퍼짐
    val hasLocation by remember(guide) { derivedStateOf { guide.myLocation != null } }   // 위치가 생기거나 없어질 때만 다시 그림
    val locationPulse = remember { Animatable(1f) }

    // 메뉴 모아보기: 겹쳐진 막대들을 위로 펼쳐서 한 번에 보여줌
    var overview by remember { mutableStateOf(false) }
    val overviewAnim = animateFloatAsState(
        targetValue = if (overview) 1f else 0f,
        animationSpec = tween(if (overview) 420 else 320, easing = FastOutSlowInEasing),
        label = "overview",
    )
    val overviewShown by remember { derivedStateOf { overviewAnim.value > 0f } }
    val drum = remember { DrumHandle() }

    // 경로 설정: 화면 1/3 창, 위로 끌면 상세정보
    var routeOpen by remember { mutableStateOf(false) }
    var routeFrom by remember { mutableStateOf(Rect.Zero) }
    val routeReveal = remember { Animatable(0f) }   // 0 = 막대, 1 = 창
    val sheetTop = remember { Animatable(0f) }       // 창 윗변 위치 (px)
    val screenH = rootSize.height.toFloat()
    val thirdTop = screenH - max(screenH / 3f, with(density) { SHEET_MIN.toPx() })
    val fullTop = statusTop + with(density) { 12.dp.toPx() }
    val lowestTop = screenH - with(density) { 96.dp.toPx() }

    val selectItem: (NavItem, LayoutCoordinates) -> Unit = { item, bar ->
        val root = rootCoords[0]
        if (root != null && bar.isAttached && openPage == null && !routeOpen) {
            focusManager.clearFocus()
            val rect = root.localBoundingBoxOf(bar)
            if (item == NavItem.Route) {
                routeFrom = rect
                routeOpen = true
                scope.launch {
                    sheetTop.snapTo(thirdTop)
                    routeReveal.snapTo(0f)
                    routeReveal.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
                }
            } else {
                pageFrom = rect
                openPage = item
                scope.launch {
                    pageProgress.snapTo(0f)
                    pageProgress.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
                }
            }
        }
    }
    // 닫힐 때는 지금 앞에 있는 막대 자리로 줄어듦 (모아보기에서 골랐으면 그 막대가 앞에 와 있음)
    val frontRect: () -> Rect? = {
        val root = rootCoords[0]
        val bar = drum.frontCoords()
        if (root != null && bar != null && bar.isAttached) root.localBoundingBoxOf(bar) else null
    }
    val closePage: () -> Unit = {
        if (openPage != null) {
            frontRect()?.let { pageFrom = it }
            scope.launch {
                pageProgress.animateTo(0f, tween(380, easing = FastOutSlowInEasing))
                openPage = null
            }
        }
    }
    val closeRoute: () -> Unit = {
        if (routeOpen) {
            focusManager.clearFocus()
            frontRect()?.let { routeFrom = it }
            scope.launch {
                routeReveal.animateTo(0f, tween(360, easing = FastOutSlowInEasing))
                routeOpen = false
            }
        }
    }
    val moveSheet: (Float) -> Unit = { target ->
        scope.launch { sheetTop.animateTo(target, spring(dampingRatio = 0.9f, stiffness = 500f)) }
    }
    // 손을 뗐을 때: 많이 내리면 닫고, 아니면 1/3 또는 전체 중 가까운 쪽으로
    val settleSheet: (Float) -> Unit = { velocity ->
        val top = sheetTop.value
        val closeLine = thirdTop + (screenH - thirdTop) * 0.35f
        when {
            top > closeLine || (velocity > 1500f && top > thirdTop - 1f) -> closeRoute()
            velocity < -800f -> moveSheet(fullTop)
            velocity > 800f -> moveSheet(thirdTop)
            else -> moveSheet(if (top < (thirdTop + fullTop) / 2f) fullTop else thirdTop)
        }
    }

    // 모아보기에서 고르면: 고른 막대 자리에서 바로 열리고, 모아보기가 접힌 뒤 그 메뉴가 앞으로 옴
    val pickFromOverview: (NavItem, LayoutCoordinates) -> Unit = { item, bar ->
        selectItem(item, bar)
        overview = false
        drum.bringToFront(item)
    }

    BackHandler(enabled = openPage != null || routeOpen || overview) {
        when {
            openPage != null -> closePage()
            routeOpen && sheetTop.value < thirdTop - 1f -> moveSheet(thirdTop)   // 상세정보 보는 중이면 1/3로
            routeOpen -> closeRoute()
            else -> overview = false
        }
    }

    // 화면 꺼짐 방지: 길안내 중이고 설정이 켜져 있으면 화면을 켜 둠
    val view = LocalView.current
    val guiding by remember(guide) { derivedStateOf { guide.next != null } }
    val keepOn = settings.keepScreenOn && guiding
    DisposableEffect(view, keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    CompositionLocalProvider(LocalSoftShadow provides softShadow, LocalDistanceUnit provides settings.unit) {
        VoiceGuide(guide, enabled = settings.voiceGuide)
        Box(
            modifier
                .fillMaxSize()
                .onPlaced { rootCoords[0] = it }
                .onSizeChanged { rootSize = it }
        ) {
            // 지도 (실제 지도 SDK 를 붙이면 이 자리에 지도 화면). 자전거도로 · 대여소는 설정에서 켜고 끔
            TempMapView(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) { detectTapGestures { focusManager.clearFocus() } },
                bikeLanes = settings.bikeLanes,
                stations = if (settings.rentalStations) state.map.rentalStations else emptyList(),
            )
            MyLocationPin(
                location = { guide.myLocation },
                toScreen = TempMap::toScreen,
                pulse = { locationPulse.value },
                modifier = Modifier.fillMaxSize(),
            )
            // 길안내 (다음 안내가 있을 때만): 위쪽 배너 또는 오른쪽 위 작은 칸
            when (settings.guideStyle) {
                GuideStyle.Banner -> GuideBanner(guide, Modifier.align(Alignment.TopCenter))
                GuideStyle.Box -> TurnBox(
                    next = { guide.next },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 12.dp, end = EDGE),
                )
            }
            // 모아보기 중에는 뒤를 살짝 어둡게, 빈 곳을 누르면 닫힘
            if (overviewShown) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = overviewAnim.value }
                        .background(Soft.Dark.copy(alpha = if (Soft.isBlack) 0.55f else 0.3f))
                        .pointerInput(Unit) { detectTapGestures { overview = false } }
                )
            }

            // 원통 메뉴 오른쪽 위 작은 버튼들: 모아보기 · 현재 위치 (모아보기를 펼치면 목록 위로 같이 올라감)
            val lift = with(density) { (LIST_H - DRUM_H).toPx() }
            Row(
                Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = EDGE, bottom = EDGE + DRUM_H + 12.dp)
                    .graphicsLayer { translationY = -lift * overviewAnim.value },
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OverviewButton(open = overview, onClick = { overview = !overview })
                MyLocationButton(
                    active = hasLocation,
                    onClick = {
                        // 핀 아래 고리 (실제 지도를 붙이면 여기서 지도를 내 위치로 옮기기)
                        scope.launch {
                            locationPulse.snapTo(0f)
                            locationPulse.animateTo(1f, tween(900, easing = LinearOutSlowInEasing))
                        }
                    },
                )
            }

            NavDrum(
                overview = { overviewAnim.value },
                overviewOn = overview,
                handle = drum,
                onPick = pickFromOverview,
                onSelect = selectItem,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = EDGE, bottom = EDGE)
                    .fillMaxWidth(DRUM_WIDTH),
            )

            if (routeOpen) {
                RouteSheet(
                    from = routeFrom,
                    reveal = { routeReveal.value },
                    top = { sheetTop.value },
                    expand = { ((thirdTop - sheetTop.value) / (thirdTop - fullTop)).coerceIn(0f, 1f) },
                    onDrag = { dy -> scope.launch { sheetTop.snapTo((sheetTop.value + dy).coerceIn(fullTop, lowestTop)) } },
                    onDragStopped = settleSheet,
                    onExpand = { moveSheet(fullTop) },
                    onClose = closeRoute,
                    state = state,
                    onStart = { plan ->
                        guide.startRoute(plan.points)    // 길안내 시작 → 배너(또는 작은 칸)에 안내
                        closeRoute()
                    },
                )
            }

            openPage?.let { page ->
                // 커지는 화면의 바깥 그림자: 화면 레이어는 모양대로 잘리므로 그 밖(뒤)에 따로 그림
                Spacer(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer()
                        .drawBehind {
                            val p = pageProgress.value
                            if (p < 1f) {
                                val rect = lerp(pageFrom, Rect(Offset.Zero, size), p)
                                softShadow.drawRaised(this, rect, alpha = (p * 6f).coerceAtMost(1f) * (1f - p))
                            }
                        }
                )
                PageOverlay(
                    page = page,
                    state = state,
                    from = pageFrom,
                    progress = { pageProgress.value },
                    onBack = closePage,
                )
            }
        }
    }
}

// ───────────────────────── 원통 메뉴 ─────────────────────────

private enum class BarRole { Front, Back, Hidden }

/** 원통 메뉴를 바깥(메인 화면)에서 다루기 위한 손잡이 */
private class DrumHandle {
    /** 지금 앞에 있는 막대의 위치 정보 */
    var frontCoords: () -> LayoutCoordinates? = { null }
    /** 고른 메뉴를 앞으로 가져오기 (모아보기가 다 접힌 뒤에) */
    var bringToFront: (NavItem) -> Unit = {}
}

/**
 * 오른쪽 아래 원통 메뉴. 앞 막대 하나에 메뉴 하나, 뒤쪽 막대들은 위로 살짝 겹쳐 보임.
 * 아래로 밀면 뒤(위)의 막대가 앞으로 내려오고, 위로 밀면 앞 막대가 뒤로 넘어감. 끝없이 반복.
 * 성능: 위치·크기·투명도는 레이어 속성으로만 바뀜 (드래그 중 재구성·재배치 없음).
 */
@Composable
private fun NavDrum(
    overview: () -> Float,
    overviewOn: Boolean,
    handle: DrumHandle,
    onPick: (NavItem, LayoutCoordinates) -> Unit,
    onSelect: (NavItem, LayoutCoordinates) -> Unit,
    modifier: Modifier = Modifier,
) {
    val items = NavItem.entries
    val n = items.size
    var savedFront by rememberSaveable { mutableIntStateOf(0) }
    val pos = remember { Animatable(savedFront.toFloat()) }   // 앞에 있는 항목 번호 (소수 = 도는 중)
    val scope = rememberCoroutineScope()
    val stepPx = with(LocalDensity.current) { DRUM_STEP.toPx() }
    val barCoords = remember { arrayOfNulls<LayoutCoordinates>(n) }
    // 손가락 상태 (상태가 아니므로 바뀌어도 재구성되지 않음): [0] 도는 중에 붙잡음, [1] 끄는 중
    val touch = remember { BooleanArray(2) }
    // 속도 1(칸/초)로 놓았을 때 관성으로 더 도는 거리
    val unitTravel = remember { exponentialDecay<Float>().calculateTargetValue(0f, 1f) }

    /** 막대에 딱 맞춰 멈추기 */
    val snapTo: suspend (Float, Float) -> Unit = { target, velocity ->
        pos.animateTo(target, spring(dampingRatio = 0.9f, stiffness = 700f), initialVelocity = velocity)
        savedFront = target.roundToInt()
    }
    /** 손을 놓은 뒤: 관성으로 돌다가 느려지면 가장 가까운 막대에 맞춰 멈춤 */
    val settle: suspend (Float) -> Unit = { speed ->
        val now = pos.value
        val natural = now + speed * unitTravel / DRUM_FRICTION
        val target = round(natural.coerceIn(now - MAX_SPIN, now + MAX_SPIN))
        val dist = target - now
        if (abs(speed) > SNAP_SPEED && dist * speed > 0f) {
            // 목표 막대에 정확히 닿도록 마찰을 맞춰 감속
            pos.animateDecay(
                speed,
                exponentialDecay(frictionMultiplier = speed * unitTravel / dist, absVelocityThreshold = SNAP_SPEED),
            )
        }
        snapTo(target, pos.velocity)
    }

    // 모아보기: 펼치기 전에 막대 위치를 정확히 맞춤
    val overviewShown by remember { derivedStateOf { overview() > 0f } }
    LaunchedEffect(overviewOn) { if (overviewOn) pos.snapTo(round(pos.value)) }
    handle.frontCoords = { barCoords[Math.floorMod(round(pos.value).toInt(), n)] }
    handle.bringToFront = { item ->
        scope.launch {
            snapshotFlow { overview() }.first { it <= 0f }
            val base = round(pos.value)
            var diff = Math.floorMod(item.ordinal - base.toInt(), n)
            if (diff > n / 2) diff -= n
            pos.snapTo(base + diff)
            savedFront = (base + diff).roundToInt()
        }
    }

    // 그리는 순서 (먼 막대부터, 앞 막대가 맨 위): 순서가 바뀔 때만 재구성
    val order by remember {
        derivedStateOf(structuralEqualityPolicy()) {
            if (overview() > 0f) (0 until n).sortedByDescending { drumSlot(it - pos.value, n) }
            else (0 until n).sortedByDescending { abs(drumRel(it - pos.value, n)) }
        }
    }

    Box(
        modifier
            // 모아보기 중에는 펼친 목록 높이만큼 (아래 기준이라 막대 위치는 그대로)
            .height(if (overviewShown) LIST_H else DRUM_H)
            // 도는 중에 손을 대면 가장 가까운 막대에 바로 맞춰 멈춤 (흐릿한 중간 상태로 서 있지 않게).
            // 이때 누른 막대는 열리지 않음
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    touch[0] = pos.isRunning
                    if (touch[0]) scope.launch { snapTo(round(pos.value), 0f) }
                }
            }
            .draggable(
                orientation = Orientation.Vertical,
                enabled = !overviewShown,
                state = rememberDraggableState { delta -> scope.launch { pos.snapTo(pos.value + delta / stepPx) } },
                onDragStarted = { touch[1] = true },
                onDragStopped = { velocity ->
                    touch[0] = false
                    touch[1] = false
                    settle(velocity / stepPx)
                },
            )
            .semantics { contentDescription = "메뉴. 위아래로 밀어서 바꾸기" }
    ) {
        for (k in order) {
            key(items[k]) {
                val role by remember { derivedStateOf { drumRole(drumRel(k - pos.value, n)) } }
                DrumBar(
                    item = items[k],
                    rel = { drumRel(k - pos.value, n) },
                    back = { drumBackRel(k - pos.value, n) },
                    slot = { drumSlot(k - pos.value, n) },
                    spread = { overviewStagger(overview(), drumSlot(k - pos.value, n)) },
                    interactive = overviewShown || role != BarRole.Hidden,
                    onClick = {
                        when {
                            overviewShown -> barCoords[k]?.let { onPick(items[k], it) }   // 모아보기에서 바로 고름
                            touch[0] -> touch[0] = false   // 도는 걸 멈추려고 누른 것: 열지 않음
                            role == BarRole.Front -> barCoords[k]?.let { onSelect(items[k], it) }
                            // 뒤쪽 막대를 누르면 그 막대가 앞으로 오도록 돌림
                            else -> scope.launch { snapTo(round(pos.value + drumRel(k - pos.value, n)), 0f) }
                        }
                    },
                    onPlaced = { barCoords[k] = it },
                    modifier = Modifier.align(Alignment.BottomEnd),
                )
            }
        }
    }
}

/** 막대가 앞 막대 기준 몇 칸 뒤(+, 위)/아래(-)에 있는지. (-1.5, n-1.5] 로 감싸서 끝없이 반복 */
private fun drumRel(x: Float, n: Int): Float {
    // 범위 (VISIBLE_BACK + 0.5 - n, VISIBLE_BACK + 0.5]: 항목이 3개여도 뒤쪽 막대 2개가 보이고,
    // 앞에서 말려 들어간 막대는 안 보이는 끝(맨 뒤)으로 이어짐
    val shift = n - (VISIBLE_BACK + 0.5f)
    var v = (x + shift) % n
    if (v <= 0f) v += n
    return v - shift
}

/** 앞 막대 기준 뒤쪽으로만 센 거리 [0, n): 모아보기로 펼칠 때 출발 위치 계산용 */
private fun drumBackRel(x: Float, n: Int): Float {
    val v = x % n
    return if (v < 0f) v + n else v
}

/** 모아보기 목록에서의 자리 (0 = 맨 아래 앞 막대, 1, 2, 3 = 그 위로 차례로) */
private fun drumSlot(x: Float, n: Int): Int = Math.floorMod(round(x).toInt(), n)

/** 모아보기 진행도를 자리마다 조금씩 늦게 → 아래 막대부터 차례로 펼쳐지고, 접을 땐 위에서부터 */
private fun overviewStagger(progress: Float, slot: Int): Float {
    val span = 1f - OVERVIEW_STAGGER * 3f
    return ((progress - slot * OVERVIEW_STAGGER) / span).coerceIn(0f, 1f)
}

private fun drumRole(d: Float): BarRole = when {
    abs(d) < 0.5f -> BarRole.Front
    d >= 0.5f && d <= VISIBLE_BACK + 0.25f -> BarRole.Back
    else -> BarRole.Hidden
}

/** 뒤로 갈수록 작게(오른쪽 아래 기준), 아래로 말려 들어갈 땐 살짝 작게 */
private fun drumScale(d: Float): Float =
    if (d >= 0f) 1f - BACK_SHRINK * min(d, VISIBLE_BACK + 0.5f) else 1f - 0.05f * min(-d, 1f)

/** 뒤로 갈수록 위로 (앞 막대 위로 PEEK 만큼씩 보이게), 아래로 말려 들어갈 땐 아래로 */
private fun drumOffsetY(d: Float, scale: Float, barH: Float, peek: Float, drop: Float): Float =
    if (d >= 0f) -(peek * min(d, VISIBLE_BACK + 0.5f) + (1f - scale) * barH) else drop * min(-d, 1.5f)

/** 보이는 범위를 벗어나는 막대는 서서히 사라짐 (갑자기 튀지 않게) */
private fun drumAlpha(d: Float): Float = when {
    d > VISIBLE_BACK -> (1f - (d - VISIBLE_BACK) / 0.5f).coerceIn(0f, 1f)
    d >= 0f -> 1f
    else -> (1f + 2f * d).coerceIn(0f, 1f)
}

private fun drumShade(d: Float): Float = if (d > 0f) BACK_SHADE * min(d, VISIBLE_BACK) else 0f

/**
 * 막대 안 글자·아이콘: 앞 자리 근처에서는 바로 또렷하게, 뒤로 넘어가거나 아래로 말려 들어가면 금방 흐려짐
 * (중간에 두 글자가 겹치지 않게)
 */
private fun drumContentAlpha(d: Float): Float =
    if (d > 0f) (1f - (d - 0.1f) * 1.8f).coerceIn(0f, 1f) else (1f + (d + 0.05f) * 3.5f).coerceIn(0f, 1f)

@Composable
private fun DrumBar(
    item: NavItem,
    rel: () -> Float,
    back: () -> Float,
    slot: () -> Int,
    spread: () -> Float,
    interactive: Boolean,
    onClick: () -> Unit,
    onPlaced: (LayoutCoordinates) -> Unit,
    modifier: Modifier = Modifier,
) {
    val softShadow = LocalSoftShadow.current
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    // 원통 위 위치: 모아보기로 펼치는 중이면 뒤쪽 기준 거리로 (숨은 막대는 맨 뒤에서 나오게)
    val depth: () -> Float = { if (spread() > 0f) back() else rel() }
    Box(
        modifier
            .fillMaxWidth()
            .height(BAR_H)
            .graphicsLayer {
                val e = spread()                         // 0 = 원통, 1 = 모아보기 목록
                val d = depth()
                val s0 = drumScale(d)
                val s = mix(s0, 1f, e)
                scaleX = s
                scaleY = s
                translationY = mix(
                    drumOffsetY(d, s0, BAR_H.toPx(), PEEK.toPx(), DROP.toPx()),
                    -slot() * (BAR_H + LIST_GAP).toPx(),
                    e,
                )
                alpha = mix(drumAlpha(d), 1f, e)
                transformOrigin = TransformOrigin(1f, 1f)
                // 투명도를 그리기마다 적용해서 막대 밖으로 퍼진 그림자가 잘리지 않게
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
            .onPlaced(onPlaced)
            .drawBehind { softShadow.drawRaised(this, size.toRect(), alpha = 1f - press.value) }
            .clip(CardShape)
            .background(Soft.Base)
            .softPressedInset(CardShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, enabled = interactive, onClick = onClick),
    ) {
        // 뒤로 넘어가면 글자·아이콘은 흐려져서 깔끔한 띠만 보이게 (레이어 투명도만 바뀜)
        BarContent(item, Modifier.graphicsLayer { alpha = mix(drumContentAlpha(depth()), 1f, spread()) })
        // 뒤로 갈수록 살짝 어둡게 (레이어 투명도만 바뀜)
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer { alpha = drumShade(depth()) * (1f - spread()) }
                .background(Soft.Dark)
        )
    }
}

/** 막대 안쪽: 왼쪽에 이름, 오른쪽 끝 오목한 작은 네모 안에 아이콘 */
@Composable
private fun BarContent(item: NavItem, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxSize()
            .padding(start = 20.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Soft.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(item.subtitle, color = Soft.TextSub, fontSize = 12.sp, maxLines = 1)
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(22.dp))
        }
    }
}

/** 누름 상태(0 = 볼록, 1 = 눌림)를 짧게 애니메이션 */
@Composable
private fun rememberPress(interaction: MutableInteractionSource): State<Float> {
    val pressed by interaction.collectIsPressedAsState()
    return animateFloatAsState(if (pressed) 1f else 0f, tween(PRESS_MS), label = "press")
}

// ───────────────────────── 경로 설정 창 ─────────────────────────

/**
 * 경로 설정 창: 막대에서 커져서 화면 아래 1/3 을 채우고, 위로 끌어올리면 상세정보까지 보임.
 * 성능: 창 크기는 모양(보이는 영역)과 내용 이동으로만 바뀜 → 끄는 동안 재배치 없음.
 */
@Composable
private fun RouteSheet(
    from: Rect,
    reveal: () -> Float,
    top: () -> Float,
    expand: () -> Float,
    onDrag: (Float) -> Unit,
    onDragStopped: (Float) -> Unit,
    onExpand: () -> Unit,
    onClose: () -> Unit,
    state: AppState,
    onStart: (RoutePlan) -> Unit,
) {
    val softShadow = LocalSoftShadow.current
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current
    val sheetCorner = with(density) { SHEET_CORNER.toPx() }
    val barCorner = with(density) { CORNER.toPx() }
    val barW = with(density) { from.width.toDp() }
    val barH = with(density) { from.height.toDp() }
    // 지금 보이는 창 영역 (막대 → 창으로 커지는 중이면 그 사이). 아래쪽 모서리는 화면 밖으로
    fun visible(size: Size): Rect =
        lerp(from, Rect(0f, top(), size.width, size.height + sheetCorner), reveal())

    // 창 바깥 그림자 (창 레이어는 모양대로 잘리므로 그 밖(뒤)에 따로 그림)
    Spacer(
        Modifier
            .fillMaxSize()
            .graphicsLayer()
            .drawBehind { softShadow.drawLifted(this, visible(size)) }
    )
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                shape = RevealShape(visible(size), mix(barCorner, sheetCorner, reveal()))
                clip = true
            }
            .background(Soft.Base)
            .pointerInput(Unit) { detectTapGestures { focusManager.clearFocus() } } // 창 안의 터치가 지도로 넘어가지 않게, 빈 곳을 누르면 입력 끝
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { onDrag(it) },
                onDragStopped = { onDragStopped(it) },
            )
    ) {
        // 처음엔 누른 막대 모양 그대로 보이다가 빠르게 사라짐
        BarContent(
            NavItem.Route,
            Modifier
                .offset { IntOffset(from.left.roundToInt(), from.top.roundToInt()) }
                .size(barW, barH)
                .graphicsLayer { alpha = (1f - reveal() * 4f).coerceIn(0f, 1f) },
        )
        SheetContent(
            expand = expand,
            state = state,
            onStart = onStart,
            onExpand = onExpand,
            onClose = onClose,
            modifier = Modifier.graphicsLayer {
                val p = reveal()
                translationY = mix(from.top, top(), p)   // 내용은 창 윗변을 따라 움직임
                alpha = ((p - 0.45f) / 0.55f).coerceIn(0f, 1f)
            },
        )
    }
}

/** 지금 글자를 넣고 있는 입력칸 */
private enum class RouteInput { Start, Dest }

@Composable
private fun SheetContent(
    expand: () -> Float,
    state: AppState,
    onStart: (RoutePlan) -> Unit,
    onExpand: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val profile = state.profile
    var start by rememberSaveable { mutableStateOf("") }
    var dest by rememberSaveable { mutableStateOf("") }
    var option by rememberSaveable { mutableStateOf(RouteOption.Fast) }
    var plan by remember { mutableStateOf<RoutePlan?>(null) }
    var searching by remember { mutableStateOf(false) }
    var problem by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<RouteInput?>(null) }        // 글자를 넣는 중인 칸 (없으면 null)
    var found by remember { mutableStateOf("" to emptyList<Place>()) }   // (찾은 글자, 장소 후보)
    val unit = LocalDistanceUnit.current
    val focusManager = LocalFocusManager.current
    val startFocus = remember { FocusRequester() }
    val destFocus = remember { FocusRequester() }

    // 입력 중에 뒤로 가기: 입력만 끝냄 (후보 닫기)
    BackHandler(enabled = editing != null) { focusManager.clearFocus() }

    // 장소 후보: 칸에 글자를 넣으면 잠시 뒤 장소 검색 (네이버 지도처럼)
    val query = when (editing) {
        RouteInput.Start -> start
        RouteInput.Dest -> dest
        null -> ""
    }.trim()
    LaunchedEffect(editing, query) {
        if (editing == null || query.isEmpty()) {
            found = "" to emptyList()
            return@LaunchedEffect
        }
        delay(SUGGEST_DELAY_MS)
        val places = try {
            state.searchPlaces(query)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            emptyList()
        }
        found = query to places
    }

    // 도착지가 정해지면 (입력을 마치면) 경로 검색 → 예상 정보 · 안내 시작 (출발지가 비면 내 위치에서)
    LaunchedEffect(start, dest, option, editing) {
        plan = null
        problem = null
        searching = false
        if (editing != null || dest.isBlank()) return@LaunchedEffect
        searching = true
        try {
            plan = state.searchRoute(start.trim().ifEmpty { null }, dest.trim(), option)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            problem = e.message ?: "경로를 찾지 못했어요"
        } finally {
            searching = false
        }
    }

    // 후보를 고르면: 출발지면 도착지 칸으로 넘어가고, 도착지면 입력을 마침 → 경로 검색
    val pick: (RouteInput, String, Place?) -> Unit = { input, text, place ->
        if (place != null) profile.recentPlaces = (listOf(place) + profile.recentPlaces.filter { it.name != place.name }).take(RECENT_MAX)
        when (input) {
            RouteInput.Start -> {
                start = text
                if (dest.isBlank()) destFocus.requestFocus() else focusManager.clearFocus()
            }
            RouteInput.Dest -> {
                dest = text
                focusManager.clearFocus()
            }
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        // 손잡이
        Box(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(40.dp, 5.dp)
                    .clip(PillShape)
                    .background(Soft.Base)
                    .softInset(PillShape, offset = 1.dp, blur = 2.dp)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("경로 설정", color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            SoftIconButton(onClick = onClose, size = 40.dp) {
                Icon(Icons.Filled.Close, contentDescription = "닫기", tint = Soft.TextSub, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(12.dp))

        // 출발·도착을 하나로 합친 오목한 입력칸 (가운데 선으로 구분)
        Column(
            Modifier
                .fillMaxWidth()
                .height(FIELD_H)
                .clip(FieldShape)
                .background(Soft.Base)
                .softInset(FieldShape)
        ) {
            RouteField(
                start, { start = it }, "내 위치에서 출발",
                focusRequester = startFocus,
                imeAction = ImeAction.Next,
                onImeAction = { destFocus.requestFocus() },
                onFocusChange = { focused ->
                    if (focused) {
                        editing = RouteInput.Start
                        onExpand()
                    } else if (editing == RouteInput.Start) {
                        editing = null
                    }
                },
            ) {
                Box(
                    Modifier
                        .size(11.dp)
                        .border(2.5.dp, Soft.Accent, CircleShape)
                )
            }
            GrooveDivider()
            RouteField(
                dest, { dest = it }, "도착지를 입력하세요",
                focusRequester = destFocus,
                imeAction = ImeAction.Done,
                onImeAction = { focusManager.clearFocus() },
                onFocusChange = { focused ->
                    if (focused) {
                        editing = RouteInput.Dest
                        onExpand()
                    } else if (editing == RouteInput.Dest) {
                        editing = null
                    }
                },
            ) {
                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(18.dp))
            }
        }

        val input = editing
        if (input != null) {
            // 입력 중: 장소 후보
            PlaceSuggestions(
                query = query,
                found = found,
                showMyLocation = input == RouteInput.Start,
                favorites = profile.favorites,
                recent = profile.recentPlaces,
                here = { state.guide.myLocation },
                onPick = { text, place -> pick(input, text, place) },
            )
        } else {
            // 경로를 찾으면: 안내 시작
            plan?.let { p ->
                Spacer(Modifier.height(12.dp))
                SoftWideButton("안내 시작 · ${formatDistance(p.distanceMeters, unit)} · ${formatMinutes(p.minutes)}") { onStart(p) }
            }

            // 위로 올리면 상세정보 (펼칠수록 사라짐)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .graphicsLayer { alpha = (1f - expand() * 3f).coerceIn(0f, 1f) }
                    .clickable(interactionSource = null, indication = null, onClick = onExpand),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = null, tint = Soft.TextHint, modifier = Modifier.size(18.dp))
                Text("위로 올리면 상세정보", color = Soft.TextHint, fontSize = 12.sp)
            }

            // ── 상세정보 (위로 끌어올리면 보임) ──
            SectionTitle("경로 옵션")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RouteOption.entries.forEach { o ->
                    OptionChip(o.label, selected = option == o) { option = o }
                }
            }
            SectionTitle("예상 정보")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile("거리", plan?.let { formatDistance(it.distanceMeters, unit) } ?: "—")
                MetricTile("시간", plan?.let { formatMinutes(it.minutes) } ?: "—")
            }
            Text(
                when {
                    searching -> "경로를 찾는 중이에요"
                    problem != null -> problem ?: ""
                    plan != null -> "${option.label} 기준이에요"
                    else -> "도착지를 입력하면 표시돼요"
                },
                color = Soft.TextHint,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp),
            )
            SectionTitle("즐겨찾기")
            if (profile.favorites.isEmpty()) {
                Text("즐겨찾는 장소가 없어요", color = Soft.TextHint, fontSize = 13.sp)
            } else {
                // 누르면 그 주소가 도착지로 (출발지는 그대로, 비어 있으면 내 위치)
                profile.favorites.chunked(2).forEachIndexed { i, row ->
                    if (i > 0) Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { place -> FavoriteTile(place) { dest = place.address } }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/** 장소 후보 한 줄: 아이콘, 이름 (찾은 글자는 파랗게), 주소, 내 위치에서 거리 */
private class Suggestion(val icon: ImageVector, val title: String, val subtitle: String?, val fill: String, val place: Place?)

/**
 * 장소 후보 목록 (입력 중, 입력칸 아래). 글자가 없으면 내 위치 · 즐겨찾기 · 최근 장소, 있으면 장소 검색 결과.
 * [onPick] 에는 (입력칸에 넣을 글자, 최근 장소에 남길 장소) 를 넘김.
 */
@Composable
private fun PlaceSuggestions(
    query: String,
    found: Pair<String, List<Place>>,
    showMyLocation: Boolean,
    favorites: List<Place>,
    recent: List<Place>,
    here: () -> GeoPoint?,
    onPick: (String, Place?) -> Unit,
) {
    val unit = LocalDistanceUnit.current
    val items = buildList {
        if (query.isEmpty()) {
            if (showMyLocation) add(Suggestion(TargetIcon, "내 위치", "지금 있는 곳에서 출발", fill = "", place = null))
            favorites.forEach { add(Suggestion(if (it.name == "집") Icons.Filled.Home else Icons.Filled.Star, it.name, it.address, fill = it.address, place = null)) }
            recent.filter { r -> favorites.none { it.name == r.name } }.take(3)
                .forEach { add(Suggestion(ClockIcon, it.name, it.address, fill = it.name, place = it)) }
        } else if (found.first == query) {
            found.second.take(MAX_SUGGESTIONS).forEach { add(Suggestion(Icons.Filled.Place, it.name, it.address, fill = it.name, place = it)) }
        }
    }
    Spacer(Modifier.height(14.dp))
    when {
        items.isNotEmpty() -> SoftCard {
            items.forEachIndexed { i, item ->
                if (i > 0) GrooveDivider()
                val distance = item.place?.location?.let { to -> here()?.let { from -> formatDistance(distanceMeters(from, to).roundToInt(), unit) } }
                SuggestionRow(item, query, distance) { onPick(item.fill, item.place) }
            }
        }
        query.isNotEmpty() && found.first == query ->
            Text("'$query' 에 맞는 장소가 없어요", color = Soft.TextHint, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp))
        query.isEmpty() ->
            Text("장소 이름을 입력하세요", color = Soft.TextHint, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
private fun SuggestionRow(item: Suggestion, query: String, distance: String?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .semantics(mergeDescendants = true) {},
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, contentDescription = null, tint = if (item.icon == ClockIcon) Soft.TextSub else Soft.Accent, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(highlight(item.title, query), color = Soft.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            item.subtitle?.let { Text(it, color = Soft.TextSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
        distance?.let {
            Spacer(Modifier.width(8.dp))
            Text(it, color = Soft.TextHint, fontSize = 12.sp)
        }
    }
}

/** [text] 안의 [query] 부분만 파랗고 굵게 */
private fun highlight(text: String, query: String): AnnotatedString = buildAnnotatedString {
    val i = if (query.isEmpty()) -1 else text.indexOf(query, ignoreCase = true)
    if (i < 0) {
        append(text)
    } else {
        append(text.substring(0, i))
        withStyle(SpanStyle(color = Soft.Accent, fontWeight = FontWeight.SemiBold)) { append(text.substring(i, i + query.length)) }
        append(text.substring(i + query.length))
    }
}

/** 최근 장소 아이콘 (시계) */
private val ClockIcon: ImageVector by lazy {
    ImageVector.Builder("clock", 24.dp, 24.dp, 24f, 24f)
        .path(stroke = SolidColor(Color.Black), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round) {
            moveTo(20f, 12f)
            arcTo(8f, 8f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 4f, y1 = 12f)
            arcTo(8f, 8f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 20f, y1 = 12f)
            moveTo(12f, 7.5f)
            lineTo(12f, 12f)
            lineTo(15f, 14f)
        }
        .build()
}

/** 내 위치 아이콘 (조준선) */
private val TargetIcon: ImageVector by lazy {
    ImageVector.Builder("target", 24.dp, 24.dp, 24f, 24f)
        .path(stroke = SolidColor(Color.Black), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round) {
            moveTo(18.5f, 12f)
            arcTo(6.5f, 6.5f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 5.5f, y1 = 12f)
            arcTo(6.5f, 6.5f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 18.5f, y1 = 12f)
            moveTo(12f, 2f); lineTo(12f, 4.5f)
            moveTo(12f, 19.5f); lineTo(12f, 22f)
            moveTo(2f, 12f); lineTo(4.5f, 12f)
            moveTo(19.5f, 12f); lineTo(22f, 12f)
        }
        .path(fill = SolidColor(Color.Black)) {
            moveTo(14.5f, 12f)
            arcTo(2.5f, 2.5f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 9.5f, y1 = 12f)
            arcTo(2.5f, 2.5f, 0f, isMoreThanHalf = true, isPositiveArc = true, x1 = 14.5f, y1 = 12f)
        }
        .build()
}

/** 가로로 꽉 찬 소프트 버튼 (누르면 오목하게) */
@Composable
private fun SoftWideButton(text: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .softPressable(FieldShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Soft.Accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = Soft.Text,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp,
        modifier = Modifier.padding(top = 26.dp, bottom = 12.dp),
    )
}

/** 선택하면 오목하게 들어가는 옵션 */
@Composable
private fun RowScope.OptionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val press by animateFloatAsState(if (selected) 1f else 0f, tween(160), label = "chip")
    Box(
        Modifier
            .weight(1f)
            .height(40.dp)
            .softPressable(PillShape) { press }
            .clickable(interactionSource = null, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) Soft.Accent else Soft.TextSub,
            fontSize = 12.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
        )
    }
}

@Composable
private fun RowScope.MetricTile(label: String, value: String) {
    Column(
        Modifier
            .weight(1f)
            .height(76.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Soft.TextSub, fontSize = 12.sp)
        Text(value, color = Soft.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RowScope.FavoriteTile(place: Place, onClick: () -> Unit) {
    val icon = if (place.name == "집") Icons.Filled.Home else Icons.Filled.Place
    Row(
        Modifier
            .weight(1f)
            .height(64.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .clickable(interactionSource = null, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(place.name, color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(place.address, color = Soft.TextSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** 구분선: 어두운 선 아래 밝은 선을 겹쳐 살짝 파인 홈처럼 보이게 */
@Composable
private fun GrooveDivider(inset: Dp = 16.dp) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = inset)
    ) {
        Spacer(Modifier.fillMaxWidth().height(DIVIDER / 2).background(DividerDark))
        Spacer(Modifier.fillMaxWidth().height(DIVIDER / 2).background(Soft.Light))
    }
}

/** 합친 입력칸 안의 한 줄 (출발 또는 도착). 누르면 창을 끝까지 펼쳐 키보드에 가리지 않게 함 */
@Composable
private fun RouteField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    focusRequester: FocusRequester,
    imeAction: ImeAction,
    onImeAction: () -> Unit,
    onFocusChange: (Boolean) -> Unit,
    leading: @Composable () -> Unit,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = FieldTextStyle,
        cursorBrush = CursorBrush,
        keyboardOptions = KeyboardOptions(imeAction = imeAction),
        keyboardActions = KeyboardActions(onAny = { onImeAction() }),
        modifier = Modifier
            .fillMaxWidth()
            .height(ROW)
            .focusRequester(focusRequester)
            .onFocusChanged { onFocusChange(it.isFocused) },
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // 아이콘 폭이 달라도 두 줄의 글자 시작 위치가 맞도록 같은 폭 칸 가운데에 둠
                Box(Modifier.width(20.dp), contentAlignment = Alignment.Center) { leading() }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = Soft.TextHint, fontSize = 14.sp)
                    inner()
                }
            }
        },
    )
}

// ───────────────────────── 화면 채우기 (계정/설정) ─────────────────────────

/** 누른 막대가 커지면서 화면 전체를 채우고, 그 안에 해당 화면이 나타남 */
@Composable
private fun PageOverlay(
    page: NavItem,
    state: AppState,
    from: Rect,
    progress: () -> Float,
    onBack: () -> Unit,
) {
    val density = LocalDensity.current
    val barW = with(density) { from.width.toDp() }
    val barH = with(density) { from.height.toDp() }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = progress()
                shape = RevealShape(
                    lerp(from, Rect(0f, 0f, size.width, size.height), p),
                    CORNER.toPx() * (1f - p),
                )
                clip = true
            }
            .background(Soft.Base)
            .pointerInput(Unit) { detectTapGestures() } // 뒤의 지도/메뉴로 터치가 넘어가지 않게
    ) {
        // 처음엔 누른 막대 모양 그대로 보이다가 빠르게 사라짐
        BarContent(
            page,
            Modifier
                .offset { IntOffset(from.left.roundToInt(), from.top.roundToInt()) }
                .size(barW, barH)
                .graphicsLayer { alpha = (1f - progress() * 4f).coerceIn(0f, 1f) },
        )
        PageContent(
            page = page,
            state = state,
            onBack = onBack,
            modifier = Modifier.graphicsLayer { alpha = ((progress() - 0.3f) / 0.7f).coerceIn(0f, 1f) },
        )
    }
}

/** 레이어 안의 [rect] 영역만 보이게 하는 둥근 사각형 모양 */
private class RevealShape(private val rect: Rect, private val radius: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Rounded(RoundRect(rect, CornerRadius(radius)))
}

private fun mix(start: Float, stop: Float, fraction: Float) = start + (stop - start) * fraction

/** 계정(마이페이지)/설정 화면 */
@Composable
private fun PageContent(
    page: NavItem,
    state: AppState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // 마이페이지 안의 로그인 화면: '로그인' 버튼으로 열리고, 뒤로 가면 마이페이지로
    var login by remember(page) { mutableStateOf(false) }
    BackHandler(enabled = login) { login = false }
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = EDGE, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SoftIconButton(onClick = { if (login) login = false else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "뒤로", tint = Soft.Text)
            }
            Spacer(Modifier.width(18.dp))
            Text(if (login) "로그인" else page.pageTitle, color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        when (page) {
            NavItem.Account -> AnimatedContent(
                targetState = login,
                transitionSpec = {
                    val dir = if (targetState) 1 else -1     // 로그인으로 갈 땐 오른쪽에서, 돌아올 땐 왼쪽에서
                    (slideInHorizontally(tween(300)) { it / 4 * dir } + fadeIn(tween(220, delayMillis = 60))) togetherWith
                        (slideOutHorizontally(tween(300)) { -it / 4 * dir } + fadeOut(tween(160)))
                },
                label = "login",
            ) { showLogin ->
                if (showLogin) LoginBody(state.account, onDone = { login = false }) else MyPageBody(state, onLogin = { login = true })
            }
            NavItem.Settings -> SettingsBody(state.settings)
            NavItem.Route -> Unit   // 경로 설정은 페이지가 아니라 아래 창으로 열림
        }
    }
}

/** 마이페이지 (임시 내용) */
@Composable
private fun MyPageBody(state: AppState, onLogin: () -> Unit) {
    val account = state.account
    val profile = state.profile
    val settings = state.settings
    val unit = LocalDistanceUnit.current
    val user = account.user
    val scope = rememberCoroutineScope()
    PageBody {
        SoftCard {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Soft.Base)
                        .softInset(CircleShape, offset = 3.dp, blur = 5.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(user?.name ?: "자전거 라이더", color = Soft.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (user != null) user.email ?: "카카오 계정" else "로그인하고 기록을 저장해요",
                        color = Soft.TextSub, fontSize = 13.sp,
                    )
                }
                // 로그인 전: 로그인 화면으로 / 로그인 후: 프로필 편집 (account.editProfile)
                if (user == null) SoftTextButton("로그인", onClick = onLogin) else SoftTextButton("편집", onClick = account.editProfile)
            }
        }
        SectionHeader("이번 달 기록")
        val month = profile.monthly ?: RideSummary(0, 0, 0)
        val (distance, distanceUnit) = distanceParts(month.distanceMeters, unit)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("거리", distance, distanceUnit)
            StatTile("주행", "${month.rides}", "회")
            StatTile("시간", "${month.minutes / 60}:${(month.minutes % 60).toString().padStart(2, '0')}", "")
        }
        SectionHeader("최근 주행")
        SoftCard {
            val rides = profile.recentRides.take(3)
            if (rides.isEmpty()) {
                Text("아직 주행 기록이 없어요", color = Soft.TextHint, fontSize = 14.sp, modifier = Modifier.padding(18.dp))
            }
            rides.forEachIndexed { i, ride ->
                if (i > 0) GrooveDivider()
                RideRow(ride.title, "${formatDistance(ride.distanceMeters, unit)} · ${formatMinutes(ride.minutes)}", shortDate(ride.dateMillis))
            }
        }
        SectionHeader("내 정보")
        SoftCard {
            MenuRow("즐겨찾는 장소", profile.favorites.joinToString(" · ") { it.name }.ifEmpty { "없음" })
            GrooveDivider()
            MenuRow("주행 목표", profile.weeklyGoalKm?.let { "주 ${goalText(it, unit)}" } ?: "없음")
            GrooveDivider()
            MenuRow("알림", if (settings.notifications) "켜짐" else "꺼짐") { settings.notifications = !settings.notifications }
            if (user != null) {
                GrooveDivider()
                MenuRow("로그아웃", null) {
                    scope.launch {
                        try {
                            account.logout()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            // 로그아웃 요청이 실패해도 이 기기에서는 로그아웃 처리
                        }
                        account.user = null
                    }
                }
            }
        }
    }
}

/** 설정 (임시 내용: 값은 화면에서만 바뀜) */
@Composable
private fun SettingsBody(s: AppSettings) {
    PageBody {
        SectionHeader("주행")
        SoftCard {
            SettingRow("길안내 표시") {
                SoftSegmented(listOf("배너", "작은 칸"), s.guideStyle.ordinal, itemWidth = 60.dp) { s.guideStyle = GuideStyle.entries[it] }
            }
            GrooveDivider()
            SwitchRow("음성 안내", "갈림길에서 소리로 알려줘요", s.voiceGuide) { s.voiceGuide = it }
            GrooveDivider()
            SwitchRow("화면 꺼짐 방지", "주행 중 화면을 켜 둬요", s.keepScreenOn) { s.keepScreenOn = it }
            GrooveDivider()
            SwitchRow("자동 일시정지", "멈추면 기록도 잠시 멈춰요", s.autoPause) { s.autoPause = it }
        }
        SectionHeader("지도")
        SoftCard {
            SwitchRow("자전거도로 표시", null, s.bikeLanes) { s.bikeLanes = it }
            GrooveDivider()
            SwitchRow("공공자전거 대여소 표시", null, s.rentalStations) { s.rentalStations = it }
        }
        SectionHeader("일반")
        SoftCard {
            SettingRow("거리 단위") { SoftSegmented(listOf("km", "mi"), s.unit.ordinal) { s.unit = DistanceUnit.entries[it] } }
            GrooveDivider()
            SwitchRow("블랙 테마", "어두운 화면으로 바꿔요", Soft.isBlack) { Soft.isBlack = it }
            GrooveDivider()
            SettingRow("앱 버전") { Text(appVersion(), color = Soft.TextSub, fontSize = 14.sp) }
        }
    }
}

/** 페이지 본문: 세로 스크롤 */
@Composable
private fun PageBody(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = EDGE)
            .padding(top = 12.dp, bottom = 32.dp),
        content = content,
    )
}

/** 볼록한 카드 */
@Composable
private fun SoftCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(vertical = 4.dp),
        content = content,
    )
}

@Composable
private fun SectionHeader(text: String, tag: String? = null) {
    Row(
        Modifier.padding(start = 4.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = Soft.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
        if (tag != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                tag,
                color = Soft.TextHint,
                fontSize = 11.sp,
                modifier = Modifier
                    .border(1.dp, Soft.TextHint.copy(alpha = 0.6f), PillShape)
                    .padding(horizontal = 8.dp, vertical = 1.dp),
            )
        }
    }
}

@Composable
private fun RowScope.StatTile(label: String, value: String, unit: String) {
    Column(
        Modifier
            .weight(1f)
            .height(80.dp)
            .softRaised(CardShape)
            .clip(CardShape)
            .background(Soft.Base)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Soft.TextSub, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Soft.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(3.dp))
                Text(unit, color = Soft.TextSub, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp))
            }
        }
    }
}

@Composable
private fun RideRow(title: String, detail: String, date: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(WellShape)
                .background(Soft.Base)
                .softInset(WellShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Place, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Soft.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Soft.TextSub, fontSize = 12.sp)
        }
        Text(date, color = Soft.TextHint, fontSize = 12.sp)
    }
}

@Composable
private fun MenuRow(title: String, value: String?, onClick: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(interactionSource = null, indication = null, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Soft.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = Soft.TextSub, fontSize = 13.sp)
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = Soft.TextHint,
            modifier = Modifier.size(20.dp),
        )
    }
}

/** 줄 전체를 눌러도 켜고 끌 수 있는 스위치 줄 */
@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                interactionSource = null,
                indication = null,
                role = Role.Switch,
                onValueChange = onChange,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Soft.Text, fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, color = Soft.TextSub, fontSize = 12.sp)
        }
        SoftSwitch(checked)
    }
}

@Composable
private fun SettingRow(title: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Soft.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        trailing()
    }
}

/** 소프트 UI 스위치: 오목한 길 위로 볼록한 손잡이. 켜지면 길이 파란색 */
@Composable
private fun SoftSwitch(checked: Boolean) {
    val t by animateFloatAsState(if (checked) 1f else 0f, tween(180), label = "switch")
    Box(
        Modifier
            .size(50.dp, 28.dp)
            .clip(PillShape)
            .drawBehind { drawRect(lerpColor(Soft.Base, Soft.Accent, t)) }
            .softInset(PillShape, offset = 2.dp, blur = 3.dp)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .offset { IntOffset((22.dp.toPx() * t).roundToInt(), 0) }
                .size(20.dp)
                .softRaised(CircleShape, offset = 1.5.dp, blur = 3.dp)
                .clip(CircleShape)
                .drawBehind { drawRect(lerpColor(Soft.Base, Color.White, t)) }
        )
    }
}

/** 소프트 UI 선택 버튼 묶음: 고른 쪽이 볼록하게 */
@Composable
private fun SoftSegmented(options: List<String>, selected: Int, itemWidth: Dp = 48.dp, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .height(34.dp)
            .clip(PillShape)
            .background(Soft.Base)
            .softInset(PillShape, offset = 2.dp, blur = 3.dp)
            .padding(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(itemWidth)
                    .then(if (sel) Modifier.softRaised(PillShape, offset = 1.5.dp, blur = 3.dp).clip(PillShape).background(Soft.Base) else Modifier)
                    .clickable(interactionSource = null, indication = null) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (sel) Soft.Accent else Soft.TextSub,
                    fontSize = 13.sp,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

/** 작은 글자 버튼 (누르면 오목하게) */
@Composable
private fun SoftTextButton(text: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        Modifier
            .height(36.dp)
            .softPressable(PillShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Soft.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ───────────────────────── 현재 위치 ─────────────────────────

/** 메뉴 모아보기 버튼: 겹쳐진 막대들을 한 번에 펼쳐서 보여줌. 펼친 동안은 닫기(X) */
@Composable
private fun OverviewButton(open: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val color = if (open) Soft.Accent else Soft.TextSub
    Box(
        modifier
            .size(LOC_BTN)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics { contentDescription = if (open) "모아보기 닫기" else "메뉴 모아보기" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(22.dp)) {
            val sw = 2.dp.toPx()
            if (open) {
                val m = 6.dp.toPx()
                drawLine(color, Offset(m, m), Offset(size.width - m, size.height - m), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(size.width - m, m), Offset(m, size.height - m), sw, cap = StrokeCap.Round)
            } else {
                // 겹쳐진 막대 3개 (오른쪽 정렬, 위로 갈수록 짧게 = 원통 메뉴 모양)
                val right = size.width - 3.dp.toPx()
                drawLine(color, Offset(right - 15.dp.toPx(), 16.dp.toPx()), Offset(right, 16.dp.toPx()), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(right - 12.dp.toPx(), 11.dp.toPx()), Offset(right, 11.dp.toPx()), sw, cap = StrokeCap.Round)
                drawLine(color, Offset(right - 9.dp.toPx(), 6.dp.toPx()), Offset(right, 6.dp.toPx()), sw, cap = StrokeCap.Round)
            }
        }
    }
}

/** 현재 위치 버튼 (작은 볼록 동그라미). 내 위치를 알고 있으면 아이콘이 파란색 */
@Composable
private fun MyLocationButton(active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val color = if (active) Soft.Accent else Soft.TextSub
    Box(
        modifier
            .size(LOC_BTN)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics { contentDescription = "현재 위치" },
        contentAlignment = Alignment.Center,
    ) {
        // 조준선 모양 아이콘
        Canvas(Modifier.size(22.dp)) {
            val c = center
            val sw = 2.dp.toPx()
            drawCircle(color, radius = 6.dp.toPx(), center = c, style = Stroke(sw))
            drawCircle(color, radius = 2.5.dp.toPx(), center = c)
            val r1 = 8.dp.toPx()
            val r2 = 10.dp.toPx()
            drawLine(color, Offset(c.x, c.y - r2), Offset(c.x, c.y - r1), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x, c.y + r1), Offset(c.x, c.y + r2), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x - r2, c.y), Offset(c.x - r1, c.y), sw, cap = StrokeCap.Round)
            drawLine(color, Offset(c.x + r1, c.y), Offset(c.x + r2, c.y), sw, cap = StrokeCap.Round)
        }
    }
}

/** 소프트 UI 동그란 아이콘 버튼 (누르면 오목하게 들어감) */
@Composable
private fun SoftIconButton(onClick: () -> Unit, size: Dp = 44.dp, content: @Composable () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        Modifier
            .size(size)
            .softPressable(CircleShape) { press.value }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** 날짜 글자: 11.24 */
private fun shortDate(millis: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = millis }
    return "${c.get(Calendar.MONTH) + 1}.${c.get(Calendar.DAY_OF_MONTH)}"
}

/** 주행 목표 글자: 50km / 31mi */
private fun goalText(km: Int, unit: DistanceUnit): String =
    if (unit == DistanceUnit.Km) "${km}km" else "${(km / 1.609344).roundToInt()}mi"

/** 앱 버전 (build.gradle 의 versionName) */
@Composable
private fun appVersion(): String {
    val context = LocalContext.current
    return remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "-"
    }
}
