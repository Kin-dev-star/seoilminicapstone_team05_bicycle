package com.example.app.ui.data

import androidx.compose.runtime.compositionLocalOf
import kotlin.math.roundToInt

/** 거리 단위 (설정 → 거리 단위) */
enum class DistanceUnit { Km, Mile }

/** 화면 전체에서 쓰는 거리 단위. 메인 화면이 설정 값으로 넣어 줌 */
val LocalDistanceUnit = compositionLocalOf { DistanceUnit.Km }

private const val METERS_PER_MILE = 1609.344
private const val FEET_PER_METER = 3.28084

/** 거리 글자: km 단위면 47m · 120m · 1.2km, 마일 단위면 500ft · 0.3mi */
fun formatDistance(meters: Int, unit: DistanceUnit = DistanceUnit.Km): String = when (unit) {
    DistanceUnit.Km -> when {
        meters >= 1000 -> "${meters / 1000}.${meters % 1000 / 100}km"
        meters >= 50 -> "${(meters + 5) / 10 * 10}m"
        else -> "${meters}m"
    }
    DistanceUnit.Mile -> {
        val miles = meters / METERS_PER_MILE
        if (miles < 0.1) {
            "${(meters * FEET_PER_METER / 10).roundToInt() * 10}ft"
        } else {
            val tenths = (miles * 10).roundToInt()
            "${tenths / 10}.${tenths % 10}mi"
        }
    }
}

/** 숫자와 단위를 나눈 거리 (큰 숫자 칸용): 128.4 + km */
fun distanceParts(meters: Int, unit: DistanceUnit): Pair<String, String> {
    val value = if (unit == DistanceUnit.Km) meters / 1000.0 else meters / METERS_PER_MILE
    val tenths = (value * 10).roundToInt()
    return "${tenths / 10}.${tenths % 10}" to (if (unit == DistanceUnit.Km) "km" else "mi")
}

/** 시간: 31분, 1시간, 1시간 12분 */
fun formatMinutes(minutes: Int): String = when {
    minutes < 60 -> "${minutes}분"
    minutes % 60 == 0 -> "${minutes / 60}시간"
    else -> "${minutes / 60}시간 ${minutes % 60}분"
}

/** 음성으로 읽는 거리: 80미터, 1.2킬로미터, 500피트, 0.3마일 */
fun spokenDistance(meters: Int, unit: DistanceUnit): String {
    val text = formatDistance(meters, unit)
    return when {
        text.endsWith("km") -> text.removeSuffix("km") + "킬로미터"
        text.endsWith("mi") -> text.removeSuffix("mi") + "마일"
        text.endsWith("ft") -> text.removeSuffix("ft") + "피트"
        else -> text.removeSuffix("m") + "미터"
    }
}
