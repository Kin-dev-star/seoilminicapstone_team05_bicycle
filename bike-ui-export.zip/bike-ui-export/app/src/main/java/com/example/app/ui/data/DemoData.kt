package com.example.app.ui.data

import com.example.app.ui.guide.GeoPoint
import kotlinx.coroutines.delay

/** 데모 값 (실제 데이터를 연결하기 전 임시). 실제 값을 넣기 시작하면 부르는 줄을 지우면 됨 */
object DemoData {
    private const val DAY_MS = 24 * 60 * 60 * 1000L

    /** 마이페이지: 이번 달 기록, 최근 주행 3개, 즐겨찾는 장소 2곳, 주 50km 목표 */
    fun fillProfile(profile: ProfileState) {
        val now = System.currentTimeMillis()
        profile.monthly = RideSummary(distanceMeters = 128_400, rides = 23, minutes = 580)
        profile.recentRides = listOf(
            RideRecord("한강 자전거길", 24_600, 72, now - DAY_MS),
            RideRecord("출퇴근", 8_200, 31, now - 2 * DAY_MS),
            RideRecord("남산 순환", 12_900, 58, now - 4 * DAY_MS),
        )
        profile.favorites = listOf(Place("집", "여의도동"), Place("회사", "광화문"))
        profile.weeklyGoalKm = 50
    }

    /** 데모 장소 검색에 쓰는 서울 장소 (위치는 대략) */
    private val places = listOf(
        Place("서울역", "서울 용산구 · 기차역", GeoPoint(37.5547, 126.9707)),
        Place("서울시청", "서울 중구 · 관공서", GeoPoint(37.5663, 126.9779)),
        Place("서울숲", "서울 성동구 · 공원", GeoPoint(37.5444, 127.0374)),
        Place("서울대입구역", "서울 관악구 · 지하철역", GeoPoint(37.4812, 126.9527)),
        Place("남산서울타워", "서울 용산구 · 전망대", GeoPoint(37.5512, 126.9882)),
        Place("상계역", "서울 노원구 · 지하철역", GeoPoint(37.6610, 127.0734)),
        Place("노원역", "서울 노원구 · 지하철역", GeoPoint(37.6551, 127.0613)),
        Place("광화문", "서울 종로구 · 명소", GeoPoint(37.5759, 126.9768)),
        Place("경복궁", "서울 종로구 · 궁궐", GeoPoint(37.5796, 126.9770)),
        Place("동대문디자인플라자", "서울 중구 · 문화시설", GeoPoint(37.5665, 127.0092)),
        Place("강남역", "서울 강남구 · 지하철역", GeoPoint(37.4979, 127.0276)),
        Place("홍대입구역", "서울 마포구 · 지하철역", GeoPoint(37.5572, 126.9245)),
        Place("잠실역", "서울 송파구 · 지하철역", GeoPoint(37.5133, 127.1001)),
        Place("올림픽공원", "서울 송파구 · 공원", GeoPoint(37.5206, 127.1215)),
        Place("성수역", "서울 성동구 · 지하철역", GeoPoint(37.5446, 127.0557)),
        Place("왕십리역", "서울 성동구 · 지하철역", GeoPoint(37.5612, 127.0371)),
        Place("여의도 한강공원", "서울 영등포구 · 한강공원", GeoPoint(37.5284, 126.9327)),
        Place("반포 한강공원", "서울 서초구 · 한강공원", GeoPoint(37.5100, 126.9960)),
        Place("뚝섬 한강공원", "서울 광진구 · 한강공원", GeoPoint(37.5296, 127.0686)),
        Place("망원 한강공원", "서울 마포구 · 한강공원", GeoPoint(37.5551, 126.8945)),
        Place("이촌 한강공원", "서울 용산구 · 한강공원", GeoPoint(37.5172, 126.9706)),
    )

    /**
     * 데모 장소 검색 (장소 검색 API 붙이기 전 임시): 이름이나 주소(구 이름)에 글자가 들어 있거나 초성이 맞는 장소.
     * 이름이 글자로 시작하는 장소를 먼저, 최대 [limit] 개.
     */
    suspend fun searchPlaces(query: String, limit: Int = 6): List<Place> {
        delay(150)                                        // 검색하는 척
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val initialsOnly = q.all { it in CHOSEONG || it == ' ' }
        val key = q.replace(" ", "")
        return places
            .filter { p ->
                if (initialsOnly) choseong(p.name).replace(" ", "").contains(key)
                else p.name.replace(" ", "").contains(key, ignoreCase = true) || p.address.removePrefix("서울 ").contains(q)   // 주소는 구 이름부터
            }
            .sortedBy { p -> if (p.name.startsWith(q) || choseong(p.name).startsWith(key)) 0 else 1 }
            .take(limit)
    }

    private const val CHOSEONG = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"

    /** 한글 글자를 초성으로 (서울역 → ㅅㅇㅇ) */
    fun choseong(text: String): String = buildString {
        text.forEach { c -> append(if (c in '가'..'힣') CHOSEONG[(c - '가') / 588] else c) }
    }
}
