package com.example.app.ui.main

import android.content.SharedPreferences
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.app.ui.data.DistanceUnit
import com.example.app.ui.guide.GuideStyle

/**
 * 설정 값. 바꾸면 화면에 바로 적용되고, 앱이 저장해 두었다가 다음에 켤 때 불러옴 (BikeApp 이 저장·불러오기를 함).
 * 다른 코드에서도 이 값을 읽어서 쓰면 됨 (예: 주행 기록을 만들 때 [autoPause]).
 */
@Stable
class AppSettings {
    var guideStyle by mutableStateOf(GuideStyle.Banner)   // 길안내 표시: 위쪽 배너 / 오른쪽 위 작은 칸
    var voiceGuide by mutableStateOf(true)                // 음성 안내: 다음 안내를 소리로
    var keepScreenOn by mutableStateOf(true)              // 길안내 중에는 화면을 켜 둠
    var autoPause by mutableStateOf(false)                // 자동 일시정지 (주행 기록 기능에서 읽어서 쓰기)
    var bikeLanes by mutableStateOf(true)                 // 지도에 자전거도로 표시
    var rentalStations by mutableStateOf(false)           // 지도에 공공자전거 대여소 표시
    var unit by mutableStateOf(DistanceUnit.Km)           // 거리 단위
    var notifications by mutableStateOf(true)             // 알림 (마이페이지 '알림')

    /** 저장해 둔 값 불러오기 (저장된 적 없는 값은 그대로) */
    fun loadFrom(prefs: SharedPreferences) {
        guideStyle = enumOr(prefs.getString(K_GUIDE, null), guideStyle)
        voiceGuide = prefs.getBoolean(K_VOICE, voiceGuide)
        keepScreenOn = prefs.getBoolean(K_SCREEN, keepScreenOn)
        autoPause = prefs.getBoolean(K_PAUSE, autoPause)
        bikeLanes = prefs.getBoolean(K_LANES, bikeLanes)
        rentalStations = prefs.getBoolean(K_STATIONS, rentalStations)
        unit = enumOr(prefs.getString(K_UNIT, null), unit)
        notifications = prefs.getBoolean(K_NOTIFY, notifications)
    }

    fun saveTo(prefs: SharedPreferences) {
        prefs.edit()
            .putString(K_GUIDE, guideStyle.name)
            .putBoolean(K_VOICE, voiceGuide)
            .putBoolean(K_SCREEN, keepScreenOn)
            .putBoolean(K_PAUSE, autoPause)
            .putBoolean(K_LANES, bikeLanes)
            .putBoolean(K_STATIONS, rentalStations)
            .putString(K_UNIT, unit.name)
            .putBoolean(K_NOTIFY, notifications)
            .apply()
    }

    /** 값 묶음 (하나라도 바뀌면 저장하려고 비교할 때 씀) */
    fun values(): List<Any> = listOf(guideStyle, voiceGuide, keepScreenOn, autoPause, bikeLanes, rentalStations, unit, notifications)

    private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback

    private companion object {
        const val K_GUIDE = "guide_style"
        const val K_VOICE = "voice_guide"
        const val K_SCREEN = "keep_screen_on"
        const val K_PAUSE = "auto_pause"
        const val K_LANES = "bike_lanes"
        const val K_STATIONS = "rental_stations"
        const val K_UNIT = "distance_unit"
        const val K_NOTIFY = "notifications"
    }
}
