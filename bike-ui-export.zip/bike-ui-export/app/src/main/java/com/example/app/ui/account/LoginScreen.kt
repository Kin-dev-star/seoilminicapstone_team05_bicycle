package com.example.app.ui.account

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app.ui.theme.Soft
import com.example.app.ui.theme.softInset
import com.example.app.ui.theme.softRaised
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private val KakaoYellow = Color(0xFFFEE500)          // 카카오 로그인 버튼 색 (카카오 디자인 가이드)
private val KakaoLabel = Color.Black.copy(alpha = 0.85f)
private val KakaoShape = RoundedCornerShape(12.dp)

/**
 * 로그인 화면 본문 (마이페이지의 '로그인' 버튼으로 열림).
 * '카카오 로그인'을 누르면 [AccountState.kakaoLogin] 을 부르고, 성공하면 사용자 정보를 저장한 뒤 [onDone].
 */
@Composable
fun LoginBody(account: AccountState, onDone: () -> Unit, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(
        modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(0.8f))
        Box(
            Modifier
                .size(96.dp)
                .softRaised(CircleShape)
                .clip(CircleShape)
                .background(Soft.Base),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Soft.Base)
                    .softInset(CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Person, contentDescription = null, tint = Soft.Accent, modifier = Modifier.size(36.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("로그인하고 시작해요", color = Soft.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "카카오 계정으로 간편하게 로그인하고\n주행 기록을 저장할 수 있어요",
            color = Soft.TextSub, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 21.sp,
        )
        Spacer(Modifier.height(36.dp))
        KakaoLoginButton(busy = busy) {
            if (busy) return@KakaoLoginButton
            message = null
            busy = true
            scope.launch {
                try {
                    account.user = account.kakaoLogin()
                    onDone()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    message = e.message ?: "로그인하지 못했어요"
                } finally {
                    busy = false
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            message ?: "",
            color = Soft.TextSub, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.height(20.dp),
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "다음에 할게요",
            color = Soft.TextHint, fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onDone)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        )
        Spacer(Modifier.weight(1.2f))
    }
}

/** 카카오 로그인 버튼 (노란 바탕, 왼쪽 말풍선 기호, 가운데 '카카오 로그인'). 로그인 중엔 돌아가는 표시 */
@Composable
private fun KakaoLoginButton(busy: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .softRaised(KakaoShape, offset = 3.dp, blur = 8.dp)
            .clip(KakaoShape)
            .background(KakaoYellow)
            .background(Color.Black.copy(alpha = if (pressed) 0.06f else 0f))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics {
                contentDescription = "카카오 로그인"
                role = Role.Button
            },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            CircularProgressIndicator(color = KakaoLabel, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
        } else {
            KakaoSymbol(
                Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 18.dp)
                    .size(20.dp)
            )
            Text("카카오 로그인", color = KakaoLabel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** 카카오 말풍선 기호 (공식 이미지로 바꿔도 됨) */
@Composable
private fun KakaoSymbol(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color.Black, topLeft = Offset(0f, h * 0.04f), size = Size(w, h * 0.8f))
        drawPath(
            Path().apply {
                moveTo(w * 0.24f, h * 0.62f)
                lineTo(w * 0.17f, h * 0.98f)
                lineTo(w * 0.5f, h * 0.78f)
                close()
            },
            Color.Black,
        )
    }
}
